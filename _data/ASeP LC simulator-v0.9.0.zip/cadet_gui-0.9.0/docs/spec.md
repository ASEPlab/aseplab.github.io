# CADET GUI 스펙 문서
**University of Wyoming — Choi Lab**
작성일: 2026-09-30 / 개정: 2026-10-01 (v0.2)

> v0.2 변경 요약: 단위계(cm, mL, mL/min, min) 확정, 기호 통일(εb, εp, εt, Eb=Dax),
> Wilson & Geankoplis 식 차원 수정, LRM keff 정의 및 CADET 매핑 확정,
> GIEX 파라미터 / pH 모듈레이터, 피드·고정상 농도 단위 옵션, 화면 구성 변경,
> mass balance → 성분별 input/output mass 표시로 변경.

---

## 1. 프로젝트 개요

### 목적
- CADET 기반의 연구실 전용 크로마토그래피 시뮬레이터 (Aspen Chromatography 같은 사용 경험)
  - 모델 선택 → 해당 모델 파라미터 입력 → 실행 → 모니터링 → 결과 확인/데이터 추출
- 금속이온 + 리간드 이온교환 크로마토그래피 특화
- VERSE(Purdue) 수준의 기능을 오픈소스 + Python 환경에서 구현
- 학생들이 코딩 없이 사용 가능

### 기술 스택
- **백엔드**: CADET-Core + CADET-Process (Python)
- **프론트엔드**: Streamlit (로컬 웹 서버, `localhost:8501`, 오프라인 동작)
- **시각화**: Plotly (인터랙티브, 애니메이션은 Plotly frames로 클라이언트 측 재생)
- **컴퓨팅**: 로컬 랩탑 우선. HPC(UW MedicineBow, SLURM)는 Phase 2
- **설계 원칙**: 계산(`core/`)과 UI(`ui/`) 완전 분리 → UI 프레임워크 교체 가능

### 개발 환경
- 코드: GitHub private repo `HoonChoi2/cadet_gui`, 로컬 clone `~/Projects/cadet_gui` (OneDrive 밖)
- Python 환경: conda(Miniforge) 환경 `cadet`
- 결과/로그 저장 경로는 설정으로 지정 가능 (OneDrive 공유 폴더 지정 가능)

---

## 2. 화면 구성

| 화면 | 내용 | Phase |
|------|------|-------|
| 화면 1: Batch | 단일 컬럼 배치. 모든 컬럼 모델 / 바인딩 / 반응 / gradient 선택 | 1 |
| 화면 2: SMB | 4-zone SMB (구현됨). Sequential SMB, PCC, carousel, 커스텀 배치는 이후 | 2 |
| SMB 결과 | 전체 사이클 출구, 수렴, ring 프로파일, 공정 애니메이션, 추출 | 2 |
| 결과 뷰어 | 저장된 출력 파일 로딩 → 크로마토그램 + 컬럼 내부 농도 프로파일 애니메이션 | 1 |
| Help | 모델별 인풋 항목(단위), 지배방정식, 아웃풋(크로마토그램·내부 분포·mass·무차원수) 설명 | 1 |

- 결과 뷰어는 시뮬레이션 직후 버튼으로 열 수도 있고, 과거 결과 파일을 불러와서 열 수도 있음
- 모든 결과는 CSV / HDF5 로 추출 가능

---

## 3. 핵심 기능 목록

### Phase 1
- [ ] 단일 컬럼 배치 시뮬레이션
- [ ] Gradient elution (linear, step) — 곡선(polynomial) gradient는 불필요하여 제외
- [ ] Pulse injection (주입 부피, 시작 시간, 성분별 농도) — 용리액 프로그램 위에 얹음
- [ ] 바인딩 모델: Linear, Langmuir(경쟁 다성분), Anti-Langmuir, Bi-Langmuir(dual site), Freundlich, SMA, GeneralizedIonExchange(GIEX)
- [ ] Mobile phase 리간드 반응 (MassActionLaw) — **bulk + particle liquid 양쪽에 적용**
  - A + B ⇌ A:B (complexation)
  - A + B-C ⇌ B-A + C (displacement)
  - Kinetic mode (k+, k- 입력)
  - Rapid equilibrium mode (Ka만 입력)
- [ ] 컬럼 모델: GRM, LRMP, LRM(keff), LRM(CADET 원형)
- [ ] Mass transfer 파라미터: 직접 입력 / 상관식 추정
- [ ] Extra-column volume (총 dead volume → 입구/출구 CSTR 반반)
- [ ] 단위 변환 계층 (GUI 단위 ↔ CADET SI)
- [ ] 시뮬레이션 진행률 표시
- [ ] 결과 뷰어
  - 크로마토그램 (출구 농도 vs 시간)
  - 컬럼 내부 농도 분포 (슬라이더 + 애니메이션)
  - 크로마토그램 클릭 → 해당 시간 내부 분포 연동
- [ ] 성분별 input mass / output mass 표
- [ ] 시뮬레이션 요약 (계산시간, 타임스텝, exit flag, 수치 안정성)
- [ ] 무차원수 + 진단 메시지
- [ ] 컬럼 최종 상태 저장/불러오기 (sequential 시뮬레이션용, HDF5)
- [ ] 인풋/아웃풋 로그 자동 저장
- [ ] 데이터 추출 (CSV, HDF5)

### Phase 2
- [ ] 파라미터 피팅 (Sequential: 리간드 없이 피팅 → Ka만 추가 피팅, CSV 실험 데이터 업로드)
- [x] 4-zone SMB (화면 2 + SMB 결과)
- [ ] 멀티컬럼 공정 나머지 (PCC, Sequential SMB, carousel, 커스텀 배치)
- [ ] HPC 연동 (SLURM)

---

## 4. 단위계 및 기호

### GUI 기본 단위

| 항목 | GUI 단위 | CADET 내부 (SI) |
|------|---------|----------------|
| 컬럼 길이, 직경 | cm | m |
| 입자 반경 R | µm (옵션 cm) | m |
| 유량 Q | mL/min | m³/s |
| 부피 (컬럼, dead volume) | mL | m³ |
| 시간 | min | s |
| 속도 u | cm/min | m/s |
| Eb, Dp, Dm | cm²/min | m²/s |
| kf, keff | cm/min | m/s |
| 액상 농도 | 옵션 (§4.3) | mol/m³ (= mmol/L) |
| 고정상 농도 | 옵션 (§4.3) | mol/m³ solid |

- 모든 변환은 `core/units.py` 한 곳에서만 수행
- 무차원수는 cm/min 기준으로 계산 (단위 약분으로 값은 동일). 중간값(u, Eb 등)도 cm/min 기준으로 표시

### 기호

| 기호 | 의미 |
|------|------|
| εb | bed porosity (입자 사이 공극률) |
| εp | intraparticle porosity |
| εt | total porosity = εb + (1−εb)·εp |
| u | **interstitial velocity** = Q / (εb·A) |
| u_s | superficial velocity = εb·u |
| Eb (= Dax) | axial dispersion coefficient |
| Dp | pore diffusivity (**εp 미포함**, CADET `PAR_DIFFUSION`과 동일 정의) |
| kf | film mass transfer coefficient |
| keff | lumped (effective) mass transfer coefficient [cm/min] |
| R, dp | 입자 반경, 직경 (dp = 2R) |
| L | 컬럼 길이 |

### 4.3 농도 단위 옵션

**액상 농도 (피드, 출구, gradient)**

| 단위 | 필요한 성분 정보 |
|------|----------------|
| mol/L, mmol/L | — |
| g/L, mg/L | 분자량 MW |
| meq/L | 전하 ν (GIEX의 ν와 공유) |

**고정상 농도 (q, qmax, Λ)**

| 기준 | 비고 |
|------|------|
| per mL solid | CADET 내부 기준 |
| per mL bed (packed resin) | 문헌에서 흔함. (1−εt) 등으로 변환 |
| per g resin | 수지 밀도 필요 |

- 농도 단위 변경 시 isotherm 상수의 단위도 자동 변환 (예: Langmuir K [L/mol] ↔ [L/mmol])

---

## 5. CADET 모델 구조

### 5.1 컬럼 모델 옵션

| GUI 모델 | CADET 구현 | 파라미터 | 기공 | r방향 구배 |
|---------|-----------|---------|------|----------|
| GRM | GeneralRateModel | Eb, kf, Dp, εb, εp, R | ✅ | ✅ |
| LRMP | LumpedRateModelWithPores | Eb, kf, εb, εp, R | ✅ | ❌ |
| LRM (keff) | **LumpedRateModelWithPores** (kf = keff, rapid-eq 바인딩) | Eb, keff, εb, εp, R | ✅ | ❌ |
| LRM (CADET 원형) | LumpedRateModelWithoutPores | Eb, εt, ka/kd (kinetic binding) | ❌ | ❌ |

#### 지배방정식

**GRM**
```
Bulk:  ∂cb/∂t = Eb·∂²cb/∂z² − u·∂cb/∂z − 3(1−εb)kf/(εb·R)·(cb − cp|r=R)
Pore:  ∂cp/∂t + (1−εp)/εp·∂q/∂t = Dp·(1/r²)·∂/∂r(r²·∂cp/∂r)
BC:    εp·Dp·∂cp/∂r|r=R = kf·(cb − cp|r=R)
```

**LRMP**
```
Bulk:  ∂cb/∂t = Eb·∂²cb/∂z² − u·∂cb/∂z − 3(1−εb)kf/(εb·R)·(cb − cp)
Pore:  εp·∂cp/∂t + (1−εp)·∂q/∂t = 3kf/R·(cb − cp)      (cp = f(z,t))
```

**LRM (keff)** — 액상 driving force LDF 모델
```
Bulk:  ∂cb/∂t = Eb·∂²cb/∂z² − u·∂cb/∂z − 3(1−εb)keff/(εb·R)·(cb − c*)
Part.: εp·∂c*/∂t + (1−εp)·∂q/∂t = 3keff/R·(cb − c*),   q = f_isotherm(c*)
```
- c* = 현재 q와 평형인 액상 농도
- 수학적으로 LRMP(kf → keff, rapid equilibrium binding)와 동일 → CADET LRMP로 계산
- 비선형 isotherm(Langmuir, GIEX)에서도 정확
- keff 추정: 직접 입력/피팅, 또는 Glueckauf 근사 `1/keff = 1/kf + R/(5·εp·Dp)`

**LRM (CADET 원형)**
```
εt·∂c/∂t + (1−εt)·∂q/∂t = εt·(Eb·∂²c/∂z² − u_t·∂c/∂z)
∂q/∂t = 바인딩 kinetics (예: Langmuir ka·c·(qmax−q) − kd·q)
```
- mass transfer가 바인딩 kinetics(ka, kd)에 lumped됨
- ka/kd = 평형상수(얼마나), ka·kd의 크기 = 속도(얼마나 빨리)
- Linear isotherm에서만 keff와 정확히 대응: `ka = 3keff/R`, `kd = 3keff/(R·K)`
- 비선형에서는 `kd_eff = 3keff/(R·K·(qmax−q))` 로 q 의존 → 상수 kd로 표현 불가 (희석 조건에서만 근사)

### 5.2 Mass Transfer 파라미터 입력

#### 옵션 A: 직접 입력
```
GRM:            Eb, kf(성분별), Dp(성분별)
LRMP:           Eb, kf(성분별)
LRM (keff):     Eb, keff(성분별)
LRM (원형):      Eb, (속도는 바인딩 ka/kd로)
```

#### 옵션 B: 상관식 추정
```
공통 유체 물성: μ [cP], ρ [kg/m³ 또는 g/mL]
분자확산계수 Dm (성분별) [cm²/min]: 직접 입력 또는 Wilke-Chang 추정

Re = dp·ρ·u_s / μ = 2R·ρ·εb·u / μ
Sc = μ / (ρ·Dm)

Eb ← Chung & Wen:
     εb·Pe_p = 0.2 + 0.011·Re^0.48,   Pe_p = dp·u / Eb
     → Eb = dp·u·εb / (0.2 + 0.011·Re^0.48)
     (컬럼 Pe = u·L/Eb = L/(2R·εb)·(0.2 + 0.011·Re^0.48))

kf ← Wilson & Geankoplis (0.0016 < Re < 55):
     Sh = kf·dp/Dm = (1.09/εb)·(Re·Sc)^(1/3)
     → kf = (1.09/εb)·(Dm²·u_s / dp²)^(1/3)

Dp:   상관식 없음 → 직접 입력 또는 피팅 (GRM)
keff: Glueckauf 근사 가능 (kf 상관식 + Dp 입력 필요), 또는 직접 입력/피팅
```

| 모델 | 상관식으로 자동 계산 | 직접 입력 필요 |
|------|-------------------|--------------|
| GRM | Eb, kf | Dp |
| LRMP | Eb, kf | — |
| LRM (keff) | Eb, (keff via Glueckauf) | (Dp, Glueckauf 사용 시) |
| LRM (원형) | Eb | ka, kd |

### 5.3 무차원수 (VERSE 기준)

#### Mass Transfer

| 무차원수 | 정의 | GRM | LRMP | LRM(keff) |
|---------|------|-----|------|-----------|
| 1/Pe | Eb/(u·L) | ✅ | ✅ | ✅ |
| Nf | 3(L/R)·(1−εb)·kf/(εb·u) | ✅ | ✅ | ❌ |
| ND | (1−εb)·εp·L·Dp/(εb·u·R²) | ✅ | ❌ | ❌ |
| Bi | kf·R/(εp·Dp) = Nf/(3·ND) | ✅ | ❌ | ❌ |
| N_eff | 3(L/R)·(1−εb)·keff/(εb·u) | ❌ | ❌ | ✅ |

#### 반응 (리간드)

| 무차원수 | 정의 | 의미 |
|---------|------|------|
| Nk+ | L·k+·Cf,L / u | 정반응 / 대류 |
| Nk− | L·k− / u | 역반응 / 대류 |
| Nk+/Nk− | Ka·Cf,L | 평형 세기 |

```
진단 기준:
  Nk− >> 1   → Rapid equilibrium 근사 유효
  Nk− ~ 1    → Kinetic 모드 필요
  Bi > 1     → 기공확산이 rate-limiting
  Bi < 1     → 필름확산이 rate-limiting
  1/Pe < 0.01 → 분산 영향 작음
```

### 5.4 바인딩 모델

**Linear**: K (성분별), kinetic 시 ka, kd

**Anti-Langmuir**: Langmuir + 성분별 부호 p = ±1 (rapid equilibrium에서 p = −1 성분의 K·c가 크면 CADET가 수렴하지 않을 수 있음 → kinetic 사용)

**Bi-Langmuir**: 서로 독립인 두 결합 자리(K·qmax, K2·qmax2), 결합량은 자리 합. 초기 q₀ 입력 불가

**Freundlich**: q = K_F·c^(1/n), 성분 간 경쟁 없음. kinetic은 driving force 형태 dq/dt = k_LDF·(q* − q)

**SMA**: salt가 성분 0 (자동 추가), pH 없음. GIEX에서 pH 항을 뺀 것과 같은 식

**Langmuir**: K(또는 ka, kd), qmax (성분별)

**GeneralizedIonExchange (GIEX)** — 선택 시 전용 입력란 표시
- 성분 구조: comp 0 = salt (counter-ion), comp 1 = pH (비흡착 모듈레이터 성분), 이후 흡착/비흡착 성분
- 입력: Λ (이온교환 용량), 성분별 ka, kd, ν (charge), σ (steric factor)
- 각 파라미터의 salt/pH 의존 계수 (선형/2차 등) + 기준값 pH_ref
- pH gradient = pH 성분의 농도 gradient로 표현
- 비흡착 성분(리간드, 착물 등)은 bound state = 0 으로 설정

### 5.5 Mobile Phase 반응 (MassActionLaw)
```
예시 (GIEX 사용 시): salt, pH, M1, M2, L, M1L, M2L
  M1 + L ⇌ M1L   (Ka1 또는 k+1/k−1)
  M2 + L ⇌ M2L   (Ka2 또는 k+2/k−2)

흡착: M1, M2 (bound state 1)
비흡착: L, M1L, M2L (bound state 0)
```
- 반응은 bulk와 particle liquid(pore) 양쪽에 동일하게 적용
- 참고: 리간드 착물 Ka가 pH(리간드 양성자화)에 의존하는 경우, MassActionLaw에는 pH 모듈레이터가 없으므로 H⁺를 성분으로 넣어 반응식에 포함하는 방식 검토 (대상 시스템 확정 후)

### 5.6 Extra-Column Volume
```
총 dead volume 입력 (mL) → 입구 CSTR: V/2, 출구 CSTR: V/2
Flow sheet: Inlet → [CSTR, V/2] → Column → [CSTR, V/2] → Outlet
```

---

## 6. GUI 상세

### 화면 1: Batch — 파라미터 패널
- 한 페이지에서 스크롤하며 입력 (탭 없음): Components → Column → Binding → Reactions → Mass transfer →
  Inlet/process → Initial state → Simulation
- 성분은 +/− 버튼으로 추가·삭제. salt와 pH는 GIEX 바인딩을 선택했을 때만 자동으로 추가되어 필요한 표
  (Mass transfer, Inlet, Initial state)에 나타남
- 반응은 체크박스를 켰을 때만 입력란 표시
- Pulse injection: 주입 부피·시작 시간·성분별 농도만 입력. 주입 구간(시작 ~ 시작 + V/Q) 동안만 시료 농도이고, 그 앞뒤는
  인렛(용리액) 표를 따름. 끄면 표만으로 인렛 정의 (연속 주입, breakthrough). 인렛 구간별 농도 그래프 표시
- 이전 실행의 컬럼 내부 농도 분포(column profile)로 이어서 계산: `Load column profile`
- 입력 파일: 현재 입력 전체를 JSON으로 저장 / 불러오면 폼이 자동으로 채워짐 (실행 로그, 결과 .h5도 가능)
- Solver tolerances: 기본은 농도에 맞춰 자동(abstol, algtol, WENO epsilon), 수동 입력 가능
```
[성분 정의]          [컬럼 모델]          [바인딩 모델]
  이름, MW, ν          ○ GRM               ○ Linear
  흡착 여부             ○ LRMP              ○ Langmuir
  농도 단위 선택         ○ LRM (keff)        ○ GIEX → 전용 입력란
                       ○ LRM (CADET 원형)
                       L, D [cm], εb, εp, R

[Mass Transfer]      [이동상 / 공정]       [반응]
  ○ 직접 입력           Q [mL/min]          반응식 정의
  ○ 상관식 추정          피드 농도/시간        Ka 또는 k+/k−
  → 모델별 동적 입력란     gradient 섹션        kinetic / rapid-eq
  → 무차원수 미리보기     (linear/step/poly)
                        salt, pH

[ECV]                 [시뮬레이션 설정]
  □ ECV 포함            총 시간 [min], 출력 간격
  dead volume [mL]     이산화 (축/입자 셀 수)
```

### 화면 1: 실행 / 모니터링
```
[▶ 시뮬레이션 실행]
진행률: [████████░░] 78%   경과: 0:01:23   예상 완료: ~25 s
```

### 결과 뷰어
```
┌──────────────────────────────────────┐
│ 크로마토그램 (성분별 출구 농도 vs 시간)   │  ← 클릭 시 아래 연동
├──────────────────────────────────────┤
│ 컬럼 내부 농도 분포 (axial profile)     │
│  표시 상: bulk / pore / solid 선택     │
└──────────────────────────────────────┘
[◀◀ ◀ ▶ ▶▶] [●────────] t = 5.3 min
[▶ 애니메이션] [속도 1x 2x 5x] [💾 GIF/MP4 저장]

┌──────────────────────────────────────┐
│ 시뮬레이션 요약                         │
│ 계산시간 23.4 s | 타임스텝 4,821 | 정상  │
├──────────────────────────────────────┤
│ 성분별 Mass                            │
│        input      output              │
│  M1   12.4 µmol   11.9 µmol           │
│  M2   12.4 µmol   11.8 µmol           │
├──────────────────────────────────────┤
│ 무차원수 + 진단                         │
├──────────────────────────────────────┤
│ 수치 안정성 (에러테스트/Newton 실패 횟수) │
└──────────────────────────────────────┘
[💾 CSV 추출] [💾 HDF5 저장] [💾 컬럼 상태 저장]
```
- input mass = ∫ C_inlet·Q dt, output mass = ∫ C_outlet·Q dt (성분별, trapz)
- 단위는 선택한 농도 단위 기준 (mol, mg, meq 등)

---

## 7. 구현 세부사항

### 진행률
- CADET-Process 기본 실행 경로는 실시간 진행률을 주지 않음 → cadet-cli 실행부 래핑 필요
- 설치된 CADET-Core 버전의 progress 출력 형식 확인 후 파싱
- 시뮬레이션은 백그라운드 프로세스로 실행 (UI 멈춤 방지)

### 컬럼 상태 저장/불러오기
- 최종 상태 저장 → 다음 시뮬레이션 초기조건으로 사용
- 파일 형식: HDF5 (pickle은 버전 호환성 문제로 사용 안 함)

### 결과 저장
- 컬럼 내부 분포를 위해 bulk/particle/solid solution 기록 활성화 (메모리 고려, 출력 간격 조절)
- 결과 파일: HDF5 (입력 파라미터 + 전체 해) + CSV 추출

### 로그
- 파일: `logs/YYYYMMDD_HHMMSS_simulation.json`
- 내용: 입력 파라미터 전체(GUI 단위) + 결과 요약 + 성분별 mass + 무차원수 + 사용한 solver 허용오차

### 입력 파일
- `Save input file`: `BatchSpec` 전체를 GUI 단위 JSON으로 저장 (`format: cadet_gui.input`)
- 불러오기: 입력 파일, 실행 로그(`logs/*.json`), 결과 파일(`.h5`) 모두 가능. 폼 전체가 교체됨

### 데이터 추출
- Excel(.xlsx) 한 파일에 모든 것: Summary(입력, MT 계수, 무차원수, 결과 수치를 한 페이지 텍스트/표), Data(그래프용 열: 시간,
  inlet, outlet, dead volume이 있으면 컬럼 출구도), Charts, 컬럼 내부 분포(상별; Excel 버튼 옆 체크박스로 선택, 기본 제외), 모든 입력 파라미터
- 시뮬레이션 제목(Title)을 입력하면 입력 파일/Excel 파일 이름(`<제목>_YYYYMMDD_HHMMSS`)과 Summary에 표시. Summary에 계산 완료 시각과 파일 생성 시각 포함
- 출구(outlet) = 시스템 출구 (출구 dead volume 이후). dead volume이 있으면 컬럼 출구(그 이전)도 Data에 포함
- 컬럼 profile 파일은 확장자 `.cprofile`(결과 파일 `.h5`와 구분). Batch의 `Load column profile`에서 사용하며 결과 파일도 받음

### Solver 허용오차
- CADET의 abstol(1e-8), algtol(1e-12), WENO epsilon(1e-10)은 mol/m³ 단위의 고정값이라 μM 이하의 낮은 농도에서는
  결과가 왜곡됨 (1 nM: 피크의 ~5 %, 10 pM: ~90 % 오차)
- 자동 모드: 가장 작은 용질 농도 기준 s = min(1, c_scale)로 abstol·s, algtol·s, WENO eps·s² (mM 이상에서는 기본값과 동일)

---

## 8. 개발 로드맵

### Phase 1
```
1. 프로젝트 구조 설정 / git / conda 환경
2. CADET-Core + CADET-Process 설치 및 테스트
3. 단위 변환 계층 (core/units.py)
4. 단일 컬럼 시뮬레이션 백엔드 (모델 빌더)
5. Streamlit 기본 UI (화면 1)
6. 결과 뷰어: 크로마토그램
7. 결과 뷰어: 컬럼 내부 분포 + 애니메이션
8. 상관식 + 무차원수 모듈
9. GIEX + pH 모듈레이터
10. 리간드 반응 모듈 (bulk + particle)
11. ECV (CSTR 반반)
12. 진행률 표시
13. 성분별 mass + 요약 패널
14. 상태 저장/불러오기, 로그, 데이터 추출
15. Help 화면 (인풋 / 모델식 / 아웃풋 설명)
```

### Phase 2
```
16. 파라미터 피팅
17. SMB / Sequential SMB / PCC (화면 2)
18. HPC 연동
```

---

## 9. 프로젝트 구조
```
cadet_gui/
├── app.py                  # Streamlit 메인 (멀티페이지)
├── pages/
│   ├── 1_Batch.py
│   ├── 3_Results_Viewer.py
│   ├── 5_SMB.py            # Phase 2: SMB 입력 + 간략 결과
│   ├── 6_SMB_Results.py    # Phase 2: SMB 상세 결과
│   └── 9_Help.py
├── config.yaml
├── environment.yml         # conda 환경 정의
├── core/
│   ├── units.py            # 단위 변환 (GUI ↔ SI)
│   ├── components.py       # 성분 정의, MW, ν
│   ├── model_builder.py    # CADET-Process 공정 생성
│   ├── simulator.py        # 실행 래퍼 (백그라운드, 진행률)
│   ├── correlations.py     # Chung & Wen, Wilson & Geankoplis, Glueckauf, Wilke-Chang
│   ├── dimensionless.py    # 무차원수 + 진단
│   ├── mass.py             # 성분별 input/output mass
│   ├── results_io.py       # 결과 HDF5/CSV 저장·로딩
│   ├── smb.py              # SMB 사양, 유량 변환(외부/zone/m), triangle 설계, CarouselBuilder 공정
│   ├── smb_sim.py          # 사이클 단위 실행 (진행률, 취소, cyclic steady state)
│   ├── smb_results.py      # SMB 결과(GUI 단위), 사이클별 순도/회수율, 결과 파일
│   └── smb_excel.py        # SMB Excel
├── ui/                     # 재사용 UI 위젯
├── utils/
│   ├── state_manager.py    # 컬럼 상태 저장/불러오기
│   └── logger.py
├── tests/
└── docs/
    └── spec.md
```


---

## 10. SMB (Phase 2, 구현)

- 컬럼/바인딩/반응/질량이동/수치 설정은 Batch와 같은 `BatchSpec`(`SMBSpec.base`)을 사용 → 모든 컬럼·바인딩 모델 가능.
  SMB 폼은 Batch 폼과 별도 상태(session 키 접두어 `smb_`); `Copy from Batch`로 가져오기
- 구성(layout): 4-zone closed(표준, zone IV 재순환) / 4-zone open(zone IV 출구 → waste) / 3-zone(open, zone III 출구 전부
  raffinate) / 5-zone closed·open(extract 1, extract 2, raffinate: 3성분; open은 zone V 출구 → waste). zone마다 1–8개 컬럼, 전환 시간 t_s,
  포트는 매 전환마다 한 칸 전진. 내부적으로 zone 유량이 기준이고 포트 유량은 인접 zone 유량 차이
- 유량 입력 3가지(상호 변환): 외부 유량(Q_F, Q_D, extract 유량, 필요 시 마지막 zone 유량) / zone 유량 / m 값
  (m_j = (Q_j·t_s − V_c·εt)/(V_c·(1−εt))). 모든 zone 유량과 포트 유량 > 0. 구성 변경 시 zone 유량 이월(불가하면 기본값)
- triangle 설계: 4-zone closed, 2성분 Linear/Langmuir, 안전계수 γ (CADET-Process 설계식). 5-zone 예제는 두지 않음
- feed/eluent 조성 일정. 제품: extract/raffinate 성분 선택 (기본: 강흡착 성분 → extract)
- 질량이동 상관식은 zone 평균 유량 사용 (모든 컬럼 동일 계수)
- 계산: 사이클마다 CADET 1회 실행(이전 상태에서 계속), cyclic steady state(모든 출구 흐름과 컬럼 출구에서 연속 두
  사이클의 면적·NRMSE 상대 변화 ≤ 허용오차; 0 농도는 feed/eluent 최대 농도의 1e-6을 하한으로) 또는 고정 사이클 수.
  출구별 물질량은 전환 구간마다 해당 컬럼 출구(시간 연속)를 적분. 사이클별 차이는 결과에 저장, 마지막 두 사이클
  차이가 허용오차보다 크면 경고(고정 사이클 모드 포함) 직전 SMB 결과 또는 저장된 SMB 결과 파일(.smbh5)의 최종 상태에서 이어서 계산 가능(구성·컬럼 수·모델·격자·성분·
  바인딩이 같아야 함; 유량·전환 시간·feed/eluent는 변경 가능)
- 결과: 순도(용질만; salt/pH 제외), 회수율(같은 사이클 feed 대비), 생산성(전체 bed L·h 당), 용리액 사용량(제품당 L);
  사이클별 표; 컬럼별 출구; 컬럼 프로파일은 첫 사이클부터 끝까지 저장(float32; 자동: 모든 출력 시점, 단 3000개
  시점·phase당 5·10⁷ 값을 넘으면 일정 간격으로 솎음; 사용자 지정 profile interval 가능)
- 화면: SMB 화면 아래 간략 결과, SMB 결과 페이지(탭: Outlets, Cycles, Column profiles, Process animation, Export)
- 파일: SMB 입력 JSON(`cadet_gui.smb_input`), SMB 결과 .smbh5(HDF5, `cadet_gui.smb_result`; Batch 결과 .h5와 구분), 실행 로그 `logs/*_smb.json`,
  Excel(Summary, Data, Cycles, Charts, Column outlets, Input parameters, 선택 시 Ring 프로파일)
