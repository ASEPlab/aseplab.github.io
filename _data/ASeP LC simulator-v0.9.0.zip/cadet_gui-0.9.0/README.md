# CADET GUI

Chromatography simulator with a web interface, built on [CADET](https://cadet.github.io) by the Choi Lab,
University of Wyoming. It runs on your own computer and opens in your web browser.

- **Batch**: single-column runs — GRM, LRMP, LRM (keff), LRM; Linear, Langmuir, Anti-Langmuir, Bi-Langmuir,
  Freundlich, SMA and GIEX binding; mobile-phase reactions; pulse injection and gradients; results viewer with
  column profiles, animation, Excel / CSV / HDF5 export.
- **SMB**: simulated moving bed with 3, 4 or 5 zones (open or closed loop), any of the Batch column and binding
  models, cyclic steady state, purity / recovery / productivity, column profiles over the whole run, process
  animation, Excel / CSV / result-file export.
- **Help**: inputs, model equations and outputs.

The version is in the file `VERSION` and on the app's start page.

## Install (once)

You need about 2 GB of disk space and an internet connection for the installation. Nothing needs
administrator rights; everything goes into one folder in your home directory (`.cadet_gui`), so it does not
interfere with other Python or conda installations.

1. Unzip `cadet_gui-<version>.zip` somewhere convenient (for example *Documents*).
2. Run the installer in that folder:
   - **macOS**: double-click `install.command`.
     The first time, macOS may say it cannot open a file from an unidentified developer: right-click
     (or Control-click) `install.command` → *Open* → *Open*. Do the same once for `run.command`.
   - **Windows**: double-click `install.bat`.
     If Windows shows *Windows protected your PC*, click *More info* → *Run anyway*. Do the same once for
     `run.bat`.
3. A window shows the progress: it downloads Miniforge (a small conda distribution) and then CADET and the
   Python packages (5–15 minutes). It ends with `Installation finished`.

## Run

Double-click `run.command` (macOS) or `run.bat` (Windows). The app opens in your browser at
<http://localhost:8501>. Keep the small terminal window open while you work; close it to stop the app.

## Update

Unzip the new version next to the old one and copy over your `logs/` and `results/` folders and your
`config.yaml` (or point `config.yaml` to folders outside the app folder, then nothing needs copying). Then run
the new version's installer: it updates the environment instead of reinstalling it.

## Where your files go

- Run logs: `logs/` in the app folder; result files saved with *Save to this folder*: `results/` by default.
  Both folders can be changed in `config.yaml`.
- Download buttons (Excel, CSV, result files) save through your browser, to its download folder.

## Uninstall

Delete the app folder and the folder `.cadet_gui` in your home directory (macOS: `~/.cadet_gui`; Windows:
`%USERPROFILE%\.cadet_gui`, or `C:\cadet_gui` if your user name contains a space).

## Troubleshooting

- **The installer stops with an error**: run it again (an interrupted download is the most common cause). If
  it keeps failing, send the text in the window to the Choi Lab.
- **The browser does not open**: open <http://localhost:8501> yourself (or the address printed in the window,
  for example `:8502` if another app already uses 8501).
- **A different install folder**: set the environment variable `CADET_GUI_HOME` to a folder without spaces
  before running the installer and the start script.
- **Windows**: the progress bar during a run is not shown (the run itself works). The Windows version has had
  less testing than macOS; please report problems.

## For developers

```bash
conda env create -f environment.yml      # or: install.command / install.bat
conda activate cadet
streamlit run app.py
python -m pytest -q tests                # the test suite (several minutes)
```

Package versions are pinned in `environment.yml`. The full specification is in `docs/spec.md`.
A release zip for collaborators is built from the last commit with `tools/make_release.sh`
(`dist/cadet_gui-<version>.zip`); bump `VERSION` first.

## License

Copyright (C) 2026 Choi Lab, University of Wyoming.

CADET GUI is free software: you can redistribute it and/or modify it under the terms of the GNU General Public
License, version 3, as published by the Free Software Foundation. It is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the file [LICENSE](LICENSE) for the full text.

## Third-party software and licenses

The installer downloads these from conda-forge and PyPI; they keep their own licenses:

- [CADET-Core](https://github.com/cadet/CADET-Core) — AGPL-3.0
- [CADET-Process](https://github.com/fau-advanced-separations/CADET-Process) — GPL-3.0
- [CADET-Python](https://github.com/cadet/CADET-Python) — BSD-3-Clause
- [Streamlit](https://streamlit.io) — Apache-2.0; Plotly — MIT; NumPy, SciPy, pandas, h5py, Matplotlib and the
  other Python packages — their respective open-source licenses
- [Miniforge](https://github.com/conda-forge/miniforge) — BSD-3-Clause
