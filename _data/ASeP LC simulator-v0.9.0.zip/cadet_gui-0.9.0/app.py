"""CADET GUI — Streamlit entry point. Run with: streamlit run app.py"""
import streamlit as st

from core import __version__

st.set_page_config(page_title="CADET GUI", layout="wide")
st.title("CADET chromatography simulator")
st.caption(f"Version {__version__} · Choi Lab, University of Wyoming · free software under the GNU GPL v3 "
           "(see LICENSE), without any warranty")
st.markdown(
    "Choi Lab, University of Wyoming. Built on CADET-Core and CADET-Process.\n\n"
    "- **Batch** — single-column simulation (GRM, LRMP, LRM (keff), LRM)\n"
    "- **Results viewer** — chromatogram linked to column profiles (bulk / pore / solid), "
    "animation, HDF5/CSV export\n"
    "- **SMB** — four-zone simulated moving bed with the same column and binding models\n"
    "- **SMB results** — outlets over all cycles, convergence, ring profiles, process animation, export\n"
    "- **Help** — inputs, model equations and outputs\n\n"
    "Units: cm, mL, mL/min, min; particle radius in µm."
)
st.page_link("pages/1_Batch.py", label="Open Batch screen", icon="▶")
st.page_link("pages/3_Results_Viewer.py", label="Open Results viewer", icon="📈")
st.page_link("pages/5_SMB.py", label="Open SMB screen", icon="🔁")
st.page_link("pages/6_SMB_Results.py", label="Open SMB results", icon="📊")
st.page_link("pages/9_Help.py", label="Help", icon="❓")
