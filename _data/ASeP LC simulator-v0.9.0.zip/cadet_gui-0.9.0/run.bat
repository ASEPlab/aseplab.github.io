@echo off
rem CADET GUI: starts the app and opens it in the web browser. Keep this window open while you use the app;
rem close it (or press Ctrl+C) to stop the app.
setlocal
cd /d "%~dp0"
if defined CADET_GUI_HOME (set "ROOT=%CADET_GUI_HOME%") else (set "ROOT=%USERPROFILE%\.cadet_gui")
if not "%ROOT%"=="%ROOT: =%" set "ROOT=%SystemDrive%\cadet_gui"
if exist "%ROOT%\env\python.exe" goto :run
echo The app is not installed yet. Run install.bat first.
pause
exit /b 1
:run
set /p VERSION=<VERSION
echo Starting CADET GUI %VERSION%... The browser opens by itself; the address (Local URL) is shown below.
call "%ROOT%\miniforge\Scripts\activate.bat" "%ROOT%\env"
python -m streamlit run app.py --browser.gatherUsageStats false
pause
