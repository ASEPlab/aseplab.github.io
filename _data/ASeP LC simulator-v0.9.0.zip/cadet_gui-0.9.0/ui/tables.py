"""Editable tables whose contents persist in ``st.session_state``.

Each table's authoritative DataFrame lives at ``st.session_state[store_key]``.
Edits are applied in the editor's ``on_change`` callback and the editor is then
re-keyed, so edits never stack or get lost across reruns.
"""
import pandas as pd
import streamlit as st


def _version_key(store_key):
    return f"{store_key}__version"


def _bump(store_key):
    st.session_state[_version_key(store_key)] = st.session_state.get(_version_key(store_key), 0) + 1


def _apply_edits(store_key, editor_key):
    delta = st.session_state[editor_key]
    df = st.session_state[store_key].copy()
    for pos, changes in delta.get("edited_rows", {}).items():
        for col, value in changes.items():
            if col in df.columns:
                df.iloc[int(pos), df.columns.get_loc(col)] = value
    deleted = delta.get("deleted_rows", [])
    if deleted:
        df = df.drop(df.index[deleted])
    added = [{k: v for k, v in row.items() if k in df.columns} for row in delta.get("added_rows", [])]
    if added:
        df = pd.concat([df, pd.DataFrame(added)], ignore_index=True)
    elif deleted:
        df = df.reset_index(drop=True)
    st.session_state[store_key] = df
    _bump(store_key)


def init_table(store_key, default_df):
    if store_key not in st.session_state:
        st.session_state[store_key] = default_df


def set_table(store_key, df):
    """Replace a table's contents programmatically (e.g. after syncing rows)."""
    st.session_state[store_key] = df
    _bump(store_key)


def editable_table(store_key, *, decorate=None, **editor_kwargs):
    """Show ``st.data_editor`` for the stored table and return the stored DataFrame.

    ``decorate(df) -> df`` may add read-only display columns (e.g. units);
    mark them ``disabled`` via ``editor_kwargs``.
    """
    df = st.session_state[store_key]
    editor_key = f"{store_key}__editor_{st.session_state.get(_version_key(store_key), 0)}"
    st.data_editor(
        decorate(df) if decorate else df,
        key=editor_key,
        on_change=_apply_edits,
        args=(store_key, editor_key),
        width="stretch",
        **editor_kwargs,
    )
    return st.session_state[store_key]


def _default_for(value, name):
    """A default is a scalar, or a dict ``{row/column name: value, "*": fallback}``."""
    return value.get(name, value.get("*", 0.0)) if isinstance(value, dict) else value


def sync_index(store_key, names, defaults):
    """Make the table's rows match component ``names``.

    Same row count -> treated as a rename, values kept by position.
    Otherwise rows are matched by name and new rows get ``defaults`` (per column: a
    scalar or ``{row name: value, "*": fallback}``).
    """
    df = st.session_state[store_key]
    names = list(names)
    if list(df.index) == names:
        return df
    if len(df) == len(names):
        new = df.set_axis(names, axis=0)
    else:
        new = df.reindex(names)
        added = [n for n in names if n not in df.index]
        for col, value in defaults.items():
            if col in new.columns:
                for name in added:
                    new.loc[name, col] = _default_for(value, name)
    set_table(store_key, new)
    return new


def sync_columns(store_key, fixed, names, default):
    """Make the table's columns ``fixed + names`` (component columns), like ``sync_index``;
    ``default`` is a scalar or ``{column name: value, "*": fallback}``."""
    df = st.session_state[store_key]
    names = list(names)
    current = [c for c in df.columns if c not in fixed]
    if current == names:
        return df
    if len(current) == len(names):
        new = df.rename(columns=dict(zip(current, names)))
    else:
        new = df.reindex(columns=list(fixed) + names)
        for name in names:
            if name not in df.columns:
                new[name] = _default_for(default, name)
    set_table(store_key, new)
    return new
