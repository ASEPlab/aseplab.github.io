"""Plotly figures for results."""
import numpy as np
import plotly.graph_objects as go

from core import model_builder as mb

from core.palette import SERIES_COLORS  # noqa: E402  (fixed-order categorical colours, shared with the Excel charts)
MARKER_COLOR = "#7a7a75"   # neutral ink for the time cursor

PHASE_LABELS = {"bulk": "Bulk liquid", "pore": "Pore liquid", "solid": "Solid (bound)"}
SPEEDS = {"1x": 120, "2x": 60, "5x": 24}   # ms per animation frame


def series_color(i):
    return SERIES_COLORS[i % len(SERIES_COLORS)]


def _axis_title(prefix, unit_set):
    return f"{prefix} [{next(iter(unit_set))}]" if len(unit_set) == 1 else prefix


def _layout(fig, x_title, y_title):
    fig.update_layout(
        xaxis_title=x_title,
        yaxis_title=y_title,
        hovermode="x unified",
        margin=dict(l=10, r=10, t=30, b=10),
        legend=dict(orientation="h", y=1.1),
    )


def default_components(result):
    """(main, modifiers): component indices for the main plots and the salt / pH traces that are drawn
    separately (their scales differ from the solutes)."""
    n = len(result.components)
    k = mb.modulator_count(result.spec.binding.model)
    return list(range(k, n)), list(range(k))


def chromatogram(result, t=None, components=None, height=None):
    """Outlet concentration vs time for ``components`` (indices, default all);
    optional vertical cursor at ``t`` [min]."""
    components = range(len(result.components)) if components is None else components
    fig = go.Figure()
    for i in components:
        comp = result.components[i]
        # Transparent markers make every output point clickable (selection needs markers).
        fig.add_trace(go.Scatter(x=result.time, y=result.outlet[:, i], mode="lines+markers",
                                 name=f"{comp.name} [{comp.liquid_unit}]",
                                 line=dict(width=2, color=series_color(i)),
                                 marker=dict(size=8, opacity=0, color=series_color(i)),
                                 selected=dict(marker=dict(opacity=0)),
                                 unselected=dict(marker=dict(opacity=0))))
    if t is not None:
        fig.add_vline(x=t, line=dict(color=MARKER_COLOR, width=1, dash="dot"))
    _layout(fig, "Time [min]",
            _axis_title("Outlet concentration", {result.components[i].liquid_unit for i in components}))
    if height:
        fig.update_layout(height=height)
    return fig


def inlet_program(segments, comps, indices, duration, height=260):
    """Concentration the column receives over time (``segments`` = ``OperationSpec.program()``),
    one line per component in ``indices``. Steps are drawn as vertical jumps."""
    fig = go.Figure()
    ends = [seg.start for seg in segments[1:]] + [duration]
    for i in indices:
        xs, ys = [], []
        for seg, end in zip(segments, ends):
            if seg.start > duration:
                break
            end = min(end, duration)
            poly = list(seg.coefficients[i]) + [0.0] * (4 - len(seg.coefficients[i]))
            tau = end - seg.start
            xs += [seg.start, end]
            ys += [poly[0], sum(a * tau ** k for k, a in enumerate(poly))]
        fig.add_trace(go.Scatter(x=xs, y=ys, mode="lines", name=f"{comps[i].name} [{comps[i].liquid_unit}]",
                                 line=dict(width=2, color=series_color(i))))
    unit_set = {comps[i].liquid_unit for i in indices}
    _layout(fig, "Time [min]", "pH" if unit_set == {"pH"} else _axis_title("Concentration", unit_set))
    fig.update_xaxes(range=[0, duration])
    fig.update_layout(height=height)
    return fig


def modifier_trace(result, i, t=None):
    """Single outlet trace (salt or pH) on its own axis."""
    comp = result.components[i]
    fig = go.Figure(go.Scatter(x=result.time, y=result.outlet[:, i], mode="lines", name=comp.name,
                               line=dict(width=2, color=series_color(i))))
    if t is not None:
        fig.add_vline(x=t, line=dict(color=MARKER_COLOR, width=1, dash="dot"))
    _layout(fig, "Time [min]", f"{comp.name} [{comp.liquid_unit}]")
    # Pad the range so a constant trace (e.g. fixed pH) is not zoomed into solver round-off.
    lo, hi = float(np.nanmin(result.outlet[:, i])), float(np.nanmax(result.outlet[:, i]))
    pad = max(0.05 * (hi - lo), 0.05 * max(abs(lo), abs(hi)), 1e-6)
    fig.update_yaxes(range=[lo - pad, hi + pad], tickformat=".4g")
    fig.update_layout(height=220, showlegend=False, title=dict(text=f"Outlet {comp.name}", x=0, font_size=13))
    return fig


def _frame_indices(nt, current, max_frames):
    idx = np.unique(np.round(np.linspace(0, nt - 1, min(nt, max_frames))).astype(int))
    return np.union1d(idx, [current])


def column_profile(result, phase, t_index, max_frames=150, fixed_y=True, components=None):
    """Axial concentration profile of ``phase`` at ``result.time[t_index]``, with
    client-side animation over time (play at 1x/2x/5x, scrub with the slider).

    ``fixed_y``: y range spans all times (steady axes while animating);
    otherwise it autoscales to the current time."""
    data = getattr(result, phase)
    candidates = range(len(result.components)) if components is None else components
    comps = [i for i in candidates if not np.all(np.isnan(data[:, :, i]))]
    frames_idx = _frame_indices(len(result.time), t_index, max_frames)

    def traces(k):
        return [go.Scatter(x=result.z, y=data[k, :, i], mode="lines",
                           name=f"{result.components[i].name} [{result.unit(phase, i)}]",
                           line=dict(width=2, color=series_color(i)))
                for i in comps]

    fig = go.Figure(data=traces(t_index),
                    frames=[go.Frame(data=traces(k), name=str(k)) for k in frames_idx])
    if fixed_y:
        y_max = np.nanmax(data[:, :, comps]) if comps else 0.0
        fig.update_yaxes(range=[0, 1.05 * y_max if y_max > 0 else 1.0])
    fig.update_xaxes(range=[0, result.spec.column.length])
    _layout(fig, "Axial position z [cm]",
            _axis_title(f"{PHASE_LABELS[phase]} concentration", {result.unit(phase, i) for i in comps}))

    def play(ms):
        return dict(frame=dict(duration=ms, redraw=False), transition=dict(duration=0), fromcurrent=True,
                    mode="immediate")

    fig.update_layout(
        hovermode="x",
        updatemenus=[dict(
            type="buttons", direction="left", x=0, y=-0.18, xanchor="left", yanchor="top", showactive=False,
            buttons=[dict(label=f"▶ {name}", method="animate", args=[None, play(ms)]) for name, ms in SPEEDS.items()]
            + [dict(label="⏸", method="animate",
                    args=[[None], dict(frame=dict(duration=0, redraw=False), mode="immediate")])],
        )],
        sliders=[dict(
            active=int(np.searchsorted(frames_idx, t_index)),
            x=0.3, len=0.7, y=-0.12, yanchor="top",
            currentvalue=dict(prefix="t = ", suffix=" min"),
            steps=[dict(label=f"{result.time[k]:.3g}", method="animate",
                        args=[[str(k)], dict(frame=dict(duration=0, redraw=False), mode="immediate")])
                   for k in frames_idx],
        )],
        margin=dict(l=10, r=10, t=30, b=110),
        height=480,
    )
    return fig
