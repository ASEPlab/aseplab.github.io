"""Reusable Streamlit widgets (presentation only)."""
