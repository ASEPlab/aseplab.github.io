"""Saving a file to a folder on the computer that runs the app (independent of the browser's downloads)."""
import streamlit as st

from utils import result_files
from utils.config import load_config


def folder_save(key, data, default_name, extension, label="Save with a chosen name and folder"):
    """Expander with file name, folder and a save button. ``default_name`` is used when the name is empty or
    when ``default_name`` changes (a new result / input); returns nothing."""
    name_key, folder_key, last_key = f"{key}_name", f"{key}_folder", f"{key}_default"
    if st.session_state.get(last_key) != default_name:
        st.session_state[name_key] = default_name
        st.session_state[last_key] = default_name
    st.session_state.setdefault(folder_key, str(load_config().results_dir))
    with st.expander(label):
        n1, n2 = st.columns(2)
        n1.text_input("File name", key=name_key, help=f"The extension .{extension} is added if missing.")
        n2.text_input("Folder", key=folder_key, help="On the computer that runs the app; created if needed. "
                                                    "The default is results_dir from config.yaml.")
        target = result_files.target_path(st.session_state[folder_key], st.session_state[name_key], extension)
        taken = target.exists()
        overwrite = st.checkbox(f"{target.name} already exists: overwrite it", key=f"{key}_overwrite") \
            if taken else False
        st.caption(f"Will be saved as `{target}`")
        if st.button("💾 Save to this folder", key=f"{key}_save", disabled=taken and not overwrite):
            try:
                saved = result_files.save_file(st.session_state[folder_key], st.session_state[name_key], extension,
                                               data() if callable(data) else data, overwrite=overwrite)
                st.success(f"Saved {saved}")
            except (OSError, ValueError) as e:
                st.error(f"Could not save the file: {e}")
