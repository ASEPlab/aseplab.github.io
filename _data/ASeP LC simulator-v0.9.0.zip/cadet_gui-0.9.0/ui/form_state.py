"""Mapping of a ``BatchSpec`` onto the Batch form's state (no Streamlit import).

``spec_to_state`` returns every widget value and table of the form, so loading an
input file, an example or the startup defaults all go through one place and always
set the complete form. ``render()`` in ``batch_form`` does the opposite direction.

Keys of the returned dict: widget keys (plain values), the five table keys of
``TABLE_KEYS`` (DataFrames), and the component rows ``comp_<id>_<field>``.
"""
import math
import re

import numpy as np
import pandas as pd

from core import model_builder as mb
from core import units
from core.components import PH_NAME, SALT_NAME

LIQUID_UNITS = list(units.LIQUID_UNITS)
SALT_UNITS = ["mmol/L", "mol/L"]
SOLID_UNITS = [f"{a}/{b}" for b in units.SOLID_BASES for a in units.AMOUNT_UNITS]
CAPACITY_UNITS = [f"{a}/{b}" for b in units.SOLID_BASES for a in ("meq", "mmol")]
STATE_SOURCES = ("Fresh column", "Final state of the last run", "Load column profile")
MT_METHODS = ("Direct input", "Correlation estimate")

TABLE_KEYS = ("binding", "mass_transfer", "reactions", "initial", "inlet", "injection")
COMP_KEY = re.compile(r"comp_\d+_")                                   # every key of a component row (incl. its button)

# Table columns
INLET_FIXED = ["start [min]", "shape"]
GIEX_PH = {"a": ("a1", "a2", "a3"), "d": ("d1", "d2", "d3"), "n": ("n1", "n2", "n3")}
GIEX_ADV = ("ka_salt", "kd_salt", "ka_prot", "kd_prot")
BINDING_DEFAULTS = {"K": 1.0, "qmax": 1.0, "ka": 1.0, "kd": 1.0, "sigma": 0.0,
                    **{c: 0.0 for cols in GIEX_PH.values() for c in cols}, **{c: 0.0 for c in GIEX_ADV},
                    "n": 1.0, "k_ldf": 1.0, "p": 1.0,                 # Freundlich n and k_LDF; Anti-Langmuir sign
                    "K2": 1.0, "qmax2": 1.0, "ka2": 1.0, "kd2": 1.0}  # Bi-Langmuir second site
KF, KEFF, DP, DM, VA = "kf [cm/min]", "keff [cm/min]", "Dp [cm²/min]", "Dm [cm²/min]", "V_A [cm³/mol]"
MT_DEFAULTS = {KF: 0.06, KEFF: 0.03, DP: 1e-4, DM: 6e-4, VA: 30.0}

# Allowed ranges of the numeric widgets: key -> (min, max, label)
BOUNDS = {
    "col_L": (0.01, None, "Column length"), "col_D": (0.01, None, "Column diameter"),
    "col_eps_b": (0.01, 0.99, "Bed porosity"), "col_eps_p": (0.0, 0.99, "Particle porosity"),
    "col_eps_t": (0.01, 0.99, "Total porosity"), "col_R": (0.01, None, "Particle radius"),
    "resin_density": (0.001, None, "Resin density"), "giex_capacity": (0.0, None, "Capacity"),
    "giex_cref": (1e-12, None, "c_ref"), "giex_qref": (1e-12, None, "q_ref"),
    "mt_Eb": (0.0, None, "Axial dispersion"), "mt_mu": (1e-4, None, "Viscosity"),
    "mt_rho": (1e-3, None, "Density"), "op_Q": (1e-6, None, "Flow rate"), "op_Vd": (0.0, None, "Dead volume"),
    "inj_volume": (1e-6, None, "Injection volume"), "inj_start": (0.0, None, "Injection start"),
    "sim_T": (0.01, None, "Total time"), "sim_dt": (1e-4, None, "Output interval"),
    "sim_ncol": (4, None, "Axial cells"), "sim_npar": (1, None, "Particle cells"),
    "sim_timeout": (1.0, None, "Max computation time"),
}


def reaction_table(rows=()):
    """Reaction table with explicit column types (an empty table must stay text/number)."""
    df = pd.DataFrame(list(rows), columns=["equation", "k+", "k−"])
    return df.astype({"equation": "string", "k+": float, "k−": float})


def component_state(i, comp):
    """Widget values of one component row."""
    return {f"comp_{i}_name": comp.name, f"comp_{i}_mw": comp.mw, f"comp_{i}_charge": comp.charge,
            f"comp_{i}_bound": bool(comp.bound), f"comp_{i}_lu": comp.liquid_unit, f"comp_{i}_su": comp.solid_unit}


def _num(v, default=np.nan):
    return default if v is None or (isinstance(v, float) and math.isnan(v)) else v


def inlet_dataframe(segments, names):
    """Inlet table (start, shape, one column per component) from inlet segments.

    The form can show step and linear rows (``mb.inlet_from_table``); anything else
    (quadratic or cubic segments, a ramp that does not end at the next row's value)
    raises ``ValueError``.
    """
    starts, shapes, concs = [], [], []
    for seg in segments:
        polys = [list(p) + [0.0] * (4 - len(p)) for p in seg.coefficients]
        starts.append(seg.start)
        concs.append([p[0] for p in polys])
        shapes.append("linear" if any(p[1] != 0 for p in polys) else "step")
    rebuilt = mb.inlet_from_table(starts, shapes, concs)
    for new, old in zip(rebuilt, segments):
        a = np.array([list(p) + [0.0] * (4 - len(p)) for p in old.coefficients], dtype=float)
        if new.start != old.start or not np.allclose(np.array(new.coefficients, dtype=float), a, rtol=1e-12, atol=0):
            raise ValueError("the inlet program has quadratic/cubic segments or ramps that do not end at the "
                             "next row's concentration; the inlet table can only show step and linear rows")
    data = {"start [min]": starts, "shape": shapes}
    data.update({name: [row[i] for row in concs] for i, name in enumerate(names)})
    return pd.DataFrame(data)


def _check_components(comps, model):
    for c in comps:
        if not c.name or not str(c.name).strip():
            raise ValueError("a component has no name")
    n_mod = mb.modulator_count(model)
    if n_mod:
        needs_ph = n_mod == 2
        if (len(comps) < n_mod + 1 or not comps[0].bound
                or (needs_ph and (comps[1].bound or comps[1].liquid_unit != units.MODULATOR_UNIT))):
            raise ValueError(f"a {model} input needs salt (adsorbing)"
                             + (" and pH (unit 'pH')" if needs_ph else "") + " as its first "
                             + ("two components" if needs_ph else "component") + ", followed by at least one solute")
        if comps[0].liquid_unit not in SALT_UNITS:
            raise ValueError(f"the salt unit {comps[0].liquid_unit!r} is not supported (use {SALT_UNITS})")
    solutes = comps[n_mod:]
    names = [c.name for c in solutes]
    if len(set(names)) != len(names):
        raise ValueError("component names must be unique")
    reserved = [SALT_NAME, PH_NAME][:n_mod]
    for c in solutes:
        if c.name in reserved:
            raise ValueError(f"the name {c.name!r} is reserved for {model}")
        if c.liquid_unit not in LIQUID_UNITS:
            raise ValueError(f"component {c.name!r}: liquid unit {c.liquid_unit!r} is not available "
                             f"('pH' is only for the GIEX modulator)")
        if c.solid_unit not in SOLID_UNITS:
            raise ValueError(f"component {c.name!r}: unknown solid unit {c.solid_unit!r}")


def _check_bounds(state):
    for key, (lo, hi, label) in BOUNDS.items():
        v = state.get(key)
        if v is None:
            continue
        if (lo is not None and v < lo) or (hi is not None and v > hi):
            raise ValueError(f"{label} = {v:g} is outside the allowed range "
                             f"[{'-∞' if lo is None else format(lo, 'g')}, {'∞' if hi is None else format(hi, 'g')}]")


def spec_to_state(spec):
    """``(state, notes)`` that make the form show ``spec``; raises ``ValueError`` if it cannot."""
    comps, col, b, op, sim = spec.components, spec.column, spec.binding, spec.operation, spec.settings
    giex = b.model == "GIEX"
    _check_components(comps, b.model)
    k = mb.modulator_count(b.model)
    solutes = comps[k:]
    ns = len(solutes)
    solute_names = [c.name for c in solutes]
    names = [SALT_NAME, PH_NAME][:k] + solute_names
    n_all = len(names)
    notes = []
    if spec.initial_state_source:
        notes.append(f"The original run started from a saved column profile ({spec.initial_state_source}); "
                     "the form starts from a fresh column.")

    s = {"form_title": spec.title or "", "comp_ids": list(range(ns)), "comp_next": ns,
         "giex_salt_unit": comps[0].liquid_unit if k else SALT_UNITS[0]}
    for i, c in enumerate(solutes):
        s.update(component_state(i, c))

    # column
    s.update(col_model=col.model, col_L=float(col.length), col_D=float(col.diameter), col_eps_b=float(col.eps_b),
             col_eps_p=float(col.eps_p), col_R=float(col.radius),
             col_eps_t_manual=col.eps_t is not None,
             col_eps_t=float(col.eps_t if col.eps_t is not None else units.total_porosity(col.eps_b, col.eps_p)),
             resin_density_basis=col.density_basis,
             resin_density=float(col.resin_density) if col.resin_density else 1.2)

    # binding
    g = b.giex
    s.update(binding_model=b.model, binding_kinetic=bool(b.kinetic) and col.model != "LRM_keff",
             giex_capacity=float(g.capacity) if g else 1.2,
             giex_capacity_unit=g.capacity_unit if g else CAPACITY_UNITS[0],
             giex_cref=float(g.reference_liquid) if g else 100.0, giex_ph_ref=float(g.ph_ref) if g else 7.0,
             giex_qref_is_capacity=g is None or g.reference_solid is None,
             giex_qref=float(g.reference_solid if g and g.reference_solid is not None
                             else (g.capacity if g else 1.2)))
    if g and g.capacity_unit not in CAPACITY_UNITS:
        raise ValueError(f"unknown capacity unit {g.capacity_unit!r}")

    def column_values(values, default, i_off=k):
        if values is None:
            return [default] * ns
        return [_num(values[i_off + i]) if i_off + i < len(values) else np.nan for i in range(ns)]

    def triples(values):
        out = []
        for i in range(ns):
            t = values[k + i] if values is not None and k + i < len(values) else None
            out.append(list(t) + [0.0] * (3 - len(t)) if t is not None else [0.0, 0.0, 0.0])
        return out

    bt = {"K": column_values(b.equilibrium, BINDING_DEFAULTS["K"]),
          "qmax": column_values(b.capacity, BINDING_DEFAULTS["qmax"]),
          "ka": column_values(b.adsorption_rate, BINDING_DEFAULTS["ka"]),
          "kd": column_values(b.desorption_rate, BINDING_DEFAULTS["kd"]),
          "sigma": column_values(g.steric_factor if g else None, 0.0)}
    for key, field in (("a", "adsorption_ph"), ("d", "desorption_ph"), ("n", "charge_ph")):
        t = triples(getattr(g, field) if g else None)
        for j, name in enumerate(GIEX_PH[key]):
            bt[name] = [row[j] for row in t]
    for name, field in zip(GIEX_ADV, ("adsorption_salt", "desorption_salt", "adsorption_protein",
                                      "desorption_protein")):
        bt[name] = column_values(getattr(g, field) if g else None, 0.0)
    bt["n"] = column_values(b.exponent, BINDING_DEFAULTS["n"])
    bt["k_ldf"] = column_values(b.ldf_rate, BINDING_DEFAULTS["k_ldf"])
    bt["p"] = column_values(b.sign, BINDING_DEFAULTS["p"])
    s2 = b.site2
    bt["K2"] = column_values(s2.equilibrium if s2 else None, BINDING_DEFAULTS["K2"])
    bt["qmax2"] = column_values(s2.capacity if s2 else None, BINDING_DEFAULTS["qmax2"])
    bt["ka2"] = column_values(s2.adsorption_rate if s2 else None, BINDING_DEFAULTS["ka2"])
    bt["kd2"] = column_values(s2.desorption_rate if s2 else None, BINDING_DEFAULTS["kd2"])
    s["giex_advanced"] = any(v not in (0.0, None) and v == v for name in GIEX_ADV for v in bt[name])
    s["binding"] = pd.DataFrame(bt, index=solute_names)

    # reactions
    rxs = spec.reactions
    s["rx_enabled"] = bool(rxs and rxs.reactions)
    s["rx_basis"] = rxs.basis if rxs else "mol/L"
    s["reactions"] = reaction_table([(r.equation, r.k_fwd, r.k_bwd) for r in rxs.reactions] if rxs else [])

    # mass transfer
    cor = spec.correlation
    glueckauf = bool(cor and cor.keff_from_glueckauf)
    s.update(mt_method=MT_METHODS[1] if cor else MT_METHODS[0], mt_Eb=float(col.axial_dispersion),
             mt_mu=float(cor.viscosity) if cor else 0.89, mt_rho=float(cor.density) if cor else 0.997,
             mt_glueckauf=glueckauf if cor else True, mt_T=float(cor.temperature) if cor else 25.0)

    def per_comp(values, default):
        if values is None:
            return [default] * n_all
        return [_num(v, np.nan) for v in values] + [np.nan] * (n_all - len(values))

    mt = {c: [v] * n_all for c, v in MT_DEFAULTS.items()}
    film_is_input = not cor or (col.model == "LRM_keff" and not glueckauf)
    if col.film_diffusion is not None and film_is_input and col.model in ("GRM", "LRMP", "LRM_keff"):
        mt[KEFF if col.model == "LRM_keff" else KF] = per_comp(col.film_diffusion, MT_DEFAULTS[KF])
    pore = (cor.pore_diffusion if cor and cor.pore_diffusion is not None else col.pore_diffusion)
    if pore is not None:
        mt[DP] = per_comp(pore, MT_DEFAULTS[DP])
    if cor and cor.molecular_diffusion is not None:
        mt[DM] = per_comp(cor.molecular_diffusion, MT_DEFAULTS[DM])
    if cor and cor.molar_volume is not None:
        mt[VA] = per_comp(cor.molar_volume, MT_DEFAULTS[VA])
    s["mass_transfer"] = pd.DataFrame(mt, index=names)

    # inlet / process
    s.update(op_Q=float(op.flow_rate), op_ecv=bool(op.dead_volume and op.dead_volume > 0),
             op_Vd=float(op.dead_volume) if op.dead_volume and op.dead_volume > 0 else 0.1)
    try:
        s["inlet"] = inlet_dataframe(op.inlet, names)
    except ValueError as e:
        raise ValueError(str(e)) from None

    # injection (a pulse laid over the inlet program)
    inj = op.injection
    s.update(inj_enabled=inj is not None, inj_volume=float(inj.volume) if inj else 0.5,
             inj_start=float(inj.start) if inj else 0.0)
    if inj is not None and (inj.feed is None or len(inj.feed) != n_all):
        raise ValueError(f"the injection needs one feed concentration per component ({n_all})")
    feed = ([float(_num(v, 0.0)) for v in inj.feed] if inj is not None
            else [50.0 if n == SALT_NAME else 7.0 if n == PH_NAME else 0.0 for n in names])
    s["injection"] = pd.DataFrame({"feed": feed}, index=names)

    # initial state (always a fresh column: a column profile is not part of an input file)
    liquid = col.initial_liquid if col.initial_liquid is not None else [0.0] * n_all
    solid = col.initial_solid if col.initial_solid is not None else [0.0] * n_all
    s["init_state_source"] = STATE_SOURCES[0]
    s["initial"] = pd.DataFrame({"c0": [float(_num(v, 0.0)) for v in liquid],
                                 "q0": [float(_num(v, 0.0)) for v in solid]}, index=names)

    # simulation
    s.update(sim_T=float(sim.duration), sim_dt=float(sim.output_interval), sim_ncol=int(sim.n_col),
             sim_npar=int(sim.n_par), sim_timeout=float(sim.timeout), sim_tol_mode=sim.tolerance_mode,
             sim_reltol=repr(float(sim.reltol)), sim_abstol=repr(float(sim.abstol)),
             sim_algtol=repr(float(sim.algtol)), sim_weno_eps=repr(float(sim.weno_eps)))
    _check_bounds(s)
    return s, notes


def default_state():
    from core import examples
    return spec_to_state(examples.default())[0]
