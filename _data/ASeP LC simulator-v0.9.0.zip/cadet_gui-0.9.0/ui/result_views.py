"""Result widgets shared by the Batch screen and the results viewer."""
import pandas as pd
import streamlit as st

from datetime import datetime

from core import dimensionless, mass, units
from core.excel_export import build_workbook, export_filename
from ui import plots


def component_selector(result, key):
    """Multiselect of components for the main plots; returns component indices."""
    names = [c.name for c in result.components]
    main, _ = plots.default_components(result)
    default = [names[i] for i in main]
    if key not in st.session_state or not set(st.session_state[key]) <= set(names):
        st.session_state[key] = default
    chosen = st.multiselect("Components shown", names, key=key)
    return [i for i, n in enumerate(names) if n in chosen]


def modifier_plots(result, t=None):
    """Salt and pH outlet traces, each on its own axis (GIEX)."""
    _, modifiers = plots.default_components(result)
    if not modifiers:
        return
    for col, i in zip(st.columns(len(modifiers)), modifiers):
        col.plotly_chart(plots.modifier_trace(result, i, t), width="stretch")


def summary_panel(result, key):
    """Simulation summary, per-component amounts, dimensionless groups and checks."""
    s = result.summary
    c = st.columns(3)
    c[0].metric("Computation time", f"{s.get('time_elapsed_s', float('nan')):.2f} s")
    c[1].metric("Output points", f"{len(result.time):,}")
    c[2].metric("Status", "OK" if s.get("exit_flag") == 0 else f"exit {s.get('exit_flag')}")
    reactions = len(result.spec.reactions.reactions) if result.spec.reactions else 0
    st.caption(f"Column {result.spec.column.model} · binding {result.spec.binding.model} · "
               f"{len(result.components)} components · {reactions} reactions · "
               f"dead volume {result.spec.operation.dead_volume:g} mL")

    st.markdown("**Per-component amount** (input = ∫C_in·Q dt, output = ∫C_out·Q dt)")
    unit = st.selectbox("Amount unit", [mass.AUTO, *units.AMOUNT_UNITS], key=f"{key}_amount_unit")
    st.dataframe(mass.mass_table(result, unit).style.format({"input": "{:.4g}", "output": "{:.4g}"}),
                 width="stretch")

    spec = result.spec
    values = dimensionless.groups(spec.column, spec.operation.flow_rate, len(spec.components))
    names = [c.name for c in spec.components]
    st.markdown("**Dimensionless groups**")
    st.dataframe(pd.DataFrame(values, index=names).style.format("{:.3g}"), width="stretch")
    for message in dimensionless.diagnose(values, names):
        st.caption(message)
    if spec.reactions is not None:
        try:
            rows = dimensionless.reaction_groups(spec)
            st.dataframe(pd.DataFrame(rows).set_index("reaction").style.format(
                {"Nk+": "{:.3g}", "Nk−": "{:.3g}", "Nk+/Nk−": "{:.3g}"}), width="stretch")
        except ValueError as e:      # e.g. a result file from an older version without k+/k−
            st.caption(f"Reaction numbers unavailable: {e}")

    st.markdown("**Numerical checks**")
    st.dataframe(mass.numerical_checks(result).style.format({"negative undershoot / peak": "{:.2e}"}),
                 width="stretch")
    st.caption("CADET-Core 5.1.1 does not report step counts or error-test / Newton failures; NaNs and "
               "negative undershoot of the outlet are shown instead. Large undershoot suggests more axial cells.")


XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


def excel_button(result, key):
    """Excel workbook download with a checkbox for the column-profile sheets (off by default: they are large
    and rarely needed). The workbook is built once per result and option, since the page reruns on every
    interaction."""
    c1, c2 = st.columns([2, 3], vertical_alignment="center")
    include = c2.checkbox("Include column profiles (bulk / pore / solid)", key=f"{key}_xlsx_profiles",
                          help="Adds the concentrations along the column at 21 times as extra sheets.")
    cached = st.session_state.get(f"{key}_xlsx")
    if cached is None or cached[0] is not result or cached[1] != include:
        created = datetime.now()
        cached = (result, include, build_workbook(result, include_profiles=include, created=created),
                  export_filename(result, created))
        st.session_state[f"{key}_xlsx"] = cached
    c1.download_button(
        "📊 Excel workbook (all data)", cached[2], cached[3], XLSX_MIME, key=f"{key}_xlsx_button",
        help="One file: Summary (title, dates, inputs, mass-transfer coefficients, dimensionless numbers, "
             "results), Data (time, inlet and outlet columns for plotting), Charts and every input parameter.")
