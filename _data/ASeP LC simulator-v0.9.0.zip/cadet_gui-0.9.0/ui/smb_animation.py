"""SMB process animation: the columns stay in place, the ports move one column every switch.

A self-contained HTML/SVG/JS snippet (shown with ``st.iframe``): a timeline bar over one
cycle with a moving cursor, play / pause, previous / next switch and a time slider over the whole run.
"""
import json

from core import smb

ZONE_COLORS = {"I": ("#EEEDFE", "#534AB7"), "II": ("#E1F5EE", "#0F6E56"), "III": ("#FAECE7", "#993C1D"),
               "IV": ("#F1EFE8", "#5F5E5A"), "V": ("#FAEEDA", "#854F0B")}
PORT_COLORS = {"eluent": "#1D9E75", "feed": "#D85A30", "extract": "#7F77DD", "extract_1": "#7F77DD",
               "extract_2": "#D4537E", "raffinate": "#BA7517", smb.WASTE: "#888780"}


HEIGHT = 360        # px of the iframe: controls + readout + the 270 px drawing


def config(spec: smb.SMBSpec, total_time):
    """Numbers for the drawing. Port ``pos``: inlets enter the column at that ring position; outlets take the
    outlet of the column just before it (an open layout's end outlet: of the last column, pos = n)."""
    f = smb.flow_set(spec)
    layout = spec.geometry
    kinds = {name: kind for kind, name in layout.nodes}
    positions = smb.port_positions(spec)
    ports = [{"name": name, "label": smb.STREAM_LABELS[name].capitalize(),
              "kind": kinds.get(name, "out"), "pos": positions[name], "flow": f.ports[name]}
             for name in list(positions)]
    return {"n": spec.n_columns, "ts": spec.switch_time, "total": float(total_time), "closed": layout.closed,
            "zones": smb.zone_of_position(spec), "ports": ports,
            "zoneColors": ZONE_COLORS, "portColors": PORT_COLORS}


def process_html(spec: smb.SMBSpec, total_time=None):
    cfg = json.dumps(config(spec, total_time or spec.cycle_time))
    return """
<div style="font-family: sans-serif; color: #31333F;">
<div style="display:flex;align-items:center;gap:8px">
  <button id="prev" title="Previous switch">⏮</button>
  <button id="play" title="Play">▶</button>
  <button id="next" title="Next switch">⏭</button>
  <input type="range" id="t" min="0" step="0.01" style="flex:1">
  <select id="spd" title="Speed"><option value="0.5">0.5×</option><option value="1" selected>1×</option>
    <option value="3">3×</option><option value="10">10×</option></select>
</div>
<div id="ro" style="font-size:13px;color:#5F5E5A;margin:6px 0 2px"></div>
<svg id="fs" viewBox="0 0 760 270" preserveAspectRatio="xMidYMin meet" role="img"
     aria-label="SMB layout at the current time" style="display:block;width:100%;height:270px"></svg>
</div>
<style>
html,body{margin:0}
button{border:1px solid #c9c8c2;background:#fff;border-radius:6px;width:34px;height:30px;cursor:pointer}
.flow{stroke-dasharray:7 5;animation:dash .9s linear infinite}
@keyframes dash{to{stroke-dashoffset:-12}}
</style>
<script>
const C = """ + cfg + """;
const n = C.n, ts = C.ts, cycle = n * ts, total = C.total;
const W = 760, X0 = 70, X1 = 690, gap = Math.max(10, Math.min(26, 120 / n));
const cw = (X1 - X0 - gap * (n - 1)) / n, yTop = 150, ch = 40;
const svg = document.getElementById('fs');
const slider = document.getElementById('t');
slider.max = total;
let t = 0, playing = false, last = null, shown = -1;
const colX = c => X0 + c * (cw + gap);
const jointX = c => c === 0 ? X0 - gap / 2 - 4 : colX(c) - gap / 2;
function arrowDefs() {
  let d = '<defs>';
  for (const [k, col] of Object.entries(C.portColors).concat([['ring', '#888780']]))
    d += `<marker id="m_${k}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0,0L10,5L0,10z" fill="${col}"/></marker>`;
  return d + '</defs>';
}
function timeline(state) {
  let h = '';
  const w = (X1 - X0) / n;
  for (let s = 0; s < n; s++) {
    const on = s === state;
    h += `<rect x="${X0 + s * w + 1}" y="22" width="${w - 2}" height="18" rx="3" fill="${on ? '#EEEDFE' : '#F1EFE8'}" stroke="${on ? '#534AB7' : '#D3D1C7'}"/>`;
    h += `<text x="${X0 + s * w + w / 2}" y="35" font-size="11" text-anchor="middle" fill="#444441">switch ${s + 1}</text>`;
  }
  h += `<g id="cur"><line x1="0" y1="18" x2="0" y2="44" stroke="#D85A30" stroke-width="2.5"/><path d="M-5,16L5,16L0,22z" fill="#D85A30"/></g>`;
  h += `<text id="cyc" x="${X0}" y="13" font-size="12" fill="#444441"></text>`;
  return h;
}
function label(x, y, col, text) {     // right-aligned near the right edge so it is not cut off
  const right = x > W - 150;
  return `<text x="${right ? x - 4 : x + 4}" y="${y}" font-size="12" fill="${col}" text-anchor="${right ? 'end' : 'start'}">${text}</text>`;
}
function draw(state) {
  let h = arrowDefs() + timeline(state);
  const pos = c => ((c - state) % n + n) % n;              // ring position of physical column c
  const atRing = p => ((p + state) % n + n) % n;           // physical column at ring position p
  const broken = C.closed ? -1 : atRing(n - 1);            // open layouts: no flow out of the last ring column
  for (let c = 0; c < n; c++) {
    const z = C.zones[pos(c)], [fill, stroke] = C.zoneColors[z];
    h += `<rect x="${colX(c)}" y="${yTop}" width="${cw}" height="${ch}" rx="5" fill="${fill}" stroke="${stroke}"/>`;
    h += `<text x="${colX(c) + cw / 2}" y="${yTop + 17}" font-size="12" text-anchor="middle" fill="${stroke}">col ${c + 1}</text>`;
    h += `<text x="${colX(c) + cw / 2}" y="${yTop + 32}" font-size="11" text-anchor="middle" fill="${stroke}">zone ${z}</text>`;
    if (c < n - 1 && c !== broken)
      h += `<path class="flow" d="M${colX(c) + cw},${yTop + ch / 2}H${colX(c + 1) - 2}" stroke="#888780" stroke-width="2" fill="none" marker-end="url(#m_ring)"/>`;
  }
  const yb = yTop + ch + 74;
  if (n - 1 !== broken)       // last physical column back to the first
    h += `<path class="flow" d="M${colX(n - 1) + cw},${yTop + ch / 2}H${X1 + 14}V${yb}H${X0 - 20}V${yTop + ch / 2}H${X0 - 2}" stroke="#888780" stroke-width="2" fill="none" marker-end="url(#m_ring)"/>`;
  let nIn = 0, nOut = 0;
  for (const p of C.ports) {
    const col = C.portColors[p.name] || '#888780', q = p.flow.toFixed(3);
    if (p.kind === 'in') {
      const c = atRing(p.pos), x = c === 0 ? X0 - 4 : colX(c) - 4, y = 70 + 24 * nIn++;
      h += `<path class="flow" d="M${x},${y}V${yTop + ch / 2 - 6}" stroke="${col}" stroke-width="2.5" fill="none" marker-end="url(#m_${p.name})"/>`;
      h += label(x, y - 4, col, `${p.label} ${q} mL/min`);
    } else {
      const c = atRing(p.pos - 1), x = colX(c) + cw + 5, y = yTop + ch + 20 + 16 * nOut++;
      h += `<path class="flow" d="M${x},${yTop + ch / 2 + 4}V${y}" stroke="${col}" stroke-width="2.5" fill="none" marker-end="url(#m_${p.name})"/>`;
      h += label(x, y + 12, col, `${p.label} ${q} mL/min`);
    }
  }
  svg.innerHTML = h;
}
function render() {
  const tc = Math.min(t, total - 1e-9);
  const state = Math.floor((tc % cycle) / ts + 1e-9) % n;
  if (state !== shown) { draw(state); shown = state; }
  const cur = document.getElementById('cur');
  cur.setAttribute('transform', `translate(${X0 + (X1 - X0) * ((tc % cycle) / cycle)},0)`);
  document.getElementById('cyc').textContent = `cycle ${Math.floor(tc / cycle) + 1} of ${Math.max(1, Math.round(total / cycle))}`;
  slider.value = t;
  document.getElementById('ro').textContent = `t = ${t.toFixed(2)} min · switch ${state + 1} of ${n} · ` +
    C.ports.map(p => p.kind === 'in' ? `${p.label.toLowerCase()} into col ${(p.pos + state) % n + 1}`
                                     : `${p.label.toLowerCase()} from col ${((p.pos - 1 + state) % n + n) % n + 1}`).join(', ');
}
function setPlay(v) { playing = v; document.getElementById('play').textContent = v ? '⏸' : '▶'; last = null; if (v) requestAnimationFrame(loop); }
function loop(now) {
  if (!playing) return;
  if (last !== null) {
    t += (now - last) / 1000 * ts / 2 * Number(document.getElementById('spd').value);   // 1× = one switch per 2 s
    if (t >= total) { t = total; render(); setPlay(false); return; }
  }
  last = now; render(); requestAnimationFrame(loop);
}
document.getElementById('play').onclick = () => { if (t >= total) t = 0; setPlay(!playing); };
document.getElementById('next').onclick = () => { t = Math.min(total, (Math.floor(t / ts + 1e-9) + 1) * ts); render(); };
document.getElementById('prev').onclick = () => { const k = Math.ceil(t / ts - 1e-9) - 1; t = Math.max(0, k * ts); render(); };
slider.oninput = e => { t = Number(e.target.value); render(); };
render();
</script>
"""
