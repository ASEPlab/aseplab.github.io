"""Batch screen input form (spec §6): one scrolling page, sections from top to bottom.

``render()`` draws the form and returns ``(spec, error, initial_state)``. The form's
whole state lives in ``st.session_state`` (see ``ui.form_state``), so loading an input
file, an example or the defaults just replaces that state.
"""
import itertools
import math
import string

import pandas as pd
import streamlit as st

from core import correlations, dimensionless, examples, tolerances, units
from core import model_builder as mb
from core import reactions as rx
from core.components import Component, modulators
from core.naming import file_stem
from ui import form_state as fs
from ui import plots, tables
from utils import input_files, state_manager

BINDING_LABELS = {
    "None": "None (no adsorption)", "Linear": "Linear", "Langmuir": "Langmuir (competitive, multi-component)",
    "AntiLangmuir": "Anti-Langmuir", "BiLangmuir": "Bi-Langmuir (dual site)", "Freundlich": "Freundlich",
    "SMA": "SMA (steric mass action)", "GIEX": "GIEX (SMA with pH)",
}
MODEL_LABELS = {
    "GRM": "GRM — general rate",
    "LRMP": "LRMP — lumped rate with pores",
    "LRM_keff": "LRM (keff) — lumped mass transfer",
    "LRM": "LRM (CADET original) — no pores, kinetic binding",
}
NUM = "%g"
SECTIONS = ("Components", "Column", "Binding", "Reactions", "Mass transfer", "Inlet / process", "Initial state",
            "Simulation")
COMP_WIDTHS = [2.2, 1.6, 2.3, 1.0, 1.3, 1.2, 0.6]      # name, units, adsorbs, MW, charge, remove
REACTION_PH_NOTE = "Reactions cannot involve the pH modulator."
# Keep every form widget's value for the whole session: while a widget is not drawn (the GIEX fields with another
# binding model, ...) and while another page runs (Streamlit otherwise forgets them). Needs Streamlit >= 1.64.
_P = {"persist_state": "session"}


def _opt(value):
    return None if value is None or (isinstance(value, float) and math.isnan(value)) else float(value)


# --- Form state: defaults, examples, input files ---------------------------------------

NS_KEY = "_form_ns"     # session key holding the prefix of the form drawn on the current page


def _ns():
    return st.session_state.get(NS_KEY, "")


def _k(name):
    """Session-state key of form field ``name`` on the current page (Batch: no prefix; SMB: "smb_")."""
    return _ns() + name


def use_namespace(prefix):
    """Select the form state the panels read and write (call before drawing them)."""
    st.session_state[NS_KEY] = prefix

def apply_state(state):
    """Replace the whole form state (call before the widgets are drawn, e.g. in a callback)."""
    ns = _ns()
    for key in [k for k in st.session_state if k.startswith(ns) and fs.COMP_KEY.match(k[len(ns):])]:
        del st.session_state[key]
    for key, value in state.items():
        if key in fs.TABLE_KEYS:
            tables.set_table(_k(key), value)
        else:
            st.session_state[_k(key)] = value
    st.session_state[_k("form_ready")] = True


def load_input_into_form(data: bytes, name=""):
    """Fill the form from an input file / run log / result file. Returns True on success; the
    outcome is kept in the form's ``input_msg`` state."""
    label = name or "the file"
    try:
        state, notes = fs.spec_to_state(input_files.load_input(data))
    except (ValueError, OSError, KeyError) as e:
        st.session_state[_k("input_msg")] = ("error", f"Could not load {label}: {e}")
        return False
    apply_state(state)
    text = f"Loaded {label}. " + " ".join(notes)
    st.session_state[_k("input_msg")] = ("warning" if notes else "success", text.strip())
    return True


def _on_input_upload():
    upload = st.session_state.get(_k("input_upload"))
    if upload is not None:
        load_input_into_form(upload.getvalue(), upload.name)


def _load_example():
    name = st.session_state[_k("example_choice")]
    apply_state(fs.spec_to_state(examples.EXAMPLES[name]())[0])
    st.session_state[_k("input_msg")] = ("success", f"Loaded the example “{name}”.")


def _new_simulation():
    """Start over: startup form values, and the previous run's result and viewer state cleared."""
    job = st.session_state.get("batch_job")
    if job is not None and not job.done:
        job.cancel()
    for key in ("batch_job", "batch_result", "batch_error", "batch_log_note", "form_spec", "init_state_cache",
                "batch_components_shown"):
        st.session_state.pop(key, None)
    for key in [k for k in st.session_state if k.startswith("viewer_")]:
        del st.session_state[key]
    apply_state(fs.default_state())
    st.session_state[_k("input_msg")] = ("success", "New simulation: the form is back to its startup values and the "
                                                "previous result is cleared.")


def _init_state():
    if _k("form_ready") not in st.session_state:
        apply_state(fs.default_state())


def _input_bar(container):
    """Load / example / reset controls; returns the slot for the save button."""
    with container:
        st.subheader("Input file")
        st.text_input("Simulation title", key=_k("form_title"), placeholder="e.g. Cu / Ni separation, pH 7, 1 mL/min",
                      help="Names the input file, the Excel workbook and the reports.", **_P)
        c = st.columns([3, 3, 2])
        c[0].file_uploader("Load an input file", type=["json", "h5", "hdf5"], key=_k("input_upload"),
                           on_change=_on_input_upload,
                           help="An input file saved here, a run log (logs/*.json) or a result file (.h5). "
                                "The form fills in automatically.")
        c[1].selectbox("Examples", list(examples.EXAMPLES), key=_k("example_choice"), **_P)
        c[1].button("Load example", on_click=_load_example)
        slot = c[2].container()
        c[2].button("New", on_click=_new_simulation, key=_k("new_simulation"),
                    help="Start a new simulation: the form returns to its startup values and the previous "
                         "result is cleared. Save the input file first if you want to keep it.")
        message = st.session_state.get(_k("input_msg"))
        if message:
            getattr(st, message[0])(message[1])
    return slot


def _save_button(slot, spec):
    if spec is None:
        slot.download_button("💾 Save input file", b"", "cadet_gui_input.json", disabled=True,
                             help="Available when the input is complete.")
    else:
        slot.download_button("💾 Save input file", input_files.save_input(spec),
                             file_stem(spec.title, "cadet_gui_input") + ".json", "application/json", help="The complete input in GUI units. Load it again, or "
                                                      "any run log, to restore this form.")


# --- Components ---------------------------------------------------------------------------

def _add_component():
    ids = st.session_state[_k("comp_ids")]
    used = {st.session_state.get(_k(f"comp_{i}_name")) for i in ids}
    name = next(n for n in itertools.chain(string.ascii_uppercase, (f"C{j}" for j in itertools.count(1)))
                if n not in used)
    new = st.session_state[_k("comp_next")]
    st.session_state[_k("comp_next")] = new + 1
    st.session_state.update({_k(k): v for k, v in fs.component_state(new, Component(name)).items()})
    st.session_state[_k("comp_ids")] = ids + [new]


def _remove_component(i):
    for key in [k for k in st.session_state if k.startswith(_k(f"comp_{i}_"))]:
        del st.session_state[key]
    st.session_state[_k("comp_ids")] = [j for j in st.session_state[_k("comp_ids")] if j != i]


def _components_panel(n_mod):
    """Solute rows with + / −. With SMA / GIEX, also the salt (and pH) components, added automatically."""
    st.caption("One row per solute. MW is needed for g/L, mg/L and mg/g units, charge ν for meq units and SMA / GIEX.")
    modifiers = []
    if n_mod:
        with st.container(border=True):
            c = st.columns([2, 2, 3, 2], vertical_alignment="center")
            c[0].markdown("**salt**  \ncounter-ion, ν = 1")
            salt_unit = c[1].selectbox("Salt unit", fs.SALT_UNITS, key=_k("giex_salt_unit"), **_P)
            capacity_unit = c[2].selectbox("Capacity Λ unit (salt on the resin)", fs.CAPACITY_UNITS,
                                           key=_k("giex_capacity_unit"), **_P)
            if n_mod == 2:
                c[3].markdown("**pH**  \nmodulator, no unit")
            st.caption("Salt" + (" and pH are" if n_mod == 2 else " is") + " added automatically; "
                       + ("they appear" if n_mod == 2 else "it appears")
                       + " in the mass transfer, inlet and initial state tables.")
        modifiers = modulators(n_mod, salt_unit, capacity_unit)

    ids = st.session_state[_k("comp_ids")]
    solutes = []
    for row, i in enumerate(ids):
        vis = "visible" if row == 0 else "collapsed"
        c = st.columns(COMP_WIDTHS, vertical_alignment="bottom")
        name = c[0].text_input("Name", key=_k(f"comp_{i}_name"), label_visibility=vis, **_P)
        liquid_unit = c[1].selectbox("Liquid unit", fs.LIQUID_UNITS, key=_k(f"comp_{i}_lu"), label_visibility=vis, **_P)
        solid_unit = c[2].selectbox("Solid unit", fs.SOLID_UNITS, key=_k(f"comp_{i}_su"), label_visibility=vis, **_P)
        bound = c[3].checkbox("Adsorbs", key=_k(f"comp_{i}_bound"), label_visibility=vis, **_P)
        mw = c[4].number_input("MW [g/mol]", min_value=0.0, value=None, format=NUM, key=_k(f"comp_{i}_mw"),
                               label_visibility=vis, placeholder="optional", **_P)
        charge = c[5].number_input("Charge ν", value=None, format=NUM, key=_k(f"comp_{i}_charge"),
                                   label_visibility=vis, placeholder="optional", **_P)
        c[6].button("−", key=_k(f"comp_{i}_rm"), on_click=_remove_component, args=(i,),
                    disabled=len(ids) == 1, help="Remove this component")
        solutes.append(Component(name.strip(), mw=mw, charge=charge, bound=bound, liquid_unit=liquid_unit,
                                 solid_unit=solid_unit))
    st.button("+ Add component", key=_k("comp_add"), on_click=_add_component)
    return modifiers, solutes


def _unit_error(comps):
    """A mass or equivalent unit needs the component's MW or charge; say which, instead of failing later."""
    for c in comps:
        try:
            c.liquid_factor()
            if c.bound:
                c.solid_factor(eps_t=0.5, eps_p=0.5, density=1.0)   # porosity and density are checked elsewhere
        except ValueError as e:
            return f"Component {c.name!r}: {e}. Fill in the MW / charge of its row, or choose another unit."
    return None


def _name_error(modifiers, solutes):
    names = [c.name for c in solutes]
    if any(not n for n in names):
        return "Every component needs a name."
    if len(set(names)) != len(names):
        return "Component names must be unique."
    reserved = {c.name for c in modifiers} & set(names)
    if reserved:
        return f"The name {sorted(reserved)[0]!r} is used by the SMA / GIEX salt and pH components; choose another."
    return None


# --- Column ---------------------------------------------------------------------------------

def _column_panel():
    c1, c2 = st.columns(2)
    model = c1.radio("Column model", mb.COLUMN_MODELS, format_func=MODEL_LABELS.get, key=_k("col_model"), **_P)
    length = c2.number_input("Length L [cm]", min_value=0.01, format=NUM, key=_k("col_L"), **_P)
    diameter = c2.number_input("Diameter D [cm]", min_value=0.01, format=NUM, key=_k("col_D"), **_P)
    eps_b = c2.number_input("Bed porosity εb", min_value=0.01, max_value=0.99, format=NUM, key=_k("col_eps_b"), **_P)
    eps_p = c2.number_input("Particle porosity εp", min_value=0.0, max_value=0.99, format=NUM, key=_k("col_eps_p"), **_P)
    radius = c2.number_input("Particle radius R [µm]", min_value=0.01, format=NUM, key=_k("col_R"), **_P)
    eps_t = None
    if model == "LRM" and c2.toggle("Set total porosity εt manually", key=_k("col_eps_t_manual"), **_P):
        eps_t = c2.number_input("Total porosity εt", min_value=0.01, max_value=0.99, format=NUM, key=_k("col_eps_t"), **_P)
    else:
        c2.caption(f"εt = εb + (1 − εb)·εp = {units.total_porosity(eps_b, eps_p):.4g}")
    return mb.ColumnSpec(model=model, length=length, diameter=diameter, eps_b=eps_b, eps_p=eps_p,
                         radius=radius, eps_t=eps_t)


def _resin_density(comps, column):
    if not any(c.bound and c.solid_unit.endswith("g resin") for c in comps):
        return
    st.markdown("**Resin density** (needed for per-g-resin units)")
    c1, c2 = st.columns(2)
    column.density_basis = c1.selectbox(
        "Density basis", units.DENSITY_BASES, key=_k("resin_density_basis"),
        format_func={"solid": "skeletal — g/mL solid", "particle": "particle — g/mL particle",
                     "bed": "packing — g/mL bed"}.get, **_P)
    column.resin_density = c2.number_input("Density [g/mL]", min_value=0.001, format=NUM, key=_k("resin_density"), **_P)


# --- Binding --------------------------------------------------------------------------------

def _binding_units(binding, kinetic, comp):
    liq, sol = comp.liquid_unit, comp.solid_unit
    if not comp.bound:
        return "(not adsorbed)"
    if binding == "Freundlich":
        return f"K_F: ({sol})/({liq})^(1/n) · n: –" + (" · k_LDF: 1/min" if kinetic else "")
    if binding in ("Linear", "SMA", "GIEX"):
        units_text = f"ka: ({sol})/({liq})/min · kd: 1/min" if kinetic else f"K: ({sol})/({liq})"
        return units_text + (f" · ν = {comp.charge:g}" if binding in ("SMA", "GIEX") and comp.charge else "")
    langmuir = (f"ka: 1/({liq})/min · kd: 1/min · qmax: {sol}" if kinetic else f"K: 1/({liq}) · qmax: {sol}")
    if binding == "AntiLangmuir":
        return langmuir + " · p: ±1"
    if binding == "BiLangmuir":
        return langmuir + " (site 1; site 2: …2, same units)"
    return langmuir


BINDING_NOTES = {
    "Linear": "q = K·c (K = ka/kd).",
    "Langmuir": "Competitive multi-component Langmuir: all components share the sites, "
                "q_i = qmax_i·K_i·c_i / (1 + Σ K_j·c_j) at equilibrium.",
    "AntiLangmuir": "q_i = qmax_i·K_i·c_i / (1 + Σ p_j·K_j·c_j) at equilibrium. p = +1 is Langmuir; with p = −1 "
                    "that component raises the loading of the others (convex isotherm). With rapid equilibrium "
                    "CADET may not converge when K·c of an anti component is large; use kinetic binding then.",
    "BiLangmuir": "Two independent site types (no exchange between them): site 1 K, qmax and site 2 K2, qmax2; "
                  "the bound amount of a component is the sum over its sites. An initial q₀ is not available.",
    "Freundlich": "q* = K_F·c^(1/n) per component, no competition between components. Kinetic: "
                  "dq/dt = k_LDF·(q* − q) (driving force form).",
    "SMA": "Steric mass action: salt (counter-ion) in front of the solutes; ν is each solute's charge, σ its "
           "steric factor, Λ the capacity.",
}


BINDING_DOCS = "https://cadet.github.io/v5.1.1/modelling/binding/"
BINDING_PAGES = {"Linear": "linear", "Langmuir": "multi_component_langmuir",
                 "AntiLangmuir": "multi_component_anti_langmuir", "BiLangmuir": "multi_component_bi_langmuir",
                 "Freundlich": "freundlich_ldf", "SMA": "steric_mass_action", "GIEX": "generalized_ion_exchange"}


def _ion_exchange_inputs(modifiers, giex):
    """Λ, c_ref, q_ref (SMA and GIEX) and pH_ref (GIEX)."""
    name = "GIEX" if giex else "SMA"
    st.markdown(f"**{name} parameters**")
    st.caption("ν of each solute is its charge; σ" + (" and the pH coefficients are" if giex else " is")
               + " in the table below." + (" A pH gradient is the pH column of the inlet table." if giex else ""))
    c = st.columns(3)
    capacity_unit = modifiers[0].solid_unit
    capacity = c[0].number_input(f"Capacity Λ [{capacity_unit}]", min_value=0.0, format=NUM, key=_k("giex_capacity"), **_P)
    cref = c[1].number_input(f"c_ref [{modifiers[0].liquid_unit}]", min_value=1e-12, format=NUM, key=_k("giex_cref"),
                             help="Reference salt concentration in (c_salt/c_ref)^ν", **_P)
    if giex:
        ph_ref = c[2].number_input("pH_ref", format=NUM, key=_k("giex_ph_ref"),
                                   help="pH coefficients are per power of x = pH − pH_ref", **_P)
    else:
        ph_ref = float(st.session_state[_k("giex_ph_ref")])        # not used by SMA; kept for the input file
    q_is_cap = st.toggle("q_ref = Λ", key=_k("giex_qref_is_capacity"), **_P)
    qref = None if q_is_cap else st.number_input(f"q_ref [{capacity_unit}]", min_value=1e-12, format=NUM,
                                                 key=_k("giex_qref"), **_P)
    advanced = giex and st.toggle("Show salt / protein exponent coefficients", key=_k("giex_advanced"), **_P)
    return dict(capacity=capacity, capacity_unit=capacity_unit, reference_liquid=cref, reference_solid=qref,
                ph_ref=ph_ref), advanced


def _rows(df, columns):
    """Per-row lists of ``columns`` with blanks as 0 (pH polynomial coefficients)."""
    return [list(r) for r in df[list(columns)].astype(float).fillna(0.0).itertuples(index=False)]


def _binding_columns(binding, kinetic, advanced):
    """Binding table columns shown for a model."""
    if binding == "Freundlich":
        return ["K", "n"] + (["k_ldf"] if kinetic else [])
    cols = ["ka", "kd"] if kinetic else ["K"]
    if binding in ("Langmuir", "AntiLangmuir", "BiLangmuir"):
        cols.append("qmax")
    if binding == "AntiLangmuir":
        cols.append("p")
    if binding == "BiLangmuir":
        cols += (["ka2", "kd2"] if kinetic else ["K2"]) + ["qmax2"]
    if binding in ("SMA", "GIEX"):
        cols.append("sigma")
    if binding == "GIEX":
        cols += [*fs.GIEX_PH["a"], *(fs.GIEX_PH["d"] if kinetic else ()), *fs.GIEX_PH["n"]]
        if advanced:
            cols += list(fs.GIEX_ADV)
    return cols


def _binding_panel(modifiers, solutes, model):
    k = len(modifiers)
    c1, c2 = st.columns([1, 2])
    binding = c1.radio("Binding model", mb.BINDING_MODELS, format_func=BINDING_LABELS.get, key=_k("binding_model"), **_P)
    if binding == "None":
        return mb.BindingSpec("None")
    if model == "LRM_keff":
        kinetic = False
        c2.caption("LRM (keff) uses rapid-equilibrium binding; mass transfer is in keff.")
    else:
        kinetic = c2.toggle("Kinetic binding (k_LDF)" if binding == "Freundlich" else "Kinetic binding (ka, kd)",
                            key=_k("binding_kinetic"), **_P)
    if binding in BINDING_NOTES:
        c2.caption(BINDING_NOTES[binding] + f" [CADET documentation]({BINDING_DOCS}{BINDING_PAGES[binding]}.html)")
    giex_inputs, advanced = _ion_exchange_inputs(modifiers, binding == "GIEX") if k else (None, False)

    tables.sync_index(_k("binding"), [c.name for c in solutes], fs.BINDING_DEFAULTS)
    shown = _binding_columns(binding, kinetic, advanced)
    by_name = {c.name: c for c in solutes}

    def decorate(df):
        out = df.copy()
        out["units"] = [_binding_units(binding, kinetic, by_name[n]) for n in out.index]
        return out

    k_label = "ln ka" if kinetic else "ln K"
    labels = {"sigma": "σ", "a1": f"{k_label}·x", "a2": f"{k_label}·x²", "a3": f"{k_label}·x³",
              "d1": "ln kd·x", "d2": "ln kd·x²", "d3": "ln kd·x³", "n1": "ν·x", "n2": "ν·x²", "n3": "ν·x³",
              "K": "K_F" if binding == "Freundlich" else "K", "k_ldf": "k_LDF", "p": "p (±1)"}
    df = tables.editable_table(_k("binding"), decorate=decorate, column_order=shown + ["units"], disabled=["units"],
        column_config={c: st.column_config.NumberColumn(labels.get(c, c), format=NUM) for c in fs.BINDING_DEFAULTS})
    if binding == "GIEX":
        st.caption("x = pH − pH_ref. ln K (or ln ka, ln kd) and ν are polynomials in x; "
                   "ka_salt/kd_salt are per salt liquid unit, ka_prot/kd_prot per the component's own unit.")
    pad = [None] * k                                   # salt and pH have no isotherm parameters
    col = lambda key: pad + [_opt(v) for v in df[key]]  # noqa: E731
    giex = None
    if binding == "GIEX":
        giex = mb.GiexSpec(**giex_inputs, steric_factor=col("sigma"),
                           adsorption_ph=pad + _rows(df, fs.GIEX_PH["a"]),
                           desorption_ph=pad + _rows(df, fs.GIEX_PH["d"]),
                           charge_ph=pad + _rows(df, fs.GIEX_PH["n"]),
                           adsorption_salt=col("ka_salt"), desorption_salt=col("kd_salt"),
                           adsorption_protein=col("ka_prot"), desorption_protein=col("kd_prot"))
    elif binding == "SMA":
        giex = mb.GiexSpec(**giex_inputs, steric_factor=col("sigma"))
    spec = mb.BindingSpec(model=binding, kinetic=kinetic, equilibrium=col("K"), capacity=col("qmax"),
                          adsorption_rate=col("ka"), desorption_rate=col("kd"), giex=giex)
    if binding == "Freundlich":
        spec.exponent, spec.ldf_rate = col("n"), col("k_ldf")
    if binding == "AntiLangmuir":
        spec.sign = col("p")
    if binding == "BiLangmuir":
        spec.site2 = mb.SecondSite(equilibrium=col("K2"), capacity=col("qmax2"), adsorption_rate=col("ka2"),
                                   desorption_rate=col("kd2"))
    return spec


# --- Reactions ------------------------------------------------------------------------------

def _reactions_panel(names):
    if not st.toggle("Include mobile-phase reactions", key=_k("rx_enabled"),
                     help="Mass-action reactions between the components, in the bulk and the pore liquid.", **_P):
        return None
    st.caption("Write e.g. 'M1 + L = M1L' or 'M + B-C = B-M + C'; a coefficient is a number and a space "
               "('2 L'). Enter the forward and backward rate constants k+ and k−; Ka = k+/k− is shown. "
               + REACTION_PH_NOTE)
    basis = st.selectbox("Rate-constant concentration basis", rx.REACTION_BASES, key=_k("rx_basis"),
                         help="Independent of the components' display units.", **_P)

    def decorate(df):
        out = df.copy()
        out["Ka"] = [kf / kb if pd.notna(kf) and pd.notna(kb) and kb else None
                     for kf, kb in zip(out["k+"], out["k−"])]
        out["units"] = [rx.units_text(e, names, basis) if isinstance(e, str) and e.strip() else ""
                        for e in out["equation"]]
        return out

    df = tables.editable_table(_k("reactions"), decorate=decorate, num_rows="dynamic", hide_index=True, disabled=["Ka", "units"],
        column_config={
            "equation": st.column_config.TextColumn(width="medium"),
            "k+": st.column_config.NumberColumn(format=NUM, min_value=0.0),
            "k−": st.column_config.NumberColumn(format=NUM, min_value=0.0),
            "Ka": st.column_config.NumberColumn("Ka = k+/k−", format=NUM),
            "units": st.column_config.TextColumn(width="large"),
        },
    )
    reactions = [
        rx.ReactionSpec(row["equation"].strip(), k_fwd=_opt(row["k+"]), k_bwd=_opt(row["k−"]))
        for _, row in df.iterrows()
        if isinstance(row["equation"], str) and row["equation"].strip()
    ]
    if not reactions:
        st.info("No reaction entered yet; add rows to the table (the last row adds a new one).")
    return rx.ReactionSystem(basis, reactions) if reactions else None


def _reaction_preview(spec):
    if spec.reactions is None:
        return
    try:
        rows = dimensionless.reaction_groups(spec)
    except ValueError as e:
        st.error(str(e))
        return
    st.markdown("**Reaction numbers** (C = largest inlet reactant concentration)")
    st.dataframe(pd.DataFrame(rows).set_index("reaction").style.format(
        {"Nk+": "{:.3g}", "Nk−": "{:.3g}", "Nk+/Nk−": "{:.3g}"}), width="stretch")


# --- Mass transfer ---------------------------------------------------------------------------

def _fill_dm_wilke_chang(temperature, fluid):
    df = st.session_state[_k("mass_transfer")].copy()
    df[fs.DM] = correlations.wilke_chang(df[fs.VA].to_numpy(dtype=float), temperature, fluid)
    tables.set_table(_k("mass_transfer"), df)


def _mt_table(columns):
    return tables.editable_table(_k("mass_transfer"), column_order=columns,
        column_config={k: st.column_config.NumberColumn(format=NUM, min_value=0.0) for k in fs.MT_DEFAULTS})


def _mass_transfer_panel(comps, column, flow, n_mod):
    """Fill Eb, kf/keff, Dp of ``column``; returns ``CorrelationInputs`` or None (direct input)."""
    names = [c.name for c in comps]
    tables.sync_index(_k("mass_transfer"), names, fs.MT_DEFAULTS)
    method = st.radio("Parameters", fs.MT_METHODS, horizontal=True, key=_k("mt_method"), **_P)
    model = column.model
    correlation = None
    if n_mod:
        st.caption(("Salt and pH travel" if n_mod == 2 else "Salt travels")
                   + " through the pores like the solutes, so " + ("they" if n_mod == 2 else "it") + " need values too.")

    if method == fs.MT_METHODS[0]:
        column.axial_dispersion = st.number_input("Axial dispersion Eb [cm²/min]", min_value=0.0, format=NUM,
                                                  key=_k("mt_Eb"), **_P)
        if model == "LRM":
            st.caption("LRM (CADET original): mass transfer is lumped into the binding ka/kd.")
            return None
        df = _mt_table({"GRM": [fs.KF, fs.DP], "LRMP": [fs.KF], "LRM_keff": [fs.KEFF]}[model])
        column.film_diffusion = [_opt(v) for v in df[fs.KEFF if model == "LRM_keff" else fs.KF]]
        if model == "GRM":
            column.pore_diffusion = [_opt(v) for v in df[fs.DP]]
    else:
        st.caption("Eb: Chung & Wen · kf: Wilson & Geankoplis · keff: Glueckauf (needs Dp). "
                   "Dp has no correlation; enter it directly.")
        c1, c2, c3 = st.columns(3)
        fluid = correlations.Fluid(
            viscosity=c1.number_input("Viscosity μ [cP]", min_value=1e-4, format=NUM, key=_k("mt_mu"), **_P),
            density=c2.number_input("Density ρ [g/mL]", min_value=1e-3, format=NUM, key=_k("mt_rho"), **_P))
        glueckauf = model == "LRM_keff" and c3.toggle("keff from Glueckauf", key=_k("mt_glueckauf"), **_P)
        with st.expander("Estimate Dm with Wilke & Chang"):
            t = st.number_input("Temperature [°C]", format=NUM, key=_k("mt_T"), **_P)
            st.caption("Uses V_A (molar volume at the normal boiling point) from the table below; "
                       "water as solvent (φ = 2.6). Poor for small ions — prefer literature Dm.")
            st.button("Fill Dm from V_A", on_click=_fill_dm_wilke_chang, args=(t, fluid))
        columns = {"GRM": [fs.DM, fs.DP, fs.VA], "LRMP": [fs.DM, fs.VA], "LRM": [fs.DM, fs.VA],
                   "LRM_keff": [fs.DM, fs.DP, fs.VA] if glueckauf else [fs.DM, fs.KEFF, fs.VA]}[model]
        df = _mt_table(columns)
        dm = [_opt(v) for v in df[fs.DM]]
        dpore = [_opt(v) for v in df[fs.DP]] if model == "GRM" or glueckauf else None
        try:
            est = correlations.estimate(flow, column.diameter, column.radius, column.eps_b, column.eps_p,
                                        dm, fluid, dp_cm2_min=dpore)
        except (ValueError, TypeError) as e:
            st.error(str(e))
            return None
        for w in est.warnings:
            st.warning(w)
        column.axial_dispersion = est.axial_dispersion
        if model == "GRM":
            column.pore_diffusion = dpore
        if model == "LRM_keff":
            column.film_diffusion = list(est.keff) if glueckauf else [_opt(v) for v in df[fs.KEFF]]
        elif model != "LRM":
            column.film_diffusion = list(est.film_diffusion)
        correlation = mb.CorrelationInputs(
            viscosity=fluid.viscosity, density=fluid.density, molecular_diffusion=dm, keff_from_glueckauf=glueckauf,
            pore_diffusion=dpore, molar_volume=[_opt(v) for v in df[fs.VA]], temperature=t)

        st.markdown(f"**Estimates** — u = {est.u:.4g} cm/min · u_s = {est.u_s:.4g} cm/min · "
                    f"Re = {est.re:.3g} · Eb = {est.axial_dispersion:.4g} cm²/min")
        table = {"Sc": est.sc, fs.KF: est.film_diffusion}
        if est.keff is not None:
            table["keff (Glueckauf) [cm/min]"] = est.keff
        st.dataframe(pd.DataFrame(table, index=names), width="stretch")

    _dimensionless_preview(comps, column, flow)
    return correlation


def _dimensionless_preview(comps, column, flow):
    if column.model != "LRM" and any(v is None for v in column.film_diffusion or [None]):
        return
    if column.model == "GRM" and any(v is None or v <= 0 for v in column.pore_diffusion or [None]):
        return
    values = dimensionless.groups(column, flow, len(comps))
    st.markdown("**Dimensionless groups**")
    st.dataframe(pd.DataFrame(values, index=[c.name for c in comps]).style.format("{:.3g}"), width="stretch")
    for message in dimensionless.diagnose(values, [c.name for c in comps]):
        st.caption(message)


# --- Inlet / process -----------------------------------------------------------------------

def _injection_panel(comps, flow):
    """Pulse injection: volume, start and feed concentrations. Returns ``mb.Injection`` or None."""
    names = [c.name for c in comps]
    if not st.toggle("Pulse injection", key=_k("inj_enabled"),
                     help="Inject a volume of sample, then continue with the eluent program below. "
                          "Off: the table alone defines the inlet (e.g. continuous loading).", **_P):
        return None
    c = st.columns(3, vertical_alignment="bottom")
    volume = c[0].number_input("Injection volume [mL]", min_value=1e-6, format=NUM, key=_k("inj_volume"), **_P)
    start = c[1].number_input("Injection start [min]", min_value=0.0, format=NUM, key=_k("inj_start"), **_P)
    c[2].markdown(f"V/Q = **{volume / flow:.4g} min**  \nends at t = {start + volume / flow:.4g} min")
    tables.sync_index(_k("injection"), names, {"feed": {"salt": 50.0, "pH": 7.0, "*": 0.0}})
    units_of = {c.name: c.liquid_unit for c in comps}

    def decorate(df):
        out = df.copy()
        out["unit"] = [units_of[n] for n in out.index]
        return out

    df = tables.editable_table(_k("injection"), decorate=decorate, disabled=["unit"],
        column_config={"feed": st.column_config.NumberColumn("Feed concentration", format=NUM, min_value=0.0),
                       "unit": st.column_config.TextColumn("Unit")})
    return mb.Injection(volume=volume, start=start, feed=[_opt(v) or 0.0 for v in df["feed"]])


def _inlet_graph(comps, operation, n_mod):
    """Concentrations the column receives over time (injection laid over the program)."""
    duration = float(st.session_state[_k("sim_T")])
    segments = operation.program()
    modifiers = list(range(n_mod))
    solutes = [i for i in range(len(comps)) if i not in modifiers]
    st.markdown("**Inlet over time**")
    if solutes:
        st.plotly_chart(plots.inlet_program(segments, comps, solutes, duration), width="stretch",
                        key=_k("inlet_plot_solutes"))
    if modifiers:
        for col, i in zip(st.columns(len(modifiers)), modifiers):
            col.plotly_chart(plots.inlet_program(segments, comps, [i], duration, height=200), width="stretch",
                             key=_k(f"inlet_plot_{comps[i].name}"))
    inj = operation.injection
    if inj is not None and inj.start + inj.volume / operation.flow_rate > duration:
        st.warning(f"The injection ends at t = {inj.start + inj.volume / operation.flow_rate:.4g} min, "
                   f"after the simulated time ({duration:.4g} min). Increase the total time.")


def _operation_panel(comps, n_mod):
    c1, c2, c3 = st.columns([2, 1, 1], vertical_alignment="bottom")
    flow = c1.number_input("Flow rate Q [mL/min]", min_value=1e-6, format=NUM, key=_k("op_Q"), **_P)
    use_ecv = c2.toggle("Extra-column volume", key=_k("op_ecv"),
                        help="Total dead volume, split into an inlet and an outlet CSTR of V/2 each.", **_P)
    dead_volume = c3.number_input("Dead volume [mL]", min_value=0.0, format=NUM, key=_k("op_Vd"),
                                  disabled=not use_ecv, **_P)
    injection = _injection_panel(comps, flow)
    st.markdown("**Eluent program**" if injection else "**Inlet program**")
    st.caption("Each row sets the concentrations from its start time; 'step' holds them until the next row, "
               "'linear' ramps to the next row's values. The last row is held to the end."
               + (" The injection above replaces them while it lasts." if injection else ""))
    names = [c.name for c in comps]
    tables.sync_columns(_k("inlet"), fs.INLET_FIXED, names, {"salt": 50.0, "pH": 7.0, "*": 0.0})
    column_config = {
        "start [min]": st.column_config.NumberColumn(format=NUM, min_value=0.0, required=True),
        "shape": st.column_config.SelectboxColumn(options=mb.INLET_SHAPES, default="step", required=True),
    }
    for c in comps:
        column_config[c.name] = st.column_config.NumberColumn(f"{c.name} [{c.liquid_unit}]", format=NUM,
                                                              default=0.0)
    df = tables.editable_table(_k("inlet"), num_rows="dynamic", hide_index=True, column_config=column_config)
    df = df.dropna(subset=["start [min]"]).sort_values("start [min]")
    segments = mb.inlet_from_table(
        list(df["start [min]"]),
        [s or "step" for s in df["shape"]],
        [[float(v) if _opt(v) is not None else 0.0 for v in row] for row in df[names].itertuples(index=False)],
    )
    operation = mb.OperationSpec(flow_rate=flow, inlet=segments, dead_volume=dead_volume if use_ecv else 0.0,
                                 injection=injection)
    _inlet_graph(comps, operation, n_mod)
    return operation


# --- Initial state ---------------------------------------------------------------------------

def _initial_units(comp, index, n_mod):
    if n_mod and index == 0:
        return f"c₀: {comp.liquid_unit} · q₀ = Λ − Σ ν·q (set automatically)"
    if n_mod == 2 and index == 1:
        return "c₀: pH (initial pH of the column)"
    if not comp.bound:
        return f"c₀: {comp.liquid_unit} · (not adsorbed)"
    return f"c₀: {comp.liquid_unit} · q₀: {comp.solid_unit}"


def _fresh_state_table(comps, column, binding):
    """Uniform initial liquid / bound concentrations; fills ``column.initial_liquid / initial_solid``."""
    n_mod = mb.modulator_count(binding.model)
    st.caption("c₀ is the liquid concentration in the bulk and pore liquid, q₀ the bound concentration, "
               "both uniform along the column. Default 0." +
               (f" {binding.model}: give the initial salt" + (" and pH" if n_mod == 2 else "")
                + " (the buffer the column was equilibrated with); salt on the resin follows from "
                  "electroneutrality." if n_mod else "") +
               " With rapid-equilibrium binding CADET re-partitions pore liquid and resin to equilibrium "
               "at t = 0, keeping the total amount.")
    names = [c.name for c in comps]
    tables.sync_index(_k("initial"), names, {"c0": {"salt": 50.0, "pH": 7.0, "*": 0.0}, "q0": 0.0})
    by_name = {c.name: (i, c) for i, c in enumerate(comps)}

    def decorate(df):
        out = df.copy()
        out["units"] = [_initial_units(by_name[n][1], by_name[n][0], n_mod) for n in out.index]
        return out

    df = tables.editable_table(_k("initial"), decorate=decorate, disabled=["units"],
        column_config={"c0": st.column_config.NumberColumn("c₀", format=NUM),
                       "q0": st.column_config.NumberColumn("q₀", format=NUM, min_value=0.0),
                       "units": st.column_config.TextColumn(width="large")})
    column.initial_liquid = [_opt(v) for v in df["c0"]]
    column.initial_solid = [_opt(v) for v in df["q0"]]


def _initial_state_panel(comps, column, binding):
    """Initial column state. Fresh column: fills ``column.initial_liquid / initial_solid``
    from the table and returns None; otherwise returns the chosen ``ColumnState``."""
    choice = st.radio("Start from", fs.STATE_SOURCES, horizontal=True, key=_k("init_state_source"), **_P)
    if choice == fs.STATE_SOURCES[0]:
        _fresh_state_table(comps, column, binding)
        return None
    if choice == fs.STATE_SOURCES[1]:
        result = st.session_state.get("batch_result")
        if result is None or result.final_state is None:
            st.info("Run a simulation first; its final column profile can then start the next run.")
            return None
        state = state_manager.state_from_result(result)
        st.caption(f"Starting from the {state.source}.")
        return state
    upload = st.file_uploader("Column profile file (.cprofile), or a result file (.h5)", type=["cprofile", "h5", "hdf5"],
                              key=_k("init_state_file"),
                              help="A file saved with the '💾 Column profile' button of a result. A result file also "
                                   "works: its run's final state is used.")
    if upload is None:
        return None
    cache = st.session_state.get(_k("init_state_cache"))
    if cache is None or cache[0] != upload.file_id:
        try:
            loaded = state_manager.load_state(upload.getvalue())
        except (OSError, ValueError, KeyError) as e:
            st.error(f"Could not read {upload.name}: {e}")
            return None
        loaded.source = f"{upload.name} ({loaded.source})" if loaded.source else upload.name
        cache = (upload.file_id, loaded)
        st.session_state[_k("init_state_cache")] = cache
    st.caption(f"Starting from {cache[1].source}.")
    return cache[1]


# --- Simulation ------------------------------------------------------------------------------

def _parse_positive(text):
    try:
        value = float(str(text).strip())
    except ValueError:
        return None
    return value if math.isfinite(value) and value > 0 else None


def _settings_panel(model, duration=True):
    """Simulation settings. Returns ``(settings, tolerance_info_slot, error)``. ``duration=False`` leaves
    out the total time (SMB: the cycles set it)."""
    c1, c2, c3 = st.columns(3)
    duration = (c1.number_input("Total time [min]", min_value=0.01, format=NUM, key=_k("sim_T"), **_P)
                if duration else mb.SimulationSettings.duration)
    interval = c1.number_input("Output interval [min]", min_value=1e-4, format=NUM, key=_k("sim_dt"), **_P)
    n_col = c2.number_input("Axial cells", min_value=4, step=10, key=_k("sim_ncol"), **_P)
    n_par = c2.number_input("Particle cells (GRM)", min_value=1, step=1, key=_k("sim_npar"), disabled=model != "GRM", **_P)
    timeout = c3.number_input("Max computation time [s]", min_value=1.0, step=60.0, format=NUM, key=_k("sim_timeout"),
                              help="The run is stopped if CADET takes longer.", **_P)
    error = None
    with st.expander("Solver tolerances"):
        mode = st.radio("Tolerances", tolerances.MODES, horizontal=True, key=_k("sim_tol_mode"),
                        format_func={"auto": "Automatic (scaled to the concentrations)", "manual": "Manual"}.get, **_P)
        info = st.container()
        c = st.columns(4)
        manual = mode == "manual"
        defaults = tolerances.DEFAULT
        raw = {"reltol": c[0].text_input("Relative (reltol)", key=_k("sim_reltol"), disabled=not manual, **_P),
               "abstol": c[1].text_input("Absolute (abstol) [mol/m³]", key=_k("sim_abstol"), disabled=not manual, **_P),
               "algtol": c[2].text_input("Algebraic (algtol)", key=_k("sim_algtol"), disabled=not manual, **_P),
               "weno_eps": c[3].text_input("WENO epsilon", key=_k("sim_weno_eps"), disabled=not manual, **_P)}
        parsed = {k: _parse_positive(v) for k, v in raw.items()}
        if manual and any(v is None for v in parsed.values()):
            bad = ", ".join(k for k, v in parsed.items() if v is None)
            error = f"Solver tolerance {bad} must be a positive number (e.g. 1e-8)."
        st.caption("Smaller = stricter (more accurate, slower). Automatic mode lowers abstol, algtol and the WENO "
                   "epsilon for trace concentrations; at mM and above it equals CADET's defaults. In manual "
                   "mode raising reltol (e.g. 1e-4) speeds up very stiff problems at some cost in accuracy.")
    settings = mb.SimulationSettings(
        duration=duration, output_interval=interval, n_col=int(n_col), n_par=int(n_par), timeout=timeout,
        tolerance_mode=mode, **{k: (v if v is not None else getattr(defaults, k)) for k, v in parsed.items()})
    return settings, info, error


# --- Page ---------------------------------------------------------------------------------------

def render():
    """Draw the form. Returns ``(spec, error, initial_state)``; ``spec`` is None on error."""
    use_namespace("")
    _init_state()
    bar = st.container()
    box = {}
    for n, name in enumerate(SECTIONS):
        box[name] = st.container()
        with box[name]:
            st.divider()
            st.subheader(name)
    save_slot = _input_bar(bar)

    def fail(message):
        _save_button(save_slot, None)
        st.session_state[_k("form_spec")] = None
        return None, message, None

    n_mod = mb.modulator_count(st.session_state[_k("binding_model")])
    with box["Components"]:
        modifiers, solutes = _components_panel(n_mod)
    problem = _name_error(modifiers, solutes)
    if problem:
        with box["Components"]:
            st.error(problem)
        return fail(problem)
    comps = modifiers + solutes
    names = [c.name for c in comps]
    problem = _unit_error(comps)
    if problem:
        with box["Components"]:
            st.error(problem)
        return fail(problem)

    with box["Column"]:
        column = _column_panel()
        _resin_density(comps, column)
    with box["Binding"]:
        binding = _binding_panel(modifiers, solutes, column.model)
    with box["Reactions"]:
        reactions = _reactions_panel(names)
    try:
        with box["Inlet / process"]:
            operation = _operation_panel(comps, n_mod)
    except ValueError as e:
        return fail(str(e))
    with box["Mass transfer"]:       # needs Q from the inlet / process section
        correlation = _mass_transfer_panel(comps, column, operation.flow_rate, n_mod)
    with box["Initial state"]:
        initial_state = _initial_state_panel(comps, column, binding)
    with box["Simulation"]:
        settings, tolerance_info, tolerance_error = _settings_panel(column.model)

    spec = mb.BatchSpec(comps, column, binding, operation, settings, correlation, reactions,
                        title=st.session_state[_k("form_title")].strip())
    with box["Reactions"]:
        _reaction_preview(spec)
    with tolerance_info:
        scale = tolerances.concentration_scale(spec)
        auto = tolerances.auto_tolerances(spec)
        st.caption(("Smallest solute concentration: " + (f"{scale:.3g} mol/m³ (= mmol/L). " if scale else "none. ")
                    + f"Automatic values: reltol {auto.reltol:.3g}, abstol {auto.abstol:.3g}, "
                      f"algtol {auto.algtol:.3g}, WENO epsilon {auto.weno_eps:.3g}."))
    if tolerance_error:
        return fail(tolerance_error)
    if initial_state is not None:
        diffs = state_manager.incompatibilities(initial_state, spec)
        if diffs:
            return fail("The selected column profile does not fit the current setup: " + "; ".join(diffs)
                        + ". Change the setup back or start from a fresh column.")
        spec.initial_state_source = initial_state.source
    _save_button(save_slot, spec)
    st.session_state[_k("form_spec")] = spec
    return spec, None, initial_state
