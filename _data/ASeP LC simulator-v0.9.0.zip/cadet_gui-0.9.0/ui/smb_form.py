"""SMB screen input form: the Batch panels (components, column, binding, reactions, mass transfer,
settings) in their own form state (prefix "smb_"), plus the SMB layout, flows and streams.

``render()`` returns ``(spec, error, initial_state)``: an ``SMBSpec`` (None on error) and, when the run
continues from the last SMB run, its ``(state, state_derivative)``.
"""
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from core import examples, smb, tolerances, units
from core import model_builder as mb
from core.naming import file_stem
from ui import batch_form as bf
from ui import form_state as fs
from core import smb_results as sr
from ui import save_panel, smb_animation, tables
from ui.batch_form import NUM, _P, _k
from utils import input_files

NS = "smb_"
SECTIONS = ("Components", "Column", "Binding", "Reactions", "SMB layout and flows", "Mass transfer",
            "Initial state", "Simulation")
FLOW_MODE_LABELS = {"external": "External flows (Q_F, Q_D, Q_E, Q_IV)", "zones": "Zone flows (Q_I … Q_IV)",
                    "m": "Flow-rate ratios (m₁ … m₄)"}
STATE_SOURCES = ("Fresh columns", "Final state of the last SMB run", "Load an SMB result file")
STREAM_DEFAULTS = {"feed": {"salt": 50.0, "pH": 7.0, "*": 1.0}, "eluent": {"salt": 300.0, "pH": 7.0, "*": 0.0}}


# --- Form state -------------------------------------------------------------------------------------

def smb_state(spec: smb.SMBSpec):
    """``(state, notes)`` that make the SMB form show ``spec``."""
    state, notes = fs.spec_to_state(spec.base)
    k = mb.modulator_count(spec.base.binding.model)
    names = [fs.SALT_NAME, fs.PH_NAME][:k] + [c.name for c in spec.components[k:]]
    state.update({
        "form_title": spec.title,
        "layout": spec.layout,
        **{f"zones_{z}": 1 for z in smb.ZONE_NAMES},
        **{f"zones_{z}": int(k) for z, k in zip(smb.ZONE_NAMES, spec.columns_per_zone)},
        "switch_time": float(spec.switch_time),
        "flow_mode": spec.flow_mode, "flow_mode_last": spec.flow_mode,
        **{f"flow_{i}": float(v) for i, v in enumerate(spec.flows)},
        "streams": pd.DataFrame({"feed": [float(v) for v in spec.feed], "eluent": [float(v) for v in spec.eluent]},
                                index=names),
        **{f"products_{o}": list(spec.products.get(o, [])) for o in _ALL_PRODUCT_OUTLETS},
        "cyc_mode": spec.cycles.mode, "cyc_n": int(spec.cycles.n_cycles), "cyc_max": int(spec.cycles.max_cycles),
        "cyc_tol": float(spec.cycles.threshold),
        "tri_gamma": 1.1, "init_source": STATE_SOURCES[0],
        "profile_interval": float(spec.profile_interval or 0.0),
    })
    return state, notes


_ALL_PRODUCT_OUTLETS = sorted({o for layout in smb.LAYOUTS.values() for o in layout.products})


def _apply(state):
    streams = state.pop("streams")
    bf.apply_state(state)
    tables.set_table(_k("streams"), streams)


def _default_state():
    return smb_state(examples.smb_binary())[0]


def _init_state():
    if _k("form_ready") not in st.session_state:
        _apply(_default_state())


def _message(kind, text):
    st.session_state[_k("input_msg")] = (kind, text)


def _on_input_upload():
    upload = st.session_state.get(_k("input_upload"))
    if upload is None:
        return
    try:
        kind, spec = input_files.load_smb_input(upload.getvalue())
        if kind == "batch":
            current = st.session_state.get(_k("form_spec"))
            template = current or examples.smb_binary()
            n = len(spec.components)
            k = mb.modulator_count(spec.binding.model)
            stream = lambda key: [STREAM_DEFAULTS[key].get(c.name, STREAM_DEFAULTS[key]["*"]) if i < k else
                                  STREAM_DEFAULTS[key]["*"] for i, c in enumerate(spec.components)]
            spec = smb.SMBSpec(base=spec, layout=template.layout, columns_per_zone=template.columns_per_zone,
                               switch_time=template.switch_time, flow_mode=template.flow_mode,
                               flows=template.flows, feed=stream("feed")[:n], eluent=stream("eluent")[:n],
                               cycles=template.cycles, title=spec.title)
            spec.products = smb.default_products(spec)
            note = " It is a Batch input: its components, column, binding and settings were taken; check the SMB " \
                   "layout, flows and the feed / eluent."
        else:
            note = ""
        state, notes = smb_state(spec)
        _apply(state)
        _message("warning" if notes or note else "success",
                 f"Loaded {upload.name}." + note + " " + " ".join(notes))
    except ValueError as e:
        _message("error", f"Could not load {upload.name}: {e}")


def _load_example():
    name = st.session_state[_k("example_choice")]
    _apply(smb_state(examples.SMB_EXAMPLES[name]())[0])
    _message("success", f"Loaded the example “{name}”.")


def _copy_from_batch():
    """Take components, column, binding, reactions, mass transfer and settings from the Batch form."""
    batch = st.session_state.get("form_spec")
    if batch is None:
        _message("error", "The Batch form has no complete input to copy.")
        return
    current = st.session_state.get(_k("form_spec")) or examples.smb_binary()
    same = [c.name for c in batch.components] == [c.name for c in current.components]
    n = len(batch.components)
    spec = smb.SMBSpec(base=batch, layout=current.layout, columns_per_zone=current.columns_per_zone,
                       switch_time=current.switch_time, flow_mode=current.flow_mode, flows=current.flows,
                       feed=current.feed if same else [1.0] * n, eluent=current.eluent if same else [0.0] * n,
                       cycles=current.cycles, title=current.title or batch.title,
                       products=current.products if same else {})
    if not same:
        spec.products = smb.default_products(spec)
    _apply(smb_state(spec)[0])
    _message("success", "Copied components, column, binding, reactions, mass transfer and settings from the Batch "
                        "screen." + ("" if same else " The components differ: check the feed and eluent."))


def _new_simulation():
    job = st.session_state.get("smb_job")
    if job is not None and not job.done:
        job.cancel()
    for key in ("smb_job", "smb_result", "smb_error", "smb_log_note"):
        st.session_state.pop(key, None)
    for key in [k for k in st.session_state if k.startswith("smbview_")]:
        del st.session_state[key]
    _apply(_default_state())
    _message("success", "New SMB simulation: the form is back to its startup values and the previous result "
                        "is cleared.")


def _convert_flows():
    """Keep the same SMB when the flow input changes (external ↔ zones ↔ m)."""
    new = st.session_state[_k("flow_mode")]
    old = st.session_state.get(_k("flow_mode_last"))
    spec = st.session_state.get(_k("form_spec"))
    st.session_state[_k("flow_mode_last")] = new
    if spec is None or old == new or old is None:
        return
    try:
        values = smb.flows_as(spec, new)
    except ValueError:
        return
    for i, v in enumerate(values):
        st.session_state[_k(f"flow_{i}")] = float(f"{v:.6g}")


# Zone flows used when a layout change cannot carry the current flows over (valid for the example column).
DEFAULT_ZONE_FLOWS = {"4-zone closed": [6.33, 3.43, 5.59, 3.26], "4-zone open": [6.33, 3.43, 5.59, 3.26],
                      "3-zone": [6.33, 3.43, 5.59], "5-zone closed": [6.33, 3.43, 2.7, 4.9, 3.26],
                      "5-zone open": [6.33, 3.43, 2.7, 4.9, 3.26]}


def _change_layout():
    """New layout: zone flows carried over where they make a valid SMB (else defaults), entered as zone flows."""
    new = st.session_state[_k("layout")]
    spec = st.session_state.get(_k("form_spec_any"))
    nz = smb.LAYOUTS[new].n_zones
    flows = None
    if spec is not None:
        try:
            q = list(smb.flow_set(spec).zones)
            if nz == 5 and len(q) == 4:            # extract 2 between zones II and III
                q = [q[0], q[1], 0.8 * q[1], 0.8 * q[1] + (q[2] - q[1]), min(q[3], 0.9 * q[0])]
            elif nz == 4 and len(q) == 5:
                q = [q[0], q[1], q[1] + (q[3] - q[2]), q[4]]
            q = (q + [q[-1]] * nz)[:nz]
            trial = smb.SMBSpec(**{**spec.__dict__, "layout": new, "flow_mode": "zones", "flows": q,
                                   "columns_per_zone": [1] * nz})
            flows = q if not smb.flow_problems(trial) else None
        except ValueError:
            flows = None
    flows = flows or DEFAULT_ZONE_FLOWS[new]
    st.session_state[_k("flow_mode")] = st.session_state[_k("flow_mode_last")] = "zones"
    for i, v in enumerate(flows):
        st.session_state[_k(f"flow_{i}")] = float(f"{v:.6g}")
    if spec is not None:
        products = smb.default_products(smb.SMBSpec(**{**spec.__dict__, "layout": new}))
        for o in _ALL_PRODUCT_OUTLETS:
            st.session_state[_k(f"products_{o}")] = products.get(o, [])
    _message("info", f"Layout changed to {smb.LAYOUTS[new].label}. Flows are shown as zone flows; check them.")


def _design_flows():
    spec = st.session_state.get(_k("form_spec_any"))
    try:
        m = smb.triangle_design(spec, gamma=float(st.session_state[_k("tri_gamma")]))
    except ValueError as e:
        _message("error", f"Triangle design: {e}")
        return
    st.session_state[_k("flow_mode")] = "m"
    st.session_state[_k("flow_mode_last")] = "m"
    for i, v in enumerate(m):
        st.session_state[_k(f"flow_{i}")] = float(f"{v:.6g}")
    _message("success", "Flows set from the triangle theory: m = " + ", ".join(f"{v:.3g}" for v in m) + ".")


# --- Panels -------------------------------------------------------------------------------------

def _input_bar(container):
    with container:
        st.subheader("Input file")
        st.text_input("Simulation title", key=_k("form_title"), placeholder="e.g. A / B split, 1-1-1-1, t_s 3 min",
                      help="Names the input file, the Excel workbook and the result file.", **_P)
        c = st.columns([3, 3, 2])
        c[0].file_uploader("Load an input file", type=["json", sr.EXTENSION, "h5", "hdf5"], key=_k("input_upload"),
                           on_change=_on_input_upload,
                           help="An SMB input file (.json), SMB run log or SMB result file (.smbh5). A Batch input "
                                "or result file (.h5) gives the components, column, binding and settings.")
        c[1].selectbox("Examples", list(examples.SMB_EXAMPLES), key=_k("example_choice"), **_P)
        c[1].button("Load example", key=_k("load_example"), on_click=_load_example)
        slot = c[2].container()
        c[2].button("New", key=_k("new_simulation"), on_click=_new_simulation,
                    help="Start over: startup values, the previous SMB result cleared.")
        c[2].button("Copy from Batch", key=_k("copy_batch"), on_click=_copy_from_batch,
                    help="Take the components, column, binding, reactions, mass transfer and settings from the "
                         "Batch screen; the SMB layout and flows stay.")
        message = st.session_state.get(_k("input_msg"))
        if message:
            getattr(st, message[0])(message[1])
        folder_slot = st.container()
    return slot, folder_slot


def _save_button(slots, spec):
    slot, folder_slot = slots
    if spec is not None:
        with folder_slot:
            save_panel.folder_save(_k("input_file"), lambda: input_files.save_smb_input(spec),
                                   file_stem(spec.title, "smb_input"), "json",
                                   label="Save the input file with a chosen name and folder")
    if spec is None:
        slot.download_button("💾 Save input file", b"", "smb_input.json", disabled=True, key=_k("save_input"),
                             help="Available when the input is complete.")
    else:
        slot.download_button("💾 Save input file", input_files.save_smb_input(spec),
                             file_stem(spec.title, "smb_input") + ".json", "application/json", key=_k("save_input"),
                             help="The complete SMB input in GUI units.")


def _layout_inputs():
    name = st.selectbox("Layout", list(smb.LAYOUTS), format_func=lambda k: smb.LAYOUTS[k].label,
                        key=_k("layout"), on_change=_change_layout, **_P)
    layout = smb.LAYOUTS[name]
    c = st.columns(layout.n_zones + 1)
    per_zone = [int(c[i].number_input(f"Columns in zone {z}", min_value=1, max_value=8, step=1,
                                      key=_k(f"zones_{z}"), **_P)) for i, z in enumerate(layout.zones)]
    switch = c[-1].number_input("Switch time t_s [min]", min_value=1e-3, format=NUM, key=_k("switch_time"),
                                help="The ports move one column forward every t_s.", **_P)
    total = sum(per_zone)
    if total > 8:
        st.warning(f"{total} columns: every cycle has {total} switches, so runs take longer.")
    return name, per_zone, switch


def _flow_inputs(layout_name):
    mode = st.radio("Flow input", smb.FLOW_MODES, format_func=FLOW_MODE_LABELS.get, horizontal=True,
                    key=_k("flow_mode"), on_change=_convert_flows, **_P)
    labels = smb.flow_labels(layout_name, mode)
    unit = "" if mode == "m" else " [mL/min]"
    c = st.columns(len(labels))
    flows = [c[i].number_input(labels[i] + unit, format=NUM, key=_k(f"flow_{i}"), **_P) for i in range(len(labels))]
    return mode, flows


def _streams_table(comps, n_mod):
    names = [c.name for c in comps]
    tables.sync_index(_k("streams"), names, STREAM_DEFAULTS)
    by_name = {c.name: c for c in comps}

    def decorate(df):
        out = df.copy()
        out["units"] = [by_name[n].liquid_unit for n in out.index]
        return out

    st.markdown("**Feed and eluent (desorbent)**")
    st.caption("Concentrations entering with the feed and the eluent (zone I), constant in time."
               + (" Salt" + (" and pH" if n_mod == 2 else "") + " are part of both streams." if n_mod else ""))
    df = tables.editable_table(
        _k("streams"), decorate=decorate, disabled=["units"],
        column_config={"feed": st.column_config.NumberColumn("Feed", format=NUM, min_value=0.0),
                       "eluent": st.column_config.NumberColumn("Eluent", format=NUM, min_value=0.0)})
    return [bf._opt(v) for v in df["feed"]], [bf._opt(v) for v in df["eluent"]]


def _flow_summary(spec):
    """Live table of all flows and m values, and the flow problems (list of messages)."""
    problems = smb.flow_problems(spec)
    try:
        f = smb.flow_set(spec)
    except ValueError:
        return problems
    zones = spec.geometry.zones
    rows = [{"": "Zone flow [mL/min]", **{z: f.zones[i] for i, z in enumerate(zones)}},
            {"": "m (flow-rate ratio)", **{z: f.m[i] for i, z in enumerate(zones)}}]
    st.dataframe(pd.DataFrame(rows).set_index(""), width="stretch")
    st.caption(" · ".join(f"{smb.STREAM_LABELS[k]} {smb._SYMBOL[k]} {v:.4g}" for k, v in f.ports.items())
               + f" mL/min. Column volume {smb.column_volume(spec):.4g} mL, "
               f"εt {spec.base.column.total_porosity():.3g}; cycle {spec.cycle_time:g} min "
               f"({spec.n_columns} switches).")
    return problems


def _layout_animation(spec, problems):
    """The column layout with the moving ports, from the inputs alone (no run needed)."""
    st.markdown("**Process layout**")
    if problems:
        st.caption("Shown when the flows are valid.")
        return
    st.iframe(smb_animation.process_html(spec, spec.cycle_time), height=smb_animation.HEIGHT)   # our own HTML (spec numbers only)
    from ui import smb_views
    titled = smb.SMBSpec(**{**spec.__dict__, "title": st.session_state.get(_k("form_title"), "").strip()})
    smb_views.layout_images(titled, _k("layout"))
    st.caption("One cycle: the columns stay in place; the eluent, extract, feed and raffinate ports move one column "
               "forward every switch. Play, step through the switches or drag the slider.")


def triangle_figure(spec):
    """m₂–m₃ plane with the complete-separation region (linear: the triangle at infinite dilution)
    and the operating point."""
    h = smb.henry_coefficients(spec)
    f = smb.flow_set(spec)
    hb, ha = sorted(h.values())
    lo, hi = hb - 0.4 * (ha - hb), ha + 0.4 * (ha - hb)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[lo, hi], y=[lo, hi], mode="lines", line=dict(color="#888780", width=1),
                             name="m₂ = m₃", hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=[hb, hb, ha, hb], y=[hb, ha, ha, hb], mode="lines", fill="toself",
                             fillcolor="rgba(29,158,117,0.15)", line=dict(color="#1D9E75"),
                             name="complete separation (linear)"))
    fig.add_trace(go.Scatter(x=[f.m[1]], y=[f.m[2]], mode="markers", marker=dict(size=11, color="#D85A30"),
                             name="operating point"))
    fig.update_layout(xaxis_title="m₂", yaxis_title="m₃", height=320, margin=dict(l=10, r=10, t=30, b=10),
                      legend=dict(orientation="h", y=1.15), xaxis_range=[lo, hi], yaxis_range=[lo, hi])
    return fig


def _design_panel(spec):
    with st.expander("Triangle design", expanded=False):
        if not smb.triangle_available(spec):
            st.caption("Available for the closed 4-zone layout with exactly two adsorbing components and Linear or "
                       "Langmuir binding. Otherwise enter the flows directly.")
            return
        h = smb.henry_coefficients(spec)
        (sa, ha), (sb, hb) = sorted(h.items(), key=lambda kv: -kv[1])
        st.caption(f"Henry coefficients at infinite dilution: {sa} {ha:.4g}, {sb} {hb:.4g}. Complete separation "
                   f"(linear) needs m₁ > {ha:.3g}, {hb:.3g} < m₂ < m₃ < {ha:.3g}, m₄ < {hb:.3g}; Langmuir moves "
                   "the region down with the feed concentration.")
        c1, c2 = st.columns([1, 2], vertical_alignment="bottom")
        c1.number_input("Safety factor γ", min_value=1.0, max_value=3.0, step=0.05, format=NUM,
                        key=_k("tri_gamma"), help="1 = on the triangle's vertex; larger values move inside "
                                                  "(more robust, less productive).", **_P)
        c2.button("Design flows (triangle theory)", key=_k("tri_button"), on_click=_design_flows,
                  help="Sets m₁ … m₄; the switch time and column size stay.")
        try:
            st.plotly_chart(triangle_figure(spec), width="stretch", key=_k("tri_plot"))
        except ValueError:
            pass


def _products(layout_name, solute_names):
    """{outlet: [names]} chosen for every product outlet of the layout."""
    st.markdown("**Products** (for purity and recovery)")
    outlets = smb.LAYOUTS[layout_name].products
    c = st.columns(len(outlets))
    out = {}
    for col, outlet in zip(c, outlets):
        key = _k(f"products_{outlet}")
        current = st.session_state.get(key, [])
        if any(n not in solute_names for n in current):
            st.session_state[key] = [n for n in current if n in solute_names]
        out[outlet] = col.multiselect(f"Collected in the {smb.STREAM_LABELS[outlet]}", solute_names, key=key, **_P)
    return out


def _cycle_inputs():
    st.markdown("**Cycles**")
    c = st.columns(3)
    mode = c[0].radio("Run", smb.CYCLE_MODES, key=_k("cyc_mode"),
                      format_func={"steady state": "Until cyclic steady state", "fixed": "Fixed number of cycles"}.get,
                      **_P)
    if mode == "fixed":
        n = c[1].number_input("Cycles", min_value=1, step=1, key=_k("cyc_n"), **_P)
        return smb.CycleSettings(mode=mode, n_cycles=int(n), max_cycles=int(st.session_state.get(_k("cyc_max"), 50)),
                                 threshold=float(st.session_state.get(_k("cyc_tol"), 1e-3)))
    max_cycles = c[1].number_input("Max cycles", min_value=2, step=5, key=_k("cyc_max"), **_P)
    tol = c[2].number_input("Steady-state tolerance", min_value=1e-8, max_value=0.5, format="%.0e", key=_k("cyc_tol"),
                            help="Two successive cycles count as equal when every unit's inlet and outlet differ by "
                                 "less than this (relative area and normalised RMS error).", **_P)
    return smb.CycleSettings(mode=mode, n_cycles=int(st.session_state.get(_k("cyc_n"), 10)),
                             max_cycles=int(max_cycles), threshold=float(tol))


def _initial_state_panel(comps, column, binding, spec_for_structure):
    choice = st.radio("Start from", STATE_SOURCES, horizontal=True, key=_k("init_source"), **_P)
    if choice == STATE_SOURCES[0]:
        st.caption("Every column starts with the same uniform state.")
        bf._fresh_state_table(comps, column, binding)
        return None, None
    if choice == STATE_SOURCES[1]:
        result = st.session_state.get("smb_result")
        if result is None or result.final_state is None:
            st.info("Run an SMB simulation first; its final state can then start the next run.")
            return None, None
        st.caption(f"Continuing from the end of the last SMB run (cycle {result.n_cycles}).")
        bf._fresh_state_table(comps, column, binding)      # kept for the input file; not used by CADET
        return (result.final_state, result.final_state_derivative), result.spec
    upload = st.file_uploader(f"SMB result file (.{sr.EXTENSION})", type=[sr.EXTENSION, "h5", "hdf5"],
                              key=_k("init_file"), help="The run continues from the state at the end of that file's "
                              "run. Layout, columns per zone, column model, grid, components and binding must match; "
                              "flows, switch time and feed / eluent may change.")
    cache_key = _k("init_file_cache")
    if upload is not None and (st.session_state.get(cache_key) or {}).get("id") != upload.file_id:
        try:
            loaded = sr.load_h5(upload.getvalue())
            if loaded.final_state is None:
                raise ValueError("the file has no final state")
            st.session_state[cache_key] = {"id": upload.file_id, "name": upload.name, "spec": loaded.spec,
                                           "n_cycles": loaded.n_cycles,
                                           "state": (loaded.final_state, loaded.final_state_derivative)}
        except (ValueError, OSError, KeyError) as e:
            st.session_state.pop(cache_key, None)
            st.error(f"Could not use {upload.name}: {e}")
    cached = st.session_state.get(cache_key)
    if cached is None:
        st.info("Choose an SMB result file; the run starts from the end of that file's run.")
        return None, None
    st.caption(f"Continuing from the end of {cached['name']} (after cycle {cached['n_cycles']}).")
    bf._fresh_state_table(comps, column, binding)          # kept for the input file; not used by CADET
    return cached["state"], cached["spec"]


# --- Page ---------------------------------------------------------------------------------------

def render():
    """Draw the SMB form. Returns ``(spec, error, initial_state)``."""
    bf.use_namespace(NS)
    _init_state()
    bar = st.container()
    box = {}
    for name in SECTIONS:
        box[name] = st.container()
        with box[name]:
            st.divider()
            st.subheader(name)
    save_slot = _input_bar(bar)
    st.session_state[_k("form_spec_any")] = None

    def fail(message):
        _save_button(save_slot, None)
        st.session_state[_k("form_spec")] = None
        return None, message, None

    n_mod = mb.modulator_count(st.session_state[_k("binding_model")])
    with box["Components"]:
        modifiers, solutes = bf._components_panel(n_mod)
    problem = bf._name_error(modifiers, solutes) or bf._unit_error(modifiers + solutes)
    if problem:
        with box["Components"]:
            st.error(problem)
        return fail(problem)
    comps = modifiers + solutes
    names = [c.name for c in comps]
    with box["Column"]:
        column = bf._column_panel()
        bf._resin_density(comps, column)
    with box["Binding"]:
        binding = bf._binding_panel(modifiers, solutes, column.model)
    with box["Reactions"]:
        reactions = bf._reactions_panel(names)
    with box["SMB layout and flows"]:
        layout_name, per_zone, switch = _layout_inputs()
        mode, flows = _flow_inputs(layout_name)
        feed, eluent = _streams_table(comps, n_mod)
        flow_slot = st.container()
        design_slot = st.container()
        products = _products(layout_name, [c.name for c in solutes])
    # a provisional spec for the flow numbers (column size and porosity are known now)
    draft = smb.SMBSpec(base=mb.BatchSpec(comps, column, binding, mb.OperationSpec(1.0, [mb.constant(0.0, [0.0] * len(comps))]),
                                          mb.SimulationSettings(), None, reactions),
                        layout=layout_name, columns_per_zone=per_zone, switch_time=switch, flow_mode=mode,
                        flows=flows, feed=feed, eluent=eluent, products=products)
    with flow_slot:
        problems = _flow_summary(draft)
        for p in problems:
            st.error(p)
        _layout_animation(draft, problems)
    try:
        q_ref = float(np.mean(smb.flow_set(draft).zones))
    except ValueError:
        q_ref = 1.0
    with box["Mass transfer"]:
        if q_ref > 0:
            st.caption(f"Correlations use the mean zone flow {q_ref:.4g} mL/min (the zones run at different "
                       "velocities; CADET uses one set of coefficients for all columns).")
        correlation = bf._mass_transfer_panel(comps, column, q_ref if q_ref > 0 else 1.0, n_mod)
    with box["Initial state"]:
        initial_state, previous = _initial_state_panel(comps, column, binding, draft)
    with box["Simulation"]:
        settings, tolerance_info, tolerance_error = bf._settings_panel(column.model, duration=False)
        cycles = _cycle_inputs()
        profile_interval = st.number_input(
            "Column profile interval [min] (0 = automatic)", min_value=0.0, format=NUM, key=_k("profile_interval"),
            help="Column profiles (bulk / pore / solid along every column) are kept for the whole run, from the "
                 "first cycle to the last. Automatic: every output time, thinned only for very long runs (at most "
                 "3000 profile times and 5·10⁷ values per phase). A larger interval makes the result file smaller.",
            **_P)

    top = [max(a or 0.0, b or 0.0) for a, b in zip(feed, eluent)]
    title = st.session_state[_k("form_title")].strip()
    base = mb.BatchSpec(comps, column, binding, mb.OperationSpec(q_ref, [mb.constant(0.0, top)]), settings,
                        correlation, reactions, title=title)
    spec = smb.SMBSpec(base=base, layout=layout_name, columns_per_zone=per_zone, switch_time=switch,
                       flow_mode=mode, flows=flows, feed=feed, eluent=eluent, cycles=cycles, products=products,
                       profile_interval=float(profile_interval), title=title)
    base.settings.duration = spec.cycle_time
    st.session_state[_k("form_spec_any")] = spec
    with design_slot:
        _design_panel(spec)
    with box["Reactions"]:
        bf._reaction_preview(base)
    with tolerance_info:
        auto = tolerances.auto_tolerances(base)
        st.caption(f"Automatic values: reltol {auto.reltol:.3g}, abstol {auto.abstol:.3g}, algtol {auto.algtol:.3g}, "
                   f"WENO epsilon {auto.weno_eps:.3g}.")
    if tolerance_error:
        return fail(tolerance_error)
    if problems:
        return fail("; ".join(problems))
    if settings.output_interval > switch / 4:
        return fail(f"The output interval ({settings.output_interval:g} min) must be at most a quarter of the "
                    f"switch time ({switch:g} min).")
    try:
        smb.check(spec)
    except ValueError as e:
        return fail(str(e))
    if previous is not None and smb.state_structure(previous) != smb.state_structure(spec):
        old, new = smb.state_structure(previous), smb.state_structure(spec)
        diffs = ", ".join(f"{k} ({old.get(k)} → {new.get(k)})" for k in new if old.get(k) != new.get(k))
        return fail(f"The starting state comes from a different setup: {diffs}. Change these back or start from "
                    "fresh columns (flows, switch time and feed / eluent may differ).")
    _save_button(save_slot, spec)
    st.session_state[_k("form_spec")] = spec
    return spec, None, initial_state
