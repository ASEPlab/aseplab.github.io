"""SMB result widgets shared by the SMB page (brief) and the SMB results page (full)."""
import numpy as np
import plotly.graph_objects as go
import streamlit as st

from core import smb
from core import smb_results as sr
from ui.plots import MARKER_COLOR, PHASE_LABELS, SPEEDS, series_color

ZONE_FILL = ("rgba(127,119,221,0.10)", "rgba(29,158,117,0.08)", "rgba(216,90,48,0.08)", "rgba(136,135,128,0.10)",
             "rgba(186,117,23,0.08)")



def _pct(v):
    return "—" if v is None or not np.isfinite(v) else f"{100 * v:.2f} %"


def metrics(result):
    """Headline numbers of the last cycle."""
    perf = sr.performance(result)
    s = result.summary
    conv = s.get("converged")
    state = ("steady state" if conv else "not converged" if conv is False else "fixed")
    cards = [(f"Purity, {smb.STREAM_LABELS[o]}", _pct(v)) for o, v in perf["purity"].items()]
    for p in perf["products"]:
        cards.append((f"Recovery {p['component']} ({smb.STREAM_LABELS[p['outlet']]})", _pct(p["recovery"])))
    cards.append(("Cycles", f"{result.n_cycles} · {state}"))
    for start in range(0, len(cards), 3):           # rows of three so the numbers fit in narrow windows
        row = cards[start:start + 3]
        for col, (label, value) in zip(st.columns(3), row):
            col.metric(label, value)
    if perf["products"]:
        st.caption("Last cycle. " + " · ".join(
            f"{p['component']}: productivity {p['productivity']:.3g} {p['unit']}/(L bed·h), eluent "
            f"{p['eluent use']:.3g} L/{p['unit']}" for p in perf["products"])
            + f" · computation time {s.get('time_elapsed_s', float('nan')):.1f} s.")
    else:
        st.caption("Choose the products of each outlet in the form to get purity and recovery.")
    steady_state_warning(result)


def steady_state_warning(result):
    """Warn when the last two cycles still differ by more than the steady-state tolerance."""
    s = result.summary
    diffs, tol = s.get("cycle_differences") or [], s.get("threshold", result.spec.cycles.threshold)
    if s.get("converged") is True:
        return
    if not diffs:
        if result.n_cycles < 2:
            st.warning("Only one cycle was simulated, so it is unknown whether the SMB is at cyclic steady state.")
        return
    last = diffs[-1]
    if last <= tol:
        return
    st.warning(f"Not at cyclic steady state: the last two cycles still differ by {100 * last:.3g} % "
               f"(tolerance {100 * tol:.3g} %). Purity, recovery and amounts may still change. Run more cycles, "
               "or continue from this run's final state (Initial state → Final state of the last SMB run).")


def outlet_figure(result, outlet, last_cycle=True, components=None, height=320, curve=True, averages=True):
    """One outlet stream: the concentration curves and / or the average concentration of every switch interval
    (a point at the middle of each interval, joined by lines; what a fraction collected over that switch would
    contain); colour per component."""
    comps = result.components
    idx = result.solutes() if components is None else components
    t = result.time
    t_from = t[-1] - result.spec.cycle_time - 1e-9 if last_cycle else -np.inf
    sel = t >= t_from
    fig = go.Figure()
    if averages:
        starts, ends, means = sr.switch_averages(result, outlet)
        keep = starts >= t_from - 1e-9
        starts, ends, means = starts[keep], ends[keep], means[keep]
    for i in idx:
        if curve:
            fig.add_trace(go.Scatter(x=t[sel], y=result.outlets[outlet][sel, i], mode="lines", name=comps[i].name,
                                     legendgroup=comps[i].name, line=dict(color=series_color(i), width=1.5)))
        if averages and len(starts):
            fig.add_trace(go.Scatter(x=0.5 * (starts + ends), y=means[:, i], mode="lines+markers",
                                     name=f"{comps[i].name} average concentration", legendgroup=comps[i].name,
                                     line=dict(color=series_color(i), width=1.5, dash="dash"),
                                     marker=dict(color=series_color(i), size=8, symbol="circle")))
    cycle = result.spec.cycle_time
    if not last_cycle and result.n_cycles <= 60:
        for k in range(1, result.n_cycles):
            fig.add_vline(x=k * cycle, line=dict(color=MARKER_COLOR, width=0.5, dash="dot"))
    units = {comps[i].liquid_unit for i in idx}
    fig.update_layout(title=dict(text=smb.STREAM_LABELS[outlet].capitalize(), font=dict(size=14)),
                      xaxis_title="time [min]",
                      yaxis_title=f"concentration [{next(iter(units))}]" if len(units) == 1 else "concentration",
                      height=height, hovermode="x unified", margin=dict(l=10, r=10, t=40, b=10),
                      legend=dict(orientation="h", x=1, xanchor="right", y=1.02, yanchor="bottom"))
    return fig


def outlet_grid(result, outlets, per_row=2, key="", **kwargs):
    """``outlet_figure`` of every outlet in ``outlets``, ``per_row`` side by side."""
    for start in range(0, len(outlets), per_row):
        row = outlets[start:start + per_row]
        for col, outlet in zip(st.columns(per_row), row):
            col.plotly_chart(outlet_figure(result, outlet, **kwargs), width="stretch", key=f"{key}_{outlet}")


def convergence_figure(result):
    table = sr.cycle_table(result)
    fig = go.Figure()
    for col in table.columns:
        if col.startswith(("purity", "recovery")):
            fig.add_trace(go.Scatter(x=table.index, y=100 * table[col], mode="lines+markers", name=col))
    fig.update_layout(xaxis_title="cycle", yaxis_title="%", height=340, margin=dict(l=10, r=10, t=30, b=10),
                      legend=dict(orientation="h", y=1.15))
    return fig




def ring_figure(result, phase, k, components=None, fixed_y=True, frame_range=None, max_frames=400, height=440):
    """Concentration along the ring (zone I first) at ``profile_time[k]``, zones shaded, ports marked, with
    client-side animation over ``frame_range`` = (first, last) profile index (default: the whole run; play at
    1x / 2x / 5x, pause, scrub with the slider), at most ``max_frames`` frames."""
    spec, comps = result.spec, result.components
    data_all = getattr(result, phase)
    candidates = result.solutes() if components is None else components
    idx = [i for i in candidates if not np.all(np.isnan(data_all[..., i]))]
    lo, hi = frame_range or (0, len(result.profile_time) - 1)
    frames_idx = np.union1d(np.unique(np.round(np.linspace(lo, hi, min(hi - lo + 1, max_frames))).astype(int)), [k])

    def traces(j):
        positions, data = result.ring_profile(phase, j)
        return [go.Scatter(x=positions, y=data[:, i], mode="lines", name=comps[i].name,
                           line=dict(color=series_color(i), width=2)) for i in idx]

    def ticks(j):
        order = smb.column_order(spec, result.profile_time[j])
        return dict(tickmode="array", tickvals=[p + 0.5 for p in range(spec.n_columns)],
                    ticktext=[f"col {c + 1}" for c in order], range=[0, spec.n_columns])

    fig = go.Figure(data=traces(k),
                    frames=[go.Frame(data=traces(j), name=str(j), layout=dict(xaxis=ticks(j))) for j in frames_idx])
    edges = np.cumsum([0] + [int(v) for v in spec.columns_per_zone])
    for z, (a, b) in enumerate(zip(edges, edges[1:])):
        fig.add_vrect(x0=a, x1=b, fillcolor=ZONE_FILL[z], line_width=0, layer="below",
                      annotation_text=f"zone {smb.ZONE_NAMES[z]}", annotation_position="top left")
    for c in range(1, spec.n_columns):
        fig.add_vline(x=c, line=dict(color=MARKER_COLOR, width=0.5, dash="dot"))
    kinds = {name: kind for kind, name in spec.geometry.nodes}
    for name, x in smb.port_positions(spec).items():
        arrow = "↓" if kinds.get(name) == "in" else "↑"
        fig.add_annotation(x=x, y=1, yref="paper", text=f"{smb.STREAM_LABELS[name].capitalize()} {arrow}",
                           showarrow=False, yshift=12, font=dict(size=11))
    fig.update_xaxes(**ticks(k))
    units = {result.unit(phase, i) for i in idx}
    if fixed_y and idx:
        y_max = float(np.nanmax(data_all[..., idx]))
        fig.update_yaxes(range=[0, 1.05 * y_max if y_max > 0 else 1.0])

    def play(ms):
        return dict(frame=dict(duration=ms, redraw=True), transition=dict(duration=0), fromcurrent=True,
                    mode="immediate")

    fig.update_layout(
        yaxis_title=f"{PHASE_LABELS[phase]} [{next(iter(units))}]" if len(units) == 1 else PHASE_LABELS[phase],
        height=height, hovermode="x", margin=dict(l=10, r=10, t=50, b=110),
        legend=dict(orientation="h", x=1, xanchor="right", y=1.12, yanchor="bottom"),
        updatemenus=[dict(
            type="buttons", direction="left", x=0, y=-0.2, xanchor="left", yanchor="top", showactive=False,
            buttons=[dict(label=f"▶ {name}", method="animate", args=[None, play(ms)]) for name, ms in SPEEDS.items()]
            + [dict(label="⏸", method="animate",
                    args=[[None], dict(frame=dict(duration=0, redraw=False), mode="immediate")])])],
        sliders=[dict(
            active=int(np.searchsorted(frames_idx, k)), x=0.3, len=0.7, y=-0.14, yanchor="top",
            currentvalue=dict(prefix="t = ", suffix=" min"),
            steps=[dict(label=f"{result.profile_time[j]:.4g}", method="animate",
                        args=[[str(j)], dict(frame=dict(duration=0, redraw=True), mode="immediate")])
                   for j in frames_idx])],
    )
    return fig


def layout_images(spec, key):
    """Expander with PNG images of the process layout, one per switch (single PNG or a ZIP of all)."""
    import json

    from core import smb_media
    from core.naming import file_stem
    with st.expander("🖼 Save the layout as images (one PNG per switch)"):
        fingerprint = json.dumps(smb.spec_to_dict(spec), sort_keys=True, default=str)
        cache = st.session_state.get(f"{key}_images")
        if cache is not None and cache["for"] != fingerprint:
            cache = None
        c = st.columns([2, 3], vertical_alignment="bottom")
        if c[0].button("Create images", key=f"{key}_images_create",
                       help=f"Draws the {spec.n_columns} switches of a cycle (columns, pipes, ports, flows)."):
            with st.spinner("Drawing the switches…"):
                pngs = [smb_media.layout_png(spec, s) for s in range(spec.n_columns)]
                cache = {"for": fingerprint, "pngs": pngs, "zip": smb_media.layout_zip(spec)}
            st.session_state[f"{key}_images"] = cache
        if cache is None:
            c[1].caption("Images follow the current layout and flows.")
            return
        stem = file_stem(spec.title, "smb_layout")
        c[1].download_button(f"💾 All {spec.n_columns} switches (ZIP)", cache["zip"], f"{stem}_switches.zip",
                             "application/zip", key=f"{key}_images_zip")
        d = st.columns([2, 3], vertical_alignment="bottom")
        s = d[0].selectbox("Switch", range(spec.n_columns), format_func=lambda i: f"switch {i + 1}",
                           key=f"{key}_images_switch")
        d[1].download_button(f"💾 Switch {s + 1} (PNG)", cache["pngs"][s], f"{stem}_switch_{s + 1:02d}.png",
                             "image/png", key=f"{key}_images_png")
        st.image(cache["pngs"][s])
