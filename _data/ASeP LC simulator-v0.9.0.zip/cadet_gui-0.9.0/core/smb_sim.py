"""Running an SMB cycle by cycle in the background (progress, cancel, cyclic steady state)."""
import numpy as np

from core import smb, tolerances
from core.simulator import SimulationJob, create_simulator


def cycle_difference(results, spec: smb.SMBSpec):
    """Largest difference between the last two cycles over every outlet stream and every column outlet:
    per component, the change of the area and the RMS change of the concentration, both relative to the
    larger of that component's peak / area and a floor of 1e-6 of the largest feed or eluent concentration
    (so streams that carry (almost) nothing do not divide by zero)."""
    comps = spec.components
    scale = max([float(v) * c.liquid_factor() for v, c in zip(list(spec.feed) + list(spec.eluent), comps + comps)]
                + [1e-30])
    floor = 1e-6 * scale
    cycles = results.solution_cycles
    units_ = list(spec.geometry.outlets) + [f"column_{i}" for i in range(spec.n_columns)]
    worst = 0.0
    for unit in units_:
        solutions = cycles[unit]["outlet"]
        if len(solutions) < 2:
            return np.inf
        new, old = np.asarray(solutions[-1].solution, float), np.asarray(solutions[-2].solution, float)
        if new.shape != old.shape:
            return np.inf
        peak = np.maximum(np.max(np.abs(old), axis=0), floor)
        nrmse = np.sqrt(np.mean((new - old) ** 2, axis=0)) / peak
        area_old, area_new = old.sum(axis=0), new.sum(axis=0)
        area = np.abs(area_new - area_old) / np.maximum(np.abs(area_old), floor * len(old))
        worst = max(worst, float(np.max(nrmse)), float(np.max(area)))
    return worst


class SMBJob(SimulationJob):
    """One background SMB run: one CADET run per cycle, each continuing from the previous state.

    ``cycle`` counts finished cycles; ``max_cycles`` is the planned (fixed) or the largest (steady
    state) number; ``converged`` is True / False once a steady-state run ends (None for fixed runs).
    """

    def __init__(self, spec: smb.SMBSpec, initial_state=None):
        super().__init__(spec, initial_state)
        cyc = spec.cycles
        self.max_cycles = int(cyc.n_cycles if cyc.mode == "fixed" else cyc.max_cycles)
        self.cycle = 0
        self.converged = None
        self.differences = []          # cycle_difference after every cycle from the second on

    def _set_run_progress(self, fraction):
        self.progress = min((self.cycle + fraction) / max(self.max_cycles, 1), 0.999)

    def _simulate(self):
        spec = self.spec
        settings = spec.base.settings
        process = smb.build_process(spec, self.initial_state)
        self.tolerances = tolerances.effective_tolerances(spec.base)
        sim = create_simulator(settings.output_interval, settings.timeout, self.tolerances)
        steady = spec.cycles.mode == "steady state"
        results = None
        for k in range(self.max_cycles):
            if self._cancel.is_set():
                raise RuntimeError("Simulation cancelled")
            if results is not None:
                sim.set_state_from_results(process, results)
            new = self._run_process(sim, process, settings.timeout)
            if results is None:
                results = new
            else:
                results.update(new)
            self.cycle = k + 1
            if k >= 1:
                self.differences.append(cycle_difference(results, spec))
                if steady and self.differences[-1] <= spec.cycles.threshold:
                    self.converged = True
                    break
        else:
            if steady:
                self.converged = False
        return results


def run_smb(spec: smb.SMBSpec, initial_state=None):
    """Blocking run; returns ``(SimulationResults, job)``."""
    job = SMBJob(spec, initial_state).start().wait()
    if job.status != "done":
        raise RuntimeError(job.error)
    return job.results, job
