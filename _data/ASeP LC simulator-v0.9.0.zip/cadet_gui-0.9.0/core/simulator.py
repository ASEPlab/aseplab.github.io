"""Run CADET in the background with progress (spec §7 진행률).

CADET-Process's own run path gives no live progress, so ``SimulationJob``
writes the CADET input file through CADET-Process, runs ``cadet-cli --progress``
itself and parses its progress bar ("[====>   ]  42.3% (...) Section"). The bar
is only drawn on a terminal, so on POSIX the CLI runs under a pseudo-terminal;
elsewhere it runs without progress. Results are loaded back through
CADET-Process exactly as ``Cadet.simulate`` does.
"""
import os
import re
import subprocess
import sys
import tempfile
import threading
import time

import numpy as np
from cadet.runner import ReturnInformation
from CADETProcess.simulator import Cadet

from core import tolerances, units
from core.model_builder import BatchSpec, build_process

_PERCENT = re.compile(rb"(\d+(?:\.\d+)?)%")
_BAR = re.compile(rb"^\s*\[[=> ]*\]")


def cadet_root():
    """Root of the CADET installation in the running Python environment: ``sys.prefix`` on macOS / Linux,
    ``sys.prefix/Library`` for conda on Windows (where cadet-cli.exe is in Library\\bin)."""
    exe = "cadet-cli.exe" if os.name == "nt" else "cadet-cli"
    for root in (sys.prefix, os.path.join(sys.prefix, "Library")):
        for sub in ("bin", "Scripts"):
            if os.path.isfile(os.path.join(root, sub, exe)):
                return root
    raise FileNotFoundError(f"cadet-cli was not found in this Python environment ({sys.prefix}). Install the app's "
                            "conda environment (install script or environment.yml).")


def create_simulator(output_interval_min=0.05, timeout_s=None, tol: tolerances.Tolerances | None = None):
    """CADET simulator using the cadet-cli of the running Python environment.

    The install path is derived from ``sys.prefix`` (``cadet_root``) so it works without an
    activated conda env on PATH. ``timeout_s`` stops a stuck solver; ``tol`` sets
    the integrator tolerances (CADET's defaults if omitted).
    """
    sim = Cadet(install_path=cadet_root())
    sim.time_resolution = float(units.time_to_si(output_interval_min))
    if timeout_s:
        sim.timeout = float(timeout_s)
    if tol is not None:
        params = sim.time_integrator_parameters
        params.reltol, params.abstol, params.algtol = tol.reltol, tol.abstol, tol.algtol
    return sim


def nonfinite_paths(node, path=""):
    """Paths of NaN / inf entries in a CADET input tree (dicts of arrays)."""
    if isinstance(node, dict):
        for key, value in node.items():
            yield from nonfinite_paths(value, f"{path}/{key}")
        return
    try:
        arr = np.asarray(node, dtype=float)
    except (TypeError, ValueError):
        return
    if arr.size and not np.all(np.isfinite(arr)):
        yield path


def _log_text(raw: bytes) -> str:
    """CLI output without progress-bar redraws."""
    parts = [p for p in re.split(rb"[\r\n]+", raw) if p.strip() and not _BAR.match(p)]
    return b"\n".join(parts).decode("utf-8", errors="replace")


class SimulationJob:
    """One background CADET run. Poll ``progress`` (0–1), ``status`` and ``eta``.

    ``status``: "pending", "running", "done", "failed" or "cancelled".
    On success ``results`` holds CADET-Process ``SimulationResults``; otherwise
    ``error`` holds a message.
    """

    def __init__(self, spec: BatchSpec, initial_state=None):
        self.spec = spec
        self.initial_state = initial_state     # (state, state_derivative) or None
        self.status = "pending"
        self.progress = 0.0
        self.results = None
        self.tolerances = None                 # the tolerances actually used, set when the run starts
        self.error = None
        self.started = None
        self.finished = None
        self._proc = None
        self._cancel = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    # --- control ---------------------------------------------------------------
    def start(self):
        self.started = time.time()
        self.status = "running"
        self._thread.start()
        return self

    def wait(self, timeout=None):
        self._thread.join(timeout)
        return self

    def cancel(self):
        self._cancel.set()
        if self._proc is not None and self._proc.poll() is None:
            self._proc.terminate()

    # --- state -----------------------------------------------------------------
    @property
    def done(self):
        return self.status in ("done", "failed", "cancelled")

    @property
    def elapsed(self):
        if self.started is None:
            return 0.0
        return (self.finished or time.time()) - self.started

    @property
    def eta(self):
        """Estimated seconds remaining, or None before any progress."""
        if self.done or self.progress <= 0.01:
            return None
        return self.elapsed * (1 - self.progress) / self.progress

    def _set_run_progress(self, fraction):
        """Progress of the current CADET run (0–1); jobs with several runs map it onto their share."""
        self.progress = min(fraction, 0.999)

    # --- worker ----------------------------------------------------------------
    def _run(self):
        try:
            self.results = self._simulate()
            self.progress = 1.0
            self.status = "done"
        except Exception as e:  # reported to the UI through ``error``
            self.error = str(e) or type(e).__name__
            self.status = "cancelled" if self._cancel.is_set() else "failed"
        finally:
            self.finished = time.time()

    def _simulate(self):
        settings = self.spec.settings
        process = build_process(self.spec, self.initial_state)
        self.tolerances = tolerances.effective_tolerances(self.spec)
        sim = create_simulator(settings.output_interval, settings.timeout, self.tolerances)
        return self._run_process(sim, process, settings.timeout)

    def _run_process(self, sim, process, timeout):
        """One CADET run of ``process``; returns CADET-Process ``SimulationResults``."""
        cadet = sim.get_new_cadet_instance()
        cadet.root = sim.get_process_config(process)
        bad = list(nonfinite_paths(cadet.root.input))
        if bad:      # CADET does not stop on NaN: it spins at 0% until the timeout
            raise ValueError("The input contains empty or non-finite values (CADET parameter "
                             + ", ".join(p.removeprefix("/") for p in bad[:5]) + "). Check the input tables "
                             "for blank cells.")
        fd, path = tempfile.mkstemp(suffix=".h5", prefix="cadet_gui_")
        os.close(fd)
        try:
            cadet.filename = path
            cadet.save()
            start = time.time()
            code, raw = self._run_cli(cadet.cadet_runner.cadet_path, path, timeout)
            elapsed = time.time() - start
            if self._cancel.is_set():
                raise RuntimeError("Simulation cancelled")
            log = _log_text(raw)
            if code != 0:
                raise RuntimeError(f"CADET failed (return code {code}): {log[-800:]}")
            cadet.load_from_file(paths=["/meta", "/output"], update=True)
            info = ReturnInformation(return_code=code, error_message="", log=log)
            return sim.get_simulation_results(process, cadet, elapsed, info)
        finally:
            os.remove(path)

    def _run_cli(self, cli, path, timeout):
        """Run cadet-cli; returns (return code, raw output). Updates ``progress``."""
        if os.name != "posix":
            self._proc = subprocess.Popen([cli, path], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            try:
                out, _ = self._proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                self._proc.kill()
                raise RuntimeError(f"Simulation timed out after {timeout:g} s") from None
            return self._proc.returncode, out

        import pty
        import select
        master, slave = pty.openpty()
        try:
            self._proc = subprocess.Popen([cli, "--progress", path], stdout=slave, stderr=slave, close_fds=True)
        finally:
            os.close(slave)
        raw = b""
        deadline = time.time() + timeout if timeout else None
        try:
            while True:
                ready, _, _ = select.select([master], [], [], 0.2)
                if ready:
                    try:
                        chunk = os.read(master, 65536)
                    except OSError:          # Linux: EIO once the child closes the pty
                        chunk = b""
                    if not chunk:
                        break
                    raw += chunk
                    found = _PERCENT.findall(chunk)
                    if found:
                        self._set_run_progress(float(found[-1]) / 100.0)
                elif self._proc.poll() is not None:
                    break
                if deadline and time.time() > deadline:
                    self._proc.kill()
                    raise RuntimeError(f"Simulation timed out after {timeout:g} s")
        finally:
            os.close(master)
        return self._proc.wait(), raw


def run_batch(spec: BatchSpec, initial_state=None):
    """Build and simulate ``spec`` (blocking); returns CADET-Process ``SimulationResults``."""
    job = SimulationJob(spec, initial_state).start().wait()
    if job.status != "done":
        raise RuntimeError(job.error)
    return job.results
