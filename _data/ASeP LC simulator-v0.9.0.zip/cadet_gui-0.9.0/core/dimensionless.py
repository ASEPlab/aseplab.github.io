"""Dimensionless groups and diagnostics (spec §5.3, VERSE definitions).

All in GUI units (cm, min); the groups are unit-free.
  1/Pe  = Eb/(u·L)
  Nf    = 3(L/R)·(1−εb)·kf/(εb·u)
  ND    = (1−εb)·εp·L·Dp/(εb·u·R²)
  Bi    = kf·R/(εp·Dp) = Nf/(3·ND)
  N_eff = 3(L/R)·(1−εb)·keff/(εb·u)
For the LRM (no pores) the velocity is u_t = Q/(εt·A).
"""
import numpy as np

from core import reactions as rx
from core import units

GROUPS_BY_MODEL = {
    "GRM": ("1/Pe", "Nf", "ND", "Bi"),
    "LRMP": ("1/Pe", "Nf"),
    "LRM_keff": ("1/Pe", "N_eff"),
    "LRM": ("1/Pe",),
}


def velocity(column, flow_ml_min):
    """Velocity [cm/min] used by the model's transport equation."""
    if column.model == "LRM":
        return float(units.interstitial_velocity(flow_ml_min, column.diameter, column.total_porosity()))
    return float(units.interstitial_velocity(flow_ml_min, column.diameter, column.eps_b))


def groups(column, flow_ml_min, n_comp=None):
    """Per-component dimensionless groups for ``column`` (a ``ColumnSpec``).

    Returns ``{name: array over components}`` (1/Pe is broadcast to all components;
    ``n_comp`` defaults to the number of film coefficients).
    """
    u = velocity(column, flow_ml_min)
    L, eps_b, eps_p = column.length, column.eps_b, column.eps_p
    R = float(units.length_from_si(units.radius_to_si(column.radius)))   # µm -> cm
    names = GROUPS_BY_MODEL[column.model]
    n = n_comp or (len(column.film_diffusion) if column.film_diffusion is not None else 1)
    out = {"1/Pe": np.full(n, column.axial_dispersion / (u * L))}
    k = np.asarray(column.film_diffusion, dtype=float) if column.film_diffusion is not None else None
    if "Nf" in names:
        out["Nf"] = 3 * (L / R) * (1 - eps_b) * k / (eps_b * u)
    if "N_eff" in names:
        out["N_eff"] = 3 * (L / R) * (1 - eps_b) * k / (eps_b * u)
    if "ND" in names:
        dpore = np.asarray(column.pore_diffusion, dtype=float)
        out["ND"] = (1 - eps_b) * eps_p * L * dpore / (eps_b * u * R ** 2)
        out["Bi"] = k * R / (eps_p * dpore)
    return out


def diagnose(values, names):
    """Plain-language diagnostics (spec §5.3 criteria) per component."""
    messages = []
    inv_pe = values["1/Pe"][0]
    if inv_pe < 0.01:
        messages.append(f"1/Pe = {inv_pe:.2g} < 0.01: axial dispersion has a small effect.")
    else:
        messages.append(f"1/Pe = {inv_pe:.2g} ≥ 0.01: axial dispersion noticeably broadens peaks.")
    if "Bi" in values:
        for name, bi in zip(names, values["Bi"]):
            limit = "pore diffusion" if bi > 1 else "film diffusion"
            messages.append(f"{name}: Bi = {bi:.3g} → {limit} is rate-limiting.")
    return messages


# --- Reactions (spec §5.3) -------------------------------------------------------

def inlet_max(spec):
    """Largest inlet concentration of each component over the run (GUI liquid units)."""
    segments = spec.operation.program()
    ends = [seg.start for seg in segments[1:]] + [spec.settings.duration]
    out = np.zeros(len(spec.components))
    for seg, end in zip(segments, ends):
        tau = end - seg.start
        for i, poly in enumerate(seg.coefficients):
            values = [sum(a * t ** k for k, a in enumerate(poly)) for t in (0.0, tau)]
            out[i] = max(out[i], *values)
    return out


def reaction_groups(spec):
    """Per reaction: Nk+ = L·k+·C^(n+−1)/u, Nk− = L·k−·C^(n−−1)/u and their ratio,
    with C the largest inlet concentration among the reactants (reaction basis)."""
    system = spec.reactions
    if system is None:
        return []
    names = [c.name for c in spec.components]
    c_max = inlet_max(spec)
    u = velocity(spec.column, spec.operation.flow_rate)
    L = spec.column.length
    f_basis = units.liquid_factor(system.basis)
    out = []
    for reaction in system.reactions:
        reactants, products = rx.parse_equation(reaction.equation, names)
        n_fwd, n_bwd = rx.orders(reactants, products)
        k_fwd, k_bwd = rx.rates(reaction)
        c_ref = max(c_max[names.index(n)] * spec.components[names.index(n)].liquid_factor() / f_basis
                    for n in reactants)
        nk_fwd = L * k_fwd * c_ref ** (n_fwd - 1) / u
        nk_bwd = L * k_bwd * c_ref ** (n_bwd - 1) / u
        if nk_bwd == 0:
            ratio = float("inf") if nk_fwd > 0 else float("nan")
            note = ("k− = 0: irreversible reaction." if nk_fwd > 0
                    else "k+ and k− are both 0: the reaction does nothing.")
        else:
            ratio = nk_fwd / nk_bwd
            note = ("Nk− ≫ 1: the reaction stays near equilibrium (rate constants matter little beyond Ka)."
                    if nk_bwd >= 10 else
                    "Nk− ≲ 1: reaction kinetics shape the result; k+ and k− both matter.")
        out.append({"reaction": reaction.equation, "Nk+": nk_fwd, "Nk−": nk_bwd, "Nk+/Nk−": ratio, "note": note})
    return out
