"""Component definitions (spec §6 성분 정의): name, MW, ν, adsorbs, units."""
from dataclasses import dataclass

from core import units


@dataclass
class Component:
    name: str
    mw: float | None = None             # g/mol; needed for g/L, mg/L
    charge: float | None = None         # ν; needed for meq/L (shared with GIEX)
    bound: bool = True                  # adsorbs (1 bound state) or not (0)
    liquid_unit: str = "mmol/L"         # one of units.LIQUID_UNITS
    solid_unit: str = "mmol/mL solid"   # "<amount>/<basis>", see units.solid_factor

    def liquid_factor(self):
        """GUI liquid concentration -> mol/m³."""
        return units.liquid_factor(self.liquid_unit, self.mw, self.charge)

    def solid_factor(self, eps_t=None, eps_p=None, density=None, density_basis="solid"):
        """GUI stationary-phase concentration -> mol/m³ solid."""
        return units.solid_factor(self.solid_unit, self.mw, self.charge,
                                  eps_t=eps_t, eps_p=eps_p, density=density, density_basis=density_basis)


SALT_NAME, PH_NAME = "salt", "pH"


def giex_modulators(salt_unit="mmol/L", capacity_unit="meq/mL solid"):
    """The two components GIEX needs in front of the solutes (spec §5.4).

    They are not entered by the user: the form adds them when the binding model is
    GIEX. Salt is the counter-ion (ν = 1, adsorbs, its solid unit is the capacity
    unit); pH is the modulator (unit "pH", never adsorbs).
    """
    return [Component(SALT_NAME, charge=1.0, bound=True, liquid_unit=salt_unit, solid_unit=capacity_unit),
            Component(PH_NAME, bound=False, liquid_unit=units.MODULATOR_UNIT)]


def modulators(count, salt_unit="mmol/L", capacity_unit="meq/mL solid"):
    """The first ``count`` GIEX modulators: 1 = salt (SMA), 2 = salt and pH (GIEX)."""
    return giex_modulators(salt_unit, capacity_unit)[:count]
