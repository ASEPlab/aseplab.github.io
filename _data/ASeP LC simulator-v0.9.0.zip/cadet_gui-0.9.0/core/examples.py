"""Ready-made inputs in GUI units: the form's startup state and the Examples list.

They are written the way the Batch form writes a spec (full per-component lists,
``None`` for the salt / pH entries of GIEX), so loading one into the form and reading
it back gives an equal spec.
"""
from core import model_builder as mb
from core import reactions as rx
from core.components import Component, giex_modulators


def default() -> mb.BatchSpec:
    """Two components with Langmuir binding on a GRM column."""
    return mb.BatchSpec(
        title="Two components, Langmuir",
        components=[Component("A"), Component("B")],
        column=mb.ColumnSpec(
            model="GRM", length=10.0, diameter=1.0, eps_b=0.37, eps_p=0.5, radius=25.0,
            axial_dispersion=6e-3, film_diffusion=[0.06, 0.06], pore_diffusion=[1e-4, 1e-4],
            initial_liquid=[0.0, 0.0], initial_solid=[0.0, 0.0]),
        binding=mb.BindingSpec("Langmuir", kinetic=False, equilibrium=[0.05, 0.02],
                               adsorption_rate=[0.05, 0.02], desorption_rate=[1.0, 1.0], capacity=[0.1, 0.1]),
        operation=mb.OperationSpec(1.0, [mb.constant(0.0, [0.0, 0.0])],
                                   injection=mb.Injection(volume=0.5, start=0.0, feed=[1.0, 1.0])),
        settings=mb.SimulationSettings(duration=40.0, output_interval=0.02, n_col=100, n_par=5, timeout=600.0),
    )


def giex_metals(with_ligand=False) -> mb.BatchSpec:
    """Two divalent metals injected onto a cation exchanger and eluted by a salt gradient at pH 7 (spec §5.4);
    optionally with a non-adsorbing ligand L that complexes both in the mobile phase (spec §5.5)."""
    solutes = [Component("M1", mw=63.546, charge=2.0), Component("M2", mw=58.693, charge=2.0)]
    if with_ligand:
        solutes += [Component(name, bound=False) for name in ("L", "M1L", "M2L")]
    comps = giex_modulators() + solutes
    n, ns = len(comps), len(solutes)
    pad = [None, None]                                    # salt and pH have no isotherm parameters
    metals = lambda a, b, rest: pad + [a, b] + [rest] * (ns - 2)       # noqa: E731
    triples = [[0.0, 0.0, 0.0] for _ in range(ns)]

    def inlet(salt, ph, m1, m2, ligand=0.0):
        return [salt, ph, m1, m2] + ([ligand, 0.0, 0.0] if with_ligand else [])

    # eluent: 50 mM salt, then a linear gradient from 5 to 25 min up to 500 mM; 1 mL of both metals is injected
    starts, shapes = [0.0, 5.0, 25.0], ["step", "linear", "step"]
    rows = [inlet(50.0, 7.0, 0.0, 0.0, 0.5), inlet(50.0, 7.0, 0.0, 0.0, 0.5), inlet(500.0, 7.0, 0.0, 0.0, 0.5)]
    return mb.BatchSpec(
        title="GIEX: two metals + ligand L" if with_ligand else "GIEX: two metals, salt gradient",
        components=comps,
        column=mb.ColumnSpec(
            model="LRMP", length=10.0, diameter=1.0, eps_b=0.37, eps_p=0.5, radius=25.0,
            axial_dispersion=6e-3, film_diffusion=[0.06] * n,
            initial_liquid=[50.0, 7.0] + [0.0] * ns, initial_solid=[0.0] * n),
        binding=mb.BindingSpec(
            "GIEX", kinetic=False, equilibrium=metals(0.01, 0.03, None), capacity=metals(1.0, 1.0, 1.0),
            adsorption_rate=metals(0.6, 1.8, None), desorption_rate=metals(60.0, 60.0, None),
            giex=mb.GiexSpec(
                capacity=1.2, capacity_unit="meq/mL solid", reference_liquid=100.0, reference_solid=None,
                ph_ref=7.0, steric_factor=pad + [0.0] * ns,
                adsorption_ph=pad + [list(t) for t in triples], desorption_ph=pad + [list(t) for t in triples],
                charge_ph=pad + [list(t) for t in triples],
                adsorption_salt=pad + [0.0] * ns, desorption_salt=pad + [0.0] * ns,
                adsorption_protein=pad + [0.0] * ns, desorption_protein=pad + [0.0] * ns)),
        operation=mb.OperationSpec(1.0, mb.inlet_from_table(starts, shapes, rows),
                                   injection=mb.Injection(volume=1.0, start=0.0,
                                                          feed=inlet(50.0, 7.0, 1.0, 1.0, 0.5))),
        settings=mb.SimulationSettings(duration=40.0, output_interval=0.02, n_col=100, n_par=5, timeout=600.0),
        reactions=rx.ReactionSystem("mol/L", [rx.ReactionSpec("M1 + L = M1L", 1e5, 100.0),     # Ka = 1e3 L/mol
                                              rx.ReactionSpec("M2 + L = M2L", 1e6, 100.0)])   # Ka = 1e4 L/mol
        if with_ligand else None,
    )


EXAMPLES = {
    "Two components, Langmuir (startup default)": default,
    "GIEX: two metals, salt gradient": giex_metals,
    "GIEX: two metals + ligand L (M1L, M2L)": lambda: giex_metals(with_ligand=True),
}


def smb_binary():
    """SMB example: the two Langmuir components of ``default()`` in a closed 1-1-1-1 SMB whose flows come from
    the triangle theory (safety factor 1.1), entered as external flows."""
    from core import smb
    base = default()
    base.column.model, base.column.pore_diffusion = "LRMP", None
    base.settings.n_col, base.settings.output_interval = 30, 0.05
    spec = smb.SMBSpec(base=base, layout="4-zone closed", columns_per_zone=[1, 1, 1, 1], switch_time=3.0,
                       flow_mode="m", flows=[0.0] * 4, feed=[1.0, 1.0], eluent=[0.0, 0.0],
                       title="SMB: A / B, Langmuir")
    spec.flows = smb.triangle_design(spec, gamma=1.1)
    spec.flows = [round(v, 3) for v in smb.flows_as(spec, "external")]
    spec.flow_mode = "external"
    spec.products = smb.default_products(spec)
    base.title = spec.title
    return spec


SMB_EXAMPLES = {
    "Two components, Langmuir (4-zone, triangle design)": smb_binary,
}
