"""Mobile-phase mass-action reactions (spec §5.5).

Reactions are written as text, e.g. "M1 + L = M1L" or "M + B-C = B-M + C";
"=", "<=>" and "⇌" all separate the sides, and a stoichiometric coefficient is a
number followed by a space ("2 L"). Reactions apply in the bulk and the particle
(pore) liquid alike.

Every reaction is kinetic with user-given k+ and k−. Rate constants use a molar
concentration basis (mol/L or mmol/L), independent of each component's display unit:
  forward  r+ = k+·Π c_reactant^ν     k+ [basis^(1−n+)/min], n+ = Σ reactant ν
  backward r− = k−·Π c_product^ν      k− [basis^(1−n−)/min], n− = Σ product ν
  Ka = k+/k−                          [basis^(n− − n+)]   (shown, not entered)
"""
import re
from dataclasses import dataclass, field

from core import units

REACTION_BASES = ("mol/L", "mmol/L")
_ARROW = re.compile(r"\s*(?:<=>|⇌|<->|=)\s*")
_TERM = re.compile(r"^(\d+(?:\.\d+)?)\s+(\S.*)$")

@dataclass
class ReactionSpec:
    equation: str
    k_fwd: float | None = None        # k+
    k_bwd: float | None = None        # k−

    @classmethod
    def from_dict(cls, d):
        """Ignores keys of older files (e.g. a former rapid-equilibrium mode)."""
        return cls(equation=d["equation"], k_fwd=d.get("k_fwd"), k_bwd=d.get("k_bwd"))

    @property
    def equilibrium(self):
        """Ka = k+/k− (None if either is missing or k− = 0)."""
        if self.k_fwd is None or not self.k_bwd:
            return None
        return self.k_fwd / self.k_bwd


@dataclass
class ReactionSystem:
    basis: str = "mol/L"
    reactions: list = field(default_factory=list)


def _side(text, names, equation):
    terms = {}
    for raw in text.split("+"):
        term = raw.strip()
        if not term:
            raise ValueError(f"Empty term in reaction {equation!r}")
        m = _TERM.match(term)
        coeff, name = (float(m.group(1)), m.group(2).strip()) if m else (1.0, term)
        if name not in names:
            raise ValueError(f"Reaction {equation!r}: unknown component {name!r}")
        terms[name] = terms.get(name, 0.0) + coeff
    return terms


def parse_equation(equation, names):
    """Return ``(reactants, products)`` as ``{name: coefficient}`` dicts."""
    parts = _ARROW.split(equation.strip())
    if len(parts) != 2:
        raise ValueError(f"Reaction {equation!r} needs exactly one '=' between reactants and products")
    reactants, products = (_side(p, names, equation) for p in parts)
    if set(reactants) & set(products):
        raise ValueError(f"Reaction {equation!r}: a component appears on both sides")
    return reactants, products


def orders(reactants, products):
    return sum(reactants.values()), sum(products.values())


def _basis_factor(basis):
    if basis not in REACTION_BASES:
        raise ValueError(f"Unknown reaction basis {basis!r}; expected one of {REACTION_BASES}")
    return units.liquid_factor(basis)


def rate_to_si(k, order, basis):
    """k [basis^(1−order)/min] -> [(mol/m³)^(1−order)/s]."""
    return k * _basis_factor(basis) ** (1 - order) / units.time_factor("min")


def equilibrium_to_si(ka, n_fwd, n_bwd, basis):
    """Ka [basis^(n− − n+)] -> SI."""
    return ka * _basis_factor(basis) ** (n_bwd - n_fwd)


def rates(reaction: ReactionSpec):
    """(k+, k−) in GUI units, checked."""
    if reaction.k_fwd is None or reaction.k_bwd is None:
        raise ValueError(f"Reaction {reaction.equation!r} needs both k+ and k−")
    if reaction.k_fwd < 0 or reaction.k_bwd < 0:
        raise ValueError(f"Reaction {reaction.equation!r}: k+ and k− cannot be negative")
    return reaction.k_fwd, reaction.k_bwd


def _inverse(basis):
    amount, _, volume = basis.partition("/")
    return f"{volume}/{amount}"


def rate_unit(order, basis):
    """Display unit of a rate constant of the given reaction order."""
    if order == 1:
        return "1/min"
    if order == 2:
        return f"{_inverse(basis)}/min"
    return f"({basis})^{1 - order:g}/min"


def equilibrium_unit(n_fwd, n_bwd, basis):
    delta = n_bwd - n_fwd
    if delta == 0:
        return "–"
    if delta == -1:
        return _inverse(basis)
    if delta == 1:
        return basis
    return f"({basis})^{delta:g}"


def units_text(equation, names, basis):
    """Units of k+, k− and Ka for ``equation``, or the parse error."""
    try:
        reactants, products = parse_equation(equation, names)
    except ValueError as e:
        return str(e)
    n_fwd, n_bwd = orders(reactants, products)
    return (f"k+: {rate_unit(n_fwd, basis)} · k−: {rate_unit(n_bwd, basis)} · "
            f"Ka: {equilibrium_unit(n_fwd, n_bwd, basis)}")
