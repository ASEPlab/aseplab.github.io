"""SMB results in GUI units, performance numbers per cycle, and the SMB result file.

Arrays (GUI units):
  time                (nt,)                          min, all cycles
  outlets[name]       (nt, ncomp)                    every outlet stream of the layout (extract(s), raffinate,
                                                     waste), each component's liquid unit
  column_outlets      (ncolumns, nt, ncomp)          outlet of each physical column
  z                   (ncell,)                       cm, axial cell centres of one column
  profile_time        (np,)                          min, the whole run (every output time, or every k-th:
                                                     see ``profile_stride``)
  bulk, pore, solid   (np, ncolumns, ncell, ncomp)   physical column order (``smb.column_order`` gives the
                                                     ring order at a time); float32
"""
import io
import json
from dataclasses import dataclass, field
from datetime import datetime

import h5py
import numpy as np
import pandas as pd

from core import model_builder as mb
from core import smb, units
from core.mass import default_amount_unit
from core.results_io import _liquid, _particle_average, _solid

FILE_FORMAT = "cadet_gui.smb_result"
EXTENSION = "smbh5"            # an HDF5 file; its own extension keeps it apart from Batch results (.h5)
FILE_VERSION = 1
PHASES = ("bulk", "pore", "solid")
PROFILE_TIMES = 3000          # automatic: at most this many stored profile times …
PROFILE_VALUES = 5e7          # … and at most this many values per phase (float32: 200 MB in memory, less on disk)
_ARRAYS = ("time", "column_outlets", "z", "profile_time") + PHASES + ("final_state", "final_state_derivative")


@dataclass
class SMBResult:
    spec: smb.SMBSpec
    time: np.ndarray
    outlets: dict
    column_outlets: np.ndarray | None = None
    z: np.ndarray | None = None
    profile_time: np.ndarray | None = None
    bulk: np.ndarray | None = None
    pore: np.ndarray | None = None
    solid: np.ndarray | None = None
    summary: dict = field(default_factory=dict)
    final_state: np.ndarray | None = None
    final_state_derivative: np.ndarray | None = None

    @property
    def components(self):
        return self.spec.components

    @property
    def n_cycles(self):
        return int(self.summary.get("n_cycles", round(self.time[-1] / self.spec.cycle_time)))

    def phases(self):
        return [p for p in PHASES if getattr(self, p) is not None]

    def unit(self, phase, i):
        comp = self.components[i]
        return comp.solid_unit if phase == "solid" else comp.liquid_unit

    def solutes(self):
        """Indices of the components that count for purity (not salt / pH)."""
        return list(range(mb.modulator_count(self.spec.base.binding.model), len(self.components)))

    def outlet_dataframe(self):
        data = {"time [min]": self.time}
        for name, values in self.outlets.items():
            for i, comp in enumerate(self.components):
                data[f"{smb.STREAM_LABELS[name]} {comp.name} [{comp.liquid_unit}]"] = values[:, i]
        return pd.DataFrame(data)

    def ring_profile(self, phase, k):
        """``(positions, data)`` of ``phase`` at ``profile_time[k]`` along the ring: data (ncolumns·ncell,
        ncomp) in ring order (zone I first), positions in column lengths (0 … ncolumns)."""
        data = getattr(self, phase)[k]
        order = smb.column_order(self.spec, self.profile_time[k])
        length = self.spec.base.column.length
        positions = np.concatenate([p + self.z / length for p in range(len(order))])
        return positions, np.concatenate([data[c] for c in order], axis=0)


# --- From CADET-Process ------------------------------------------------------------------------

def profile_stride(spec, n_times, values_per_time):
    """Every how many output times a column profile is stored: from ``spec.profile_interval`` if set, and at
    least enough to keep ≤ ``PROFILE_TIMES`` times and ≤ ``PROFILE_VALUES`` values per phase."""
    dt = spec.base.settings.output_interval
    user = int(round(spec.profile_interval / dt)) if spec.profile_interval and spec.profile_interval > 0 else 1
    auto = max(int(np.ceil(n_times / PROFILE_TIMES)), int(np.ceil(n_times * values_per_time / PROFILE_VALUES)), 1)
    return max(user, auto)


def from_cadet(results, spec: smb.SMBSpec, converged=None, differences=None) -> SMBResult:
    """``converged``: steady-state outcome (None for a fixed number of cycles); ``differences``: the
    cycle-to-cycle difference after every cycle from the second on (``core.smb_sim.cycle_difference``)."""
    comps = spec.components
    sol = results.solution
    n = spec.n_columns
    names = spec.geometry.outlets
    time = units.time_from_si(sol[names[0]].inlet.time)
    columns = [sol[f"column_{i}"] for i in range(n)]
    outlets = np.stack([_liquid(c.outlet.solution, comps) for c in columns])

    # Profiles over the whole run, every k-th output time (k from the profile interval or automatic).
    cycle = spec.cycle_time
    keys0 = columns[0].keys()
    ncell = len(columns[0].bulk.axial_coordinates) if "bulk" in keys0 else 1
    k = profile_stride(spec, len(time), n * ncell * len(comps))
    keep = np.zeros(len(time), dtype=bool)
    keep[::k] = True
    keep[-1] = True
    profile_time = time[keep]
    radius = float(units.radius_to_si(spec.base.column.radius))
    keys = keys0
    z = bulk = pore = solid = None
    if "bulk" in keys:
        bulk = np.stack([_liquid(c.bulk.solution[keep], comps) for c in columns], axis=1).astype(np.float32)
        z = units.length_from_si(columns[0].bulk.axial_coordinates)
    if "particle" in keys:
        pore = np.stack([_liquid(_particle_average(c.particle, radius)[keep], comps) for c in columns],
                        axis=1).astype(np.float32)
    if "solid" in keys and columns[0].solid.solution.shape[-1] > 0:
        solid = np.stack([_solid(_particle_average(c.solid, radius)[keep], spec.base) for c in columns],
                         axis=1).astype(np.float32)

    n_cycles = int(results.n_cycles) if getattr(results, "n_cycles", None) else int(round(time[-1] / cycle))
    return SMBResult(
        spec=spec, time=time,
        outlets={name: _liquid(sol[name].inlet.solution, comps) for name in names},
        column_outlets=outlets, z=z, profile_time=profile_time, bulk=bulk, pore=pore, solid=solid,
        final_state=np.asarray(results.system_state["state"]),
        final_state_derivative=np.asarray(results.system_state["state_derivative"]),
        summary={
            "exit_flag": int(results.exit_flag),
            "exit_message": results.exit_message or "",
            "time_elapsed_s": float(results.time_elapsed),
            "n_cycles": n_cycles,
            "converged": converged,
            "cycle_differences": [float(v) for v in (differences or [])],
            "threshold": float(spec.cycles.threshold),
            "profile_stride": int(k),
            "completed": datetime.now().isoformat(timespec="seconds"),
        },
    )


# --- Performance --------------------------------------------------------------------------------

def _upstream_position(spec, outlet):
    """Ring position of the column whose outlet feeds ``outlet``."""
    pos = smb.port_positions(spec)[outlet]
    return (pos - 1) % spec.n_columns


def _switch_edges(spec, t0, t1):
    """Switch-interval boundaries between t0 and t1 [min]."""
    ts = spec.switch_time
    edges = [t0]
    while edges[-1] < t1 - 1e-9:
        edges.append(min(t1, (np.floor(edges[-1] / ts + 1e-9) + 1) * ts))
    return edges


def _stream(result, outlet, a, b):
    """``(time, concentrations (n, ncomp))`` of ``outlet`` within one switch interval [a, b], taken from the
    outlet of the column feeding the port: continuous in time, while the port stream itself jumps at every
    switch (a trapezoid across the jump would be off by up to half an output interval per switch)."""
    t = result.time
    sel = (t >= a - 1e-9) & (t <= b + 1e-9)
    if result.column_outlets is None:
        return t[sel], result.outlets[outlet][sel]
    column = smb.column_order(result.spec, 0.5 * (a + b))[_upstream_position(result.spec, outlet)]
    return t[sel], result.column_outlets[column, sel]


def _moles(result, outlet, i, t0, t1):
    """mol of component ``i`` leaving ``outlet`` between t0 and t1 [min], integrated switch by switch."""
    comp = result.components[i]
    flow = units.flow_to_si(smb.flow_set(result.spec).ports[outlet])
    edges = _switch_edges(result.spec, t0, t1)
    total = 0.0
    for a, b in zip(edges, edges[1:]):
        t, c = _stream(result, outlet, a, b)
        total += np.trapezoid(units.liquid_to_si(c[:, i], comp.liquid_unit, comp.mw, comp.charge),
                              units.time_to_si(t))
    return float(total * flow)


def switch_averages(result, outlet):
    """``(starts, ends, averages)``: the mean concentration of ``outlet`` over every switch interval of the run
    (averages (nswitch, ncomp), each component's liquid unit) — what a fraction collected over that switch
    would contain."""
    edges = _switch_edges(result.spec, float(result.time[0]), float(result.time[-1]))
    starts, ends, averages = [], [], []
    for a, b in zip(edges, edges[1:]):
        if b - a < 1e-9:
            continue
        t, c = _stream(result, outlet, a, b)
        starts.append(a)
        ends.append(b)
        averages.append(np.trapezoid(c, t, axis=0) / (t[-1] - t[0]) if len(t) > 1 else c[0])
    return np.array(starts), np.array(ends), np.array(averages)


def _fed_moles(result, i, duration):
    """mol of component ``i`` entering with the feed during ``duration`` [min] (the eluent excluded)."""
    comp = result.components[i]
    c = float(result.spec.feed[i]) * comp.liquid_factor()
    return c * units.flow_to_si(smb.flow_set(result.spec).feed) * units.time_to_si(duration)


def _purity(amounts, products, solutes):
    total = sum(amounts[j] for j in solutes)
    return sum(amounts[j] for j in products) / total if total > 0 else np.nan


def _products(result):
    """{outlet: [component indices]} of the chosen products."""
    index = {c.name: i for i, c in enumerate(result.components)}
    return {o: [index[n] for n in names if n in index] for o, names in result.spec.products.items()
            if o in result.outlets and names}


def cycle_table(result):
    """Per cycle: mol fed and leaving with every outlet (each solute); purities and recoveries."""
    spec, comps = result.spec, result.components
    solutes = result.solutes()
    products = _products(result)
    cycle = spec.cycle_time
    rows = []
    for k in range(result.n_cycles):
        t0, t1 = k * cycle, (k + 1) * cycle
        row = {"cycle": k + 1}
        amounts = {o: {i: _moles(result, o, i, t0, t1) for i in solutes} for o in result.outlets}
        for i in solutes:
            row[f"{comps[i].name} fed [mol]"] = _fed_moles(result, i, cycle)
            for o in result.outlets:
                row[f"{comps[i].name} {smb.STREAM_LABELS[o]} [mol]"] = amounts[o][i]
        for o, idx in products.items():
            row[f"purity {smb.STREAM_LABELS[o]}"] = _purity(amounts[o], idx, solutes)
        for o, idx in products.items():
            for i in idx:
                fed = row[f"{comps[i].name} fed [mol]"]
                row[f"recovery {comps[i].name} ({smb.STREAM_LABELS[o]})"] = amounts[o][i] / fed if fed > 0 else np.nan
        rows.append(row)
    return pd.DataFrame(rows).set_index("cycle")


def performance(result, cycle=None):
    """Purity per product outlet, and recovery, productivity and eluent use per product, of one cycle
    (default: the last). Productivity: amount per hour per litre of bed (all columns); eluent use: litres of
    eluent per amount of that product. Amounts in each product's own amount unit."""
    table = cycle_table(result)
    row = table.iloc[-1 if cycle is None else cycle - 1]
    spec, comps = result.spec, result.components
    hours = spec.cycle_time / 60
    bed_l = spec.n_columns * smb.column_volume(spec) / 1000
    eluent_l = smb.flow_set(spec).eluent * spec.cycle_time / 1000
    out = {"cycle": int(row.name), "purity": {}, "products": []}
    for o, idx in _products(result).items():
        label = smb.STREAM_LABELS[o]
        out["purity"][o] = row[f"purity {label}"]
        for i in idx:
            comp = comps[i]
            unit = default_amount_unit(comp)
            mol = row[f"{comp.name} {label} [mol]"]
            try:
                amount = float(units.amount_from_si(mol, unit, comp.mw, comp.charge))
            except ValueError:
                amount, unit = mol, "mol"
            out["products"].append({
                "component": comp.name, "outlet": o, "unit": unit,
                "recovery": row[f"recovery {comp.name} ({label})"],
                "productivity": amount / hours / bed_l,                      # unit/(L bed·h)
                "eluent use": eluent_l / amount if amount > 0 else np.nan,   # L/unit
            })
    return out


# --- HDF5 ---------------------------------------------------------------------------------------

def save_h5(result: SMBResult, target=None):
    buffer = io.BytesIO() if target is None else None
    with h5py.File(buffer if buffer is not None else target, "w") as f:
        f.attrs["format"] = FILE_FORMAT
        f.attrs["version"] = FILE_VERSION
        f.attrs["spec"] = json.dumps(smb.spec_to_dict(result.spec))
        f.attrs["summary"] = json.dumps(result.summary)
        for name in _ARRAYS:
            data = getattr(result, name)
            if data is not None:
                f.create_dataset(name, data=data, compression="gzip" if np.ndim(data) > 1 else None)
        for name, data in result.outlets.items():
            f.create_dataset(f"outlets/{name}", data=data, compression="gzip")
    return buffer.getvalue() if buffer is not None else None


def _open(source):
    return io.BytesIO(source) if isinstance(source, (bytes, bytearray)) else source


def _check_format(f):
    fmt = f.attrs.get("format")
    if fmt == FILE_FORMAT:
        return
    if fmt == "cadet_gui.batch_result":
        raise ValueError("This is a Batch result file; open it in the Batch results viewer.")
    raise ValueError("Not a CADET GUI SMB result file")


def read_spec(source) -> smb.SMBSpec:
    with h5py.File(_open(source), "r") as f:
        _check_format(f)
        return smb.spec_from_dict(json.loads(f.attrs["spec"]))


def load_h5(source) -> SMBResult:
    with h5py.File(_open(source), "r") as f:
        _check_format(f)
        if int(f.attrs["version"]) > FILE_VERSION:
            raise ValueError(f"SMB result file version {f.attrs['version']} is newer than this app supports")
        arrays = {name: f[name][()] for name in _ARRAYS if name in f}
        if "outlets" in f:
            outlets = {name: f["outlets"][name][()] for name in f["outlets"]}
        else:                                                  # files from the first SMB version
            outlets = {name: f[name][()] for name in ("extract", "raffinate") if name in f}
        spec = smb.spec_from_dict(json.loads(f.attrs["spec"]))
        outlets = {name: outlets[name] for name in spec.geometry.outlets if name in outlets}   # flow order
        return SMBResult(spec=spec, outlets=outlets, summary=json.loads(f.attrs["summary"]), **arrays)
