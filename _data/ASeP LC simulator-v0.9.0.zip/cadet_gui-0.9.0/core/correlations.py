"""Mass-transfer correlations (spec §5.2 option B).

Inputs and outputs are GUI units (cm, min, cm/min, cm²/min, µm for R, cP, g/mL);
each function converts to SI via ``core.units``, evaluates, and converts back.

  Re = dp·ρ·u_s / μ,  Sc = μ / (ρ·Dm),  u_s = εb·u
  Chung & Wen:          Eb = dp·u·εb / (0.2 + 0.011·Re^0.48)
  Wilson & Geankoplis:  kf = (1.09/εb)·(Dm²·u_s/dp²)^(1/3),  valid 0.0016 < Re < 55
  Glueckauf:            1/keff = 1/kf + R/(5·εp·Dp)
  Wilke & Chang:        Dm [cm²/s] = 7.4e-8·(φ·M_B)^0.5·T / (μ·V_A^0.6)
"""
from dataclasses import dataclass

import numpy as np

from core import units

WILSON_GEANKOPLIS_RE = (0.0016, 55.0)


@dataclass
class Fluid:
    viscosity: float = 0.89    # μ [cP] (water, 25 °C)
    density: float = 0.997     # ρ [g/mL]


def reynolds(radius_um, u_s_cm_min, fluid: Fluid):
    """Particle Reynolds number Re = dp·ρ·u_s/μ."""
    dp = 2 * units.radius_to_si(radius_um)
    return float(dp * units.density_to_si(fluid.density) * units.velocity_to_si(u_s_cm_min)
                 / units.viscosity_to_si(fluid.viscosity))


def schmidt(dm_cm2_min, fluid: Fluid):
    """Sc = μ/(ρ·Dm)."""
    return (units.viscosity_to_si(fluid.viscosity)
            / (units.density_to_si(fluid.density) * units.diffusivity_to_si(dm_cm2_min)))


def chung_wen(radius_um, u_cm_min, eps_b, re):
    """Axial dispersion Eb [cm²/min] from interstitial velocity u."""
    dp = 2 * units.radius_to_si(radius_um)
    eb = dp * units.velocity_to_si(u_cm_min) * eps_b / (0.2 + 0.011 * re ** 0.48)
    return float(units.diffusivity_from_si(eb))


def wilson_geankoplis(radius_um, u_s_cm_min, eps_b, dm_cm2_min):
    """Film coefficient kf [cm/min] (per component if ``dm`` is an array)."""
    dp = 2 * units.radius_to_si(radius_um)
    dm = units.diffusivity_to_si(dm_cm2_min)
    kf = (1.09 / eps_b) * np.cbrt(dm ** 2 * units.velocity_to_si(u_s_cm_min) / dp ** 2)
    return units.velocity_from_si(kf)


def glueckauf(kf_cm_min, radius_um, eps_p, dp_cm2_min):
    """Lumped keff [cm/min]: 1/keff = 1/kf + R/(5·εp·Dp)."""
    kf = units.velocity_to_si(kf_cm_min)
    r = units.radius_to_si(radius_um)
    dpore = units.diffusivity_to_si(dp_cm2_min)
    return units.velocity_from_si(1.0 / (1.0 / kf + r / (5.0 * eps_p * dpore)))


def wilke_chang(molar_volume, temperature_c=25.0, fluid: Fluid = Fluid(), solvent_mw=18.015,
                association=2.6):
    """Molecular diffusivity Dm [cm²/min].

    ``molar_volume`` V_A [cm³/mol] at the normal boiling point; association
    factor φ = 2.6 and M_B = 18.015 g/mol for water. The correlation is
    empirical in its own units (cP, K, cm³/mol -> cm²/s).
    """
    t_k = units.celsius_to_kelvin(temperature_c)
    mu_cp = units.viscosity_to_si(fluid.viscosity) / units.VISCOSITY["cP"]
    dm_cm2_s = 7.4e-8 * np.sqrt(association * solvent_mw) * t_k / (mu_cp * np.asarray(molar_volume) ** 0.6)
    return units.diffusivity_from_si(units.diffusivity_to_si(dm_cm2_s, "cm2/s"), "cm2/min")


@dataclass
class Estimate:
    """Correlation results in GUI units (per-component arrays where relevant)."""
    u: float            # interstitial velocity [cm/min]
    u_s: float          # superficial velocity [cm/min]
    re: float
    sc: np.ndarray
    axial_dispersion: float     # Eb [cm²/min]
    film_diffusion: np.ndarray  # kf [cm/min]
    keff: np.ndarray | None     # Glueckauf keff [cm/min], if Dp given
    warnings: list


def estimate(flow_ml_min, diameter_cm, radius_um, eps_b, eps_p, dm_cm2_min, fluid: Fluid,
             dp_cm2_min=None):
    """Eb (Chung & Wen), kf (Wilson & Geankoplis) and optionally keff (Glueckauf)."""
    dm = np.asarray(dm_cm2_min, dtype=float)
    if np.any(~np.isfinite(dm)) or np.any(dm <= 0):
        raise ValueError("Molecular diffusivity Dm must be positive for every component")
    u = float(units.interstitial_velocity(flow_ml_min, diameter_cm, eps_b))
    u_s = float(units.superficial_velocity(flow_ml_min, diameter_cm))
    re = reynolds(radius_um, u_s, fluid)
    kf = wilson_geankoplis(radius_um, u_s, eps_b, dm)
    warnings = []
    lo, hi = WILSON_GEANKOPLIS_RE
    if not lo < re < hi:
        warnings.append(f"Re = {re:.3g} is outside the Wilson & Geankoplis range {lo} < Re < {hi}; "
                        "kf may be inaccurate.")
    keff = None
    if dp_cm2_min is not None:
        dpore = np.asarray(dp_cm2_min, dtype=float)
        if np.any(~np.isfinite(dpore)) or np.any(dpore <= 0):
            raise ValueError("Pore diffusivity Dp must be positive for the Glueckauf keff estimate")
        keff = glueckauf(kf, radius_um, eps_p, dpore)
    return Estimate(u=u, u_s=u_s, re=re, sc=schmidt(dm, fluid),
                    axial_dispersion=chung_wen(radius_um, u, eps_b, re),
                    film_diffusion=kf, keff=keff, warnings=warnings)
