"""File names from the user's simulation title."""
import re
from datetime import datetime

_ILLEGAL = re.compile(r'[\\/:*?"<>|\x00-\x1f\s]+')


def file_stem(title, fallback="cadet_results"):
    """A safe file-name stem from a title: whitespace and characters illegal in file names become '_'."""
    stem = _ILLEGAL.sub("_", (title or "").strip()).strip("._")
    return stem[:80] or fallback


def stamped(title, extension, when=None, fallback="cadet_results"):
    """``<title>_YYYYMMDD_HHMMSS.<extension>``."""
    when = when or datetime.now()
    return f"{file_stem(title, fallback)}_{when:%Y%m%d_%H%M%S}.{extension}"
