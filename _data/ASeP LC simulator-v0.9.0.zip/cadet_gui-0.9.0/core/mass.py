"""Per-component input / output amounts (spec §6: input = ∫C_inlet·Q dt, output = ∫C_outlet·Q dt).

The input is integrated exactly from the inlet polynomials (a trapezoid over
sampled step inputs would be off by half an output interval at every step);
the output uses the trapezoid rule over the outlet samples. No balance error is
reported, by design (spec v0.2).
"""
import numpy as np
import pandas as pd

from core import units

AUTO = "component unit"


def _segment_ends(spec):
    segments = spec.operation.program()
    duration = spec.settings.duration
    return [min(nxt.start, duration) for nxt in segments[1:]] + [duration]


def input_moles(spec):
    """Injected amount per component [mol], from the inlet polynomials."""
    flow = units.flow_to_si(spec.operation.flow_rate)
    out = np.zeros(len(spec.components))
    for seg, end in zip(spec.operation.program(), _segment_ends(spec)):
        tau = max(end - seg.start, 0.0)
        for i, (comp, poly) in enumerate(zip(spec.components, seg.coefficients)):
            integral_gui = sum(a * tau ** (p + 1) / (p + 1) for p, a in enumerate(poly))   # unit·min
            out[i] += integral_gui * comp.liquid_factor() * units.time_factor("min") * flow
    return out


def output_moles(result):
    """Eluted amount per component [mol] at the system outlet (trapezoid rule)."""
    flow = units.flow_to_si(result.spec.operation.flow_rate)
    t = units.time_to_si(result.time)
    out = np.zeros(len(result.components))
    for i, comp in enumerate(result.components):
        c = units.liquid_to_si(result.outlet[:, i], comp.liquid_unit, comp.mw, comp.charge)
        out[i] = np.trapezoid(c, t) * flow
    return out


def default_amount_unit(comp):
    """Amount unit matching the component's liquid unit (e.g. mg for mg/L)."""
    return comp.liquid_unit.partition("/")[0]


def mass_table(result, unit=AUTO):
    """Input and output amount per component. Modulators (pH) are skipped.

    ``unit``: AUTO (each component's own amount unit) or one of ``units.AMOUNT_UNITS``;
    components lacking the MW or charge the unit needs show NaN.
    """
    n_in, n_out = input_moles(result.spec), output_moles(result)
    rows = []
    for i, comp in enumerate(result.components):
        if comp.liquid_unit == units.MODULATOR_UNIT:
            continue
        u = default_amount_unit(comp) if unit == AUTO else unit
        try:
            values = [float(units.amount_from_si(n, u, comp.mw, comp.charge)) for n in (n_in[i], n_out[i])]
        except ValueError:
            values = [np.nan, np.nan]
        rows.append({"component": comp.name, "unit": u, "input": values[0], "output": values[1]})
    return pd.DataFrame(rows).set_index("component")


def numerical_checks(result):
    """Indicators of numerical trouble visible in the solution itself.

    CADET-Core 5.1.1 does not export solver statistics (steps, error-test or
    Newton failures), so this reports NaNs and the deepest negative undershoot
    of the outlet relative to its peak, per component.
    """
    rows = []
    for i, comp in enumerate(result.components):
        c = result.outlet[:, i]
        peak = np.nanmax(np.abs(c)) if np.isfinite(c).any() else np.nan
        undershoot = max(0.0, -np.nanmin(c)) / peak if peak and np.isfinite(peak) else 0.0
        rows.append({"component": comp.name, "NaN values": int(np.isnan(c).sum()),
                     "negative undershoot / peak": undershoot})
    return pd.DataFrame(rows).set_index("component")
