"""Series colours in a fixed order (validated light-mode palette); colour follows the component's position in
the component list, never its rank. Shared by the web plots and the Excel charts."""

SERIES_COLORS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"]
