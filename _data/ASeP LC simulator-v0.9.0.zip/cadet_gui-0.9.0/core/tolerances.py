"""Solver tolerances for CADET, scaled to the concentrations of a run.

CADET's default absolute tolerance (1e-8), algebraic tolerance (1e-12) and WENO
epsilon (1e-10) are fixed numbers in mol/m³ (= mmol/L). They are fine at mM, but
for trace solutes the allowed error becomes comparable to the signal: a 1 nM feed
(1e-6) already shows ~5 % peak distortion, a 10 pM feed is wrong by ~90 %.
Scaling the three values with the concentration restores scale-independent
results (checked down to 1e-15 mmol/L with a linear isotherm).

Automatic rule: c_scale = the smallest, over the solutes (pH modulator and
components that never appear excluded), of each solute's largest inlet or initial
concentration [mol/m³]; s = min(1, c_scale); then
  abstol = 1e-8·s,  algtol = 1e-12·s,  weno_eps = 1e-10·s²,  reltol unchanged.
For c_scale ≥ 1 mM this is exactly CADET's defaults.
"""
import math
from dataclasses import asdict, dataclass

from core import dimensionless, units

MODES = ("auto", "manual")


@dataclass
class Tolerances:
    reltol: float = 1e-6      # relative tolerance (independent of the concentration scale)
    abstol: float = 1e-8      # absolute tolerance [mol/m³]
    algtol: float = 1e-12     # algebraic / consistent-initialisation tolerance
    weno_eps: float = 1e-10   # WENO smoothness epsilon (compared with squared concentration jumps)

    def as_dict(self):
        return asdict(self)


DEFAULT = Tolerances()


def concentration_scale(spec):
    """Smallest solute concentration scale of the run in mol/m³, or None if there is none."""
    comps = spec.components
    peak = list(dimensionless.inlet_max(spec))
    initial = spec.column.initial_liquid or []
    for i, value in enumerate(initial[:len(comps)]):
        if value is not None and value == value:
            peak[i] = max(peak[i], float(value))
    scales = []
    for comp, c in zip(comps, peak):
        if comp.liquid_unit == units.MODULATOR_UNIT or not c > 0:
            continue
        scales.append(c * comp.liquid_factor())
    return min(scales) if scales else None


def auto_tolerances(spec) -> Tolerances:
    c = concentration_scale(spec)
    s = 1.0 if c is None else min(1.0, max(c, 1e-30))
    return Tolerances(reltol=DEFAULT.reltol, abstol=DEFAULT.abstol * s, algtol=DEFAULT.algtol * s,
                      weno_eps=DEFAULT.weno_eps * s * s)


def effective_tolerances(spec) -> Tolerances:
    """Tolerances a run of ``spec`` uses: automatic, or the manual values of its settings."""
    settings = spec.settings
    if settings.tolerance_mode == "auto":
        return auto_tolerances(spec)
    if settings.tolerance_mode != "manual":
        raise ValueError(f"Unknown tolerance mode {settings.tolerance_mode!r}; expected one of {MODES}")
    tol = Tolerances(settings.reltol, settings.abstol, settings.algtol, settings.weno_eps)
    for name, value in tol.as_dict().items():
        if not (isinstance(value, (int, float)) and math.isfinite(value) and value > 0):
            raise ValueError(f"Solver tolerance {name} must be a positive number, got {value!r}")
    return tol
