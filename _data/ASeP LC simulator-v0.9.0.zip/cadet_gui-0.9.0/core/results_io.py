"""Batch results in GUI units, and their HDF5 file format (spec §7 결과 저장).

``BatchResult`` holds everything the results viewer needs, independent of
CADET-Process objects, so a saved file reopens exactly like a fresh run.

Arrays (GUI units; NaN where a component has no value, e.g. solid of a
non-adsorbing component):
  time   (nt,)              min
  z      (ncol,)            cm, axial cell centres
  inlet, outlet (nt, ncomp) each component's liquid unit; outlet is the system
                            outlet (after the outlet ECV tank, what a detector sees)
  column_outlet (nt, ncomp) leaving the column itself (before the outlet ECV tank; equal to
                            outlet without extra-column volume)
  bulk   (nt, ncol, ncomp)  liquid unit
  pore   (nt, ncol, ncomp)  liquid unit, particle-volume average (None for LRM)
  solid  (nt, ncol, ncomp)  each component's solid unit, particle-volume average
  final_state, final_state_derivative   CADET's full state vector at the end
                                        (SI, for sequential runs; see utils.state_manager)
"""
import io
import json
from dataclasses import dataclass, field
from datetime import datetime

import h5py
import numpy as np
import pandas as pd

from core import units
from core.model_builder import BatchSpec, spec_from_dict, spec_to_dict

FILE_FORMAT = "cadet_gui.batch_result"
FILE_VERSION = 1
PHASES = ("bulk", "pore", "solid")


@dataclass
class BatchResult:
    spec: BatchSpec
    time: np.ndarray
    z: np.ndarray
    inlet: np.ndarray
    outlet: np.ndarray
    bulk: np.ndarray | None = None
    pore: np.ndarray | None = None
    solid: np.ndarray | None = None
    summary: dict = field(default_factory=dict)
    final_state: np.ndarray | None = None
    final_state_derivative: np.ndarray | None = None
    column_outlet: np.ndarray | None = None

    @property
    def components(self):
        return self.spec.components

    def phases(self):
        """Phases with recorded column profiles."""
        return [p for p in PHASES if getattr(self, p) is not None]

    def unit(self, phase, i):
        comp = self.components[i]
        return comp.solid_unit if phase == "solid" else comp.liquid_unit

    def profile_dataframe(self, phase, t_index):
        """Axial profile of ``phase`` at ``time[t_index]``: "z [cm]", "<name> [<unit>]", ..."""
        data = getattr(self, phase)
        out = {"z [cm]": self.z}
        for i, comp in enumerate(self.components):
            if not np.all(np.isnan(data[t_index, :, i])):
                out[f"{comp.name} [{self.unit(phase, i)}]"] = data[t_index, :, i]
        return pd.DataFrame(out)

    def outlet_dataframe(self):
        """Outlet concentration vs time: "time [min]", "<name> [<unit>]", ..."""
        data = {"time [min]": self.time}
        for i, comp in enumerate(self.components):
            data[f"{comp.name} [{comp.liquid_unit}]"] = self.outlet[:, i]
        return pd.DataFrame(data)


# --- From CADET-Process ------------------------------------------------------

def _shell_weights(centres, radius):
    """Volume fraction of each spherical shell, from cell-centre radii."""
    order = np.argsort(centres)
    c = np.asarray(centres)[order]
    edges = np.concatenate([[0.0], (c[1:] + c[:-1]) / 2, [radius]])
    w_sorted = np.diff(edges ** 3) / radius ** 3
    w = np.empty_like(w_sorted)
    w[order] = w_sorted
    return w


def _particle_average(sol, radius):
    """(nt, ncol[, npar], n) -> (nt, ncol, n), volume-averaged over the particle."""
    data = sol.solution
    if data.ndim == 3:
        return data
    w = _shell_weights(sol.particle_coordinates, radius)
    return np.einsum("tzrc,r->tzc", data, w)


def _liquid(si, comps):
    out = np.empty_like(si, dtype=float)
    for i, c in enumerate(comps):
        out[..., i] = units.liquid_from_si(si[..., i], c.liquid_unit, c.mw, c.charge)
    return out


def _solid(si_bound, spec):
    """Bound-state array (..., n_bound) -> (..., ncomp) in solid units, NaN if unbound.

    Bi-Langmuir has two states per component, all components, component by component; their sum is the
    amount bound per component.
    """
    comps, col = spec.components, spec.column
    out = np.full(si_bound.shape[:-1] + (len(comps),), np.nan)
    bi = spec.binding.model == "BiLangmuir"
    k = 0
    for i, c in enumerate(comps):
        if not c.bound or spec.binding.model == "None":
            continue
        if bi:
            total = si_bound[..., 2 * i] + si_bound[..., 2 * i + 1]
        else:
            total = si_bound[..., k]
            k += 1
        out[..., i] = units.solid_from_si(
            total, c.solid_unit, c.mw, c.charge, eps_t=col.total_porosity(), eps_p=col.eps_p,
            density=col.resin_density, density_basis=col.density_basis)
    return out


def from_cadet(results, spec: BatchSpec) -> BatchResult:
    """Convert CADET-Process ``SimulationResults`` to a GUI-unit ``BatchResult``."""
    comps = spec.components
    col = results.solution.column
    radius = float(units.radius_to_si(spec.column.radius))
    keys = col.keys()

    bulk = pore = solid = None
    z = np.array([])
    if "bulk" in keys:
        bulk = _liquid(col.bulk.solution, comps)
        z = units.length_from_si(col.bulk.axial_coordinates)
    if "particle" in keys:
        pore = _liquid(_particle_average(col.particle, radius), comps)
    if "solid" in keys and col.solid.solution.shape[-1] > 0:
        solid = _solid(_particle_average(col.solid, radius), spec)

    return BatchResult(
        spec=spec,
        time=units.time_from_si(col.outlet.time),
        z=z,
        inlet=_liquid(results.solution.inlet.outlet.solution, comps),
        outlet=_liquid(results.solution.outlet.inlet.solution, comps),
        column_outlet=_liquid(col.outlet.solution, comps),
        bulk=bulk, pore=pore, solid=solid,
        final_state=np.asarray(results.system_state["state"]),
        final_state_derivative=np.asarray(results.system_state["state_derivative"]),
        summary={
            "exit_flag": int(results.exit_flag),
            "exit_message": results.exit_message or "",
            "time_elapsed_s": float(results.time_elapsed),
            "completed": datetime.now().isoformat(timespec="seconds"),
        },
    )


# --- HDF5 --------------------------------------------------------------------

_ARRAYS = ("time", "z", "inlet", "outlet") + PHASES + ("final_state", "final_state_derivative", "column_outlet")
COLUMN_PROFILE_FORMAT = "cadet_gui.column_state"


def _check_format(f):
    """Refuse files that are not result files, naming the right place for a column profile."""
    fmt = f.attrs.get("format")
    if fmt == FILE_FORMAT:
        return
    if fmt == COLUMN_PROFILE_FORMAT:
        raise ValueError("This is a column profile file, not a result file. Use it in the Batch screen under "
                         "Initial state → Load column profile.")
    if fmt == "cadet_gui.smb_result":
        raise ValueError("This is an SMB result file (.smbh5); open it on the SMB results page.")
    raise ValueError("Not a CADET GUI result file")


def save_h5(result: BatchResult, target=None):
    """Write ``result`` to a path or file-like object; with no target, return bytes."""
    buffer = io.BytesIO() if target is None else None
    with h5py.File(buffer if buffer is not None else target, "w") as f:
        f.attrs["format"] = FILE_FORMAT
        f.attrs["version"] = FILE_VERSION
        f.attrs["spec"] = json.dumps(spec_to_dict(result.spec))
        f.attrs["summary"] = json.dumps(result.summary)
        for name in _ARRAYS:
            data = getattr(result, name)
            if data is not None:
                f.create_dataset(name, data=data, compression="gzip" if data.ndim > 1 else None)
    return buffer.getvalue() if buffer is not None else None


def read_spec(source):
    """Only the input (``BatchSpec``) stored in a result file, without the solution arrays."""
    if isinstance(source, (bytes, bytearray)):
        source = io.BytesIO(source)
    with h5py.File(source, "r") as f:
        _check_format(f)
        return spec_from_dict(json.loads(f.attrs["spec"]))


def load_h5(source) -> BatchResult:
    """Read a result written by ``save_h5`` from a path, bytes or file-like object."""
    if isinstance(source, (bytes, bytearray)):
        source = io.BytesIO(source)
    with h5py.File(source, "r") as f:
        _check_format(f)
        if int(f.attrs["version"]) > FILE_VERSION:
            raise ValueError(f"Result file version {f.attrs['version']} is newer than this app supports")
        arrays = {name: f[name][()] for name in _ARRAYS if name in f}
        return BatchResult(
            spec=spec_from_dict(json.loads(f.attrs["spec"])),
            summary=json.loads(f.attrs["summary"]),
            **arrays,
        )
