"""Everything about an SMB run in one Excel workbook (.xlsx).

Sheets
  Summary           title and dates, layout, flows and m values, streams, products, performance of the last
                    cycle, components, binding, mass transfer, reactions, settings
  Data              time and the concentrations of every outlet stream (all cycles)
  Cycles            per cycle: amounts fed and leaving with every outlet, purities, recoveries
  Average concentration   average concentration of every outlet over every switch interval
  Charts            each product outlet over the whole run, and the convergence by cycle
  Column outlets    outlet of every physical column (all cycles)
  Ring <phase>      concentrations along the ring (zone I first) at evenly spaced times of the last
                    cycle; only when asked for (``include_profiles``)
  Input parameters  every input as ``parameter, value``
"""
import datetime
import io

import numpy as np
import xlsxwriter

from core import smb, tolerances
from core import smb_results as sr
from core.excel_export import (SUMMARY_WIDTHS, _binding_table, _flatten, _formats, _Page, _try, _when, _write)
from core.model_builder import modulator_count
from core.naming import stamped
from core.palette import SERIES_COLORS

AVERAGES = "Average concentration"
SUMMARY, DATA, CYCLES, CHARTS, OUTLETS, INPUTS = ("Summary", "Data", "Cycles", "Charts", "Column outlets",
                                                 "Input parameters")
RING_SHEETS = {"bulk": "Ring bulk", "pore": "Ring pore", "solid": "Ring solid"}


def export_filename(result, when=None):
    return stamped(result.spec.title, "xlsx", when, "smb_results")


def _summary(wb, fmt, result, created):
    ws = wb.add_worksheet(SUMMARY)
    for c, w in enumerate(SUMMARY_WIDTHS):
        ws.set_column(c, c, w)
    page = _Page(ws, fmt)
    spec, s = result.spec, result.summary
    base, comps = spec.base, spec.components
    col, b, st = base.column, base.binding, base.settings
    n_mod = modulator_count(b.model)

    page.title(spec.title or "Untitled SMB simulation")
    page.kv("Simulation completed", _when(s.get("completed")) or "(date not stored in this result)")
    page.kv("Workbook created", created.strftime("%Y-%m-%d %H:%M:%S"))
    page.note("CADET GUI SMB summary. GUI units (cm, mL, mL/min, min, µm; concentrations in each component's unit).")

    page.section("Run")
    conv = s.get("converged")
    page.kv("Cycles simulated", result.n_cycles)
    page.kv("Cyclic steady state", "reached" if conv else "not reached" if conv is False else "fixed number of cycles")
    page.kv("Steady-state tolerance", spec.cycles.threshold if spec.cycles.mode == "steady state" else None)
    page.kv("Computation time", s.get("time_elapsed_s"), "s")
    page.kv("Column model", col.model)
    page.kv("Binding model", b.model + (" (kinetic)" if b.kinetic else " (rapid equilibrium)") if b.model != "None" else "None")

    page.section("Layout")
    layout = spec.geometry
    page.kv("Layout", layout.label)
    page.table(["zone"] + list(layout.zones), [["columns"] + [int(k) for k in spec.columns_per_zone]])
    page.kv("Columns in total", spec.n_columns)
    page.kv("Switch time t_s", spec.switch_time, "min")
    page.kv("Cycle time", spec.cycle_time, "min")
    page.kv("Column length L", col.length, "cm")
    page.kv("Column diameter D", col.diameter, "cm")
    page.kv("Column volume V_c", smb.column_volume(spec), "mL")
    page.kv("Bed porosity εb", col.eps_b)
    page.kv("Particle porosity εp", col.eps_p)
    page.kv("Total porosity εt", col.total_porosity())
    page.kv("Particle radius R", col.radius, "µm")

    page.section("Flows")

    def flows():
        f = smb.flow_set(spec)
        page.table([""] + [f"zone {z}" for z in layout.zones],
                   [["flow [mL/min]", *f.zones], ["m (flow-rate ratio)", *f.m]])
        for name, q in f.ports.items():
            page.kv(f"{smb.STREAM_LABELS[name].capitalize()} {smb._SYMBOL[name]}", q, "mL/min")
        page.kv("Entered as", {"external": "external flows", "zones": "zone flows", "m": "m values"}[spec.flow_mode])
        h = smb.henry_coefficients(spec)
        if h:
            page.kv("Henry coefficients (infinite dilution)", ", ".join(f"{k} {v:.4g}" for k, v in h.items()))
    _try(page, "Flows", flows)

    page.section("Feed and eluent")
    page.table(["component", "feed", "eluent", "unit"],
               [[c.name, spec.feed[i], spec.eluent[i], c.liquid_unit] for i, c in enumerate(comps)])
    for outlet in layout.products:
        page.kv(f"Products in the {smb.STREAM_LABELS[outlet]}", ", ".join(spec.products.get(outlet, [])) or "(none chosen)")

    page.section("Performance (last cycle)")

    def perf():
        p = sr.performance(result)
        for outlet, purity in p["purity"].items():
            page.kv(f"Purity, {smb.STREAM_LABELS[outlet]}", purity)
        page.table(["product", "outlet", "recovery", "productivity", "unit", "eluent use", "unit"],
                   [[q["component"], smb.STREAM_LABELS[q["outlet"]], q["recovery"], q["productivity"], f"{q['unit']}/(L bed·h)",
                     q["eluent use"], f"L/{q['unit']}"] for q in p["products"]])
        page.note("Purity counts the solutes only (not salt or pH). Recovery = amount in the outlet / amount fed with "
                  "the feed in the same cycle. Productivity per litre of all columns.")
    _try(page, "Performance", perf)

    page.section("Components")
    page.table(["name", "MW [g/mol]", "charge ν", "adsorbs", "liquid unit", "solid unit", "role"],
               [[c.name, c.mw, c.charge, c.bound, c.liquid_unit, c.solid_unit,
                 ("salt (counter-ion)" if i == 0 else "pH modulator") if i < n_mod else "solute"]
                for i, c in enumerate(comps)])

    page.section("Binding")
    if b.model == "None":
        page.note("No adsorption.")
    else:
        headers, rows = _binding_table(base)
        page.table(headers, rows)
        if b.giex is not None and n_mod:
            g = b.giex
            page.kv("Capacity Λ", g.capacity, g.capacity_unit)
            page.kv("c_ref (salt)", g.reference_liquid, comps[0].liquid_unit)

    page.section("Mass transfer (same for every column)")
    page.kv("Axial dispersion Eb", col.axial_dispersion, "cm²/min")
    if col.film_diffusion is not None:
        headers, columns = ["component", "keff [cm/min]" if col.model == "LRM_keff" else "kf [cm/min]"], [col.film_diffusion]
        if col.model == "GRM" and col.pore_diffusion is not None:
            headers.append("Dp [cm²/min]")
            columns.append(col.pore_diffusion)
        page.table(headers, [[c.name] + [v[i] for v in columns] for i, c in enumerate(comps)])
    if base.correlation:
        page.note(f"Correlation estimates at the mean zone flow {base.operation.flow_rate:.4g} mL/min.")

    if base.reactions is not None and base.reactions.reactions:
        page.section("Mobile-phase reactions")
        page.table(["reaction", "k+", "k−", "Ka = k+/k−"],
                   [[r.equation, r.k_fwd, r.k_bwd, r.equilibrium] for r in base.reactions.reactions])

    page.section("Initial state")
    liquid = col.initial_liquid or [0.0] * len(comps)
    solid = col.initial_solid or [0.0] * len(comps)
    page.table(["component", "c0", "liquid unit", "q0", "solid unit"],
               [[c.name, liquid[i], c.liquid_unit, solid[i] if c.bound else None, c.solid_unit if c.bound else None]
                for i, c in enumerate(comps)])

    page.section("Simulation settings")
    page.kv("Output interval", st.output_interval, "min")
    page.kv("Axial cells per column", st.n_col)
    if col.model == "GRM":
        page.kv("Particle cells", st.n_par)

    def tol():
        t = tolerances.effective_tolerances(base)
        page.kv("reltol", t.reltol)
        page.kv("abstol", t.abstol, "mol/m³")
        page.kv("algtol", t.algtol)
    _try(page, "Solver tolerances", tol)


def _data(wb, fmt, result):
    ws = wb.add_worksheet(DATA)
    comps = result.components
    headers = ["time [min]"] + [f"{smb.STREAM_LABELS[o]} {c.name} [{c.liquid_unit}]" for o in result.outlets
                                for c in comps]
    ws.write_row(0, 0, headers, fmt["header"])
    ws.write_column(1, 0, result.time)
    col = 1
    for values in result.outlets.values():
        for i in range(len(comps)):
            ws.write_column(1, col, np.asarray(values[:, i], dtype=float))
            col += 1
    ws.set_column(0, col, 16)
    ws.freeze_panes(1, 1)


def _cycles(wb, fmt, result):
    ws = wb.add_worksheet(CYCLES)
    table = sr.cycle_table(result).reset_index()
    ws.write_row(0, 0, list(table.columns), fmt["header"])
    for r, row in enumerate(table.itertuples(index=False), start=1):
        for c, v in enumerate(row):
            _write(ws, r, c, v)
    ws.set_column(0, len(table.columns), 18)
    ws.freeze_panes(1, 1)
    return len(table)


def _averages(wb, fmt, result):
    ws = wb.add_worksheet(AVERAGES)
    comps = result.components
    headers = ["switch", "cycle", "from [min]", "to [min]", "average time [min]"] + [
        f"{smb.STREAM_LABELS[o]} {c.name} [{c.liquid_unit}]" for o in result.outlets for c in comps]
    ws.write_row(0, 0, headers, fmt["header"])
    blocks = [sr.switch_averages(result, o) for o in result.outlets]
    starts, ends = blocks[0][0], blocks[0][1]
    n = result.spec.n_columns
    for r, (a, b) in enumerate(zip(starts, ends), start=1):
        ws.write_row(r, 0, [r, (r - 1) // n + 1, float(a), float(b), 0.5 * float(a + b)])
        ws.write_row(r, 5, [float(v) for _, _, means in blocks for v in means[r - 1]])
    ws.set_column(0, 3, 11)
    ws.set_column(4, 4, 16)
    ws.set_column(5, len(headers), 18)
    ws.freeze_panes(1, 5)
    ws.write_string(len(starts) + 2, 0, "Average concentration of each switch interval: what a fraction collected "
                                        "over that switch would contain.", fmt["note"])


def _charts(wb, fmt, result, n_rows):
    """One chart per product outlet over the whole run (concentration lines and the average concentration of
    every switch as points joined by dashed lines), then the convergence by cycle."""
    ws = wb.add_worksheet(CHARTS)
    comps, nt = result.components, len(result.time)
    n = len(comps)
    n_switch = len(sr.switch_averages(result, next(iter(result.outlets)))[0])
    row = 1
    for k, o in enumerate(result.outlets):
        if o == smb.WASTE:
            continue
        ch = wb.add_chart({"type": "scatter", "subtype": "straight"})
        for i in result.solutes():
            col = 1 + k * n + i
            ch.add_series({"name": comps[i].name, "categories": [DATA, 1, 0, nt, 0],
                           "values": [DATA, 1, col, nt, col], "marker": {"type": "none"},
                           "line": {"color": SERIES_COLORS[i % len(SERIES_COLORS)], "width": 1.5}})
        for i in result.solutes():                     # average concentration: column E = average time
            col, color = 5 + k * n + i, SERIES_COLORS[i % len(SERIES_COLORS)]
            ch.add_series({"name": f"{comps[i].name} average concentration",
                           "categories": [AVERAGES, 1, 4, n_switch, 4], "values": [AVERAGES, 1, col, n_switch, col],
                           "line": {"color": color, "width": 1.25, "dash_type": "dash"},
                           "marker": {"type": "circle", "size": 6, "fill": {"color": color},
                                      "border": {"color": color}}})
        ch.set_title({"name": f"{smb.STREAM_LABELS[o].capitalize()}, all cycles", "name_font": {"size": 12}})
        ch.set_x_axis({"name": "Time [min]", "min": 0, "max": float(result.time[-1]),
                       "major_gridlines": {"visible": True, "line": {"color": "#E5E5E5"}}})
        ch.set_y_axis({"name": f"Concentration [{comps[result.solutes()[0]].liquid_unit}]" if result.solutes()
                       else "Concentration", "major_gridlines": {"visible": True, "line": {"color": "#E5E5E5"}}})
        ch.set_legend({"position": "bottom"})
        ch.set_size({"width": 960, "height": 340})
        ws.insert_chart(row, 0, ch)
        row += 18
    table = sr.cycle_table(result)
    cols = list(table.columns)
    conv = wb.add_chart({"type": "scatter", "subtype": "straight_with_markers"})
    for name in cols:
        if name.startswith(("purity", "recovery")):
            c = 1 + cols.index(name)
            conv.add_series({"name": name, "categories": [CYCLES, 1, 0, n_rows, 0], "values": [CYCLES, 1, c, n_rows, c]})
    conv.set_title({"name": "Purity and recovery by cycle", "name_font": {"size": 12}})
    conv.set_x_axis({"name": "Cycle"})
    conv.set_y_axis({"name": "Fraction"})
    conv.set_legend({"position": "bottom"})
    conv.set_size({"width": 760, "height": 340})
    ws.insert_chart(row, 0, conv)


def _column_outlets(wb, fmt, result):
    ws = wb.add_worksheet(OUTLETS)
    comps = result.components
    ws.write_string(0, 0, "time [min]", fmt["header"])
    ws.write_column(1, 0, result.time)
    col = 1
    for j in range(result.column_outlets.shape[0]):
        for i, c in enumerate(comps):
            ws.write_string(0, col, f"column {j + 1} {c.name} [{c.liquid_unit}]", fmt["header"])
            ws.write_column(1, col, np.asarray(result.column_outlets[j, :, i], dtype=float))
            col += 1
    ws.set_column(0, col, 15)
    ws.freeze_panes(1, 1)


def _ring(wb, fmt, result, phase, n_times):
    ws = wb.add_worksheet(RING_SHEETS[phase])
    nt = len(result.profile_time)
    idx = np.unique(np.round(np.linspace(0, nt - 1, min(nt, n_times))).astype(int))
    positions, _ = result.ring_profile(phase, 0)
    ws.write_string(0, 0, "t [min] →", fmt["bold"])
    ws.write_string(1, 0, "position [column lengths] ↓", fmt["bold"])
    ws.write_column(2, 0, positions)
    ws.set_column(0, 0, 26)
    col = 1
    for k in idx:
        _, data = result.ring_profile(phase, k)
        for i, c in enumerate(result.components):
            if np.all(np.isnan(data[:, i])):
                continue
            ws.write_number(0, col, float(result.profile_time[k]), fmt["bold"])
            ws.write_string(1, col, f"{c.name} [{result.unit(phase, i)}]", fmt["header"])
            ws.write_column(2, col, data[:, i])
            col += 1
    ws.freeze_panes(2, 1)
    ws.write_string(len(positions) + 3, 0, "Along the ring from the eluent port (zone I first); position p means "
                                           "p column lengths downstream.", fmt["note"])


def _inputs(wb, fmt, spec):
    ws = wb.add_worksheet(INPUTS)
    ws.set_column(0, 0, 58)
    ws.set_column(1, 1, 26)
    ws.write_row(0, 0, ["parameter", "value"], fmt["header"])
    for r, (path, value) in enumerate(_flatten(smb.spec_to_dict(spec)), start=1):
        ws.write_string(r, 0, path)
        _write(ws, r, 1, value)
    ws.freeze_panes(1, 0)


def build_workbook(result, include_profiles=False, profile_times=13, created=None) -> bytes:
    created = created or datetime.datetime.now()
    buffer = io.BytesIO()
    wb = xlsxwriter.Workbook(buffer, {"in_memory": True, "nan_inf_to_errors": True})
    wb.set_properties({"title": result.spec.title or "Untitled SMB simulation", "subject": "CADET GUI SMB simulation",
                       "author": "CADET GUI", "created": created})
    fmt = _formats(wb)
    _summary(wb, fmt, result, created)
    _data(wb, fmt, result)
    n_rows = _cycles(wb, fmt, result)
    _averages(wb, fmt, result)
    _charts(wb, fmt, result, n_rows)
    if result.column_outlets is not None:
        _column_outlets(wb, fmt, result)
    if include_profiles:
        for phase in result.phases():
            _ring(wb, fmt, result, phase, profile_times)
    _inputs(wb, fmt, result.spec)
    wb.close()
    return buffer.getvalue()
