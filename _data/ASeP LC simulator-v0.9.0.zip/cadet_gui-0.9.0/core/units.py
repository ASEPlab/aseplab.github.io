"""Unit conversions between GUI units and CADET SI units (spec §4).

All GUI <-> SI conversions in the project live here. Every ``*_to_si`` function
has a matching ``*_from_si`` inverse. Inputs may be scalars or array-likes.

GUI defaults: cm, µm (particle radius), mL, mL/min, min, cm/min, cm²/min.
CADET internals: m, m³, m³/s, s, m/s, m²/s, liquid mol/m³, solid mol/m³ solid.
"""
import numpy as np

# --- Factors to SI -----------------------------------------------------------

LENGTH = {"m": 1.0, "cm": 1e-2, "mm": 1e-3, "um": 1e-6, "µm": 1e-6}
TIME = {"s": 1.0, "min": 60.0, "h": 3600.0}
VOLUME = {"m3": 1.0, "L": 1e-3, "mL": 1e-6, "uL": 1e-9, "µL": 1e-9}

FLOW = {
    "m3/s": 1.0,
    "mL/min": VOLUME["mL"] / TIME["min"],
    "mL/s": VOLUME["mL"],
    "L/min": VOLUME["L"] / TIME["min"],
}
VELOCITY = {
    "m/s": 1.0,
    "cm/min": LENGTH["cm"] / TIME["min"],
    "cm/s": LENGTH["cm"],
    "cm/h": LENGTH["cm"] / TIME["h"],
}
DIFFUSIVITY = {
    "m2/s": 1.0,
    "cm2/min": LENGTH["cm"] ** 2 / TIME["min"],
    "cm2/s": LENGTH["cm"] ** 2,
}

VISCOSITY = {"Pa s": 1.0, "cP": 1e-3, "mPa s": 1e-3}
DENSITY = {"kg/m3": 1.0, "g/mL": 1e3, "g/cm3": 1e3}

LIQUID_UNITS = ("mol/L", "mmol/L", "g/L", "mg/L", "meq/L")
# The GIEX pH modulator component carries the pH value itself (no conversion).
MODULATOR_UNIT = "pH"
SOLID_BASES = ("mL solid", "mL bed", "g resin")
DENSITY_BASES = ("solid", "particle", "bed")
AMOUNT_UNITS = ("mol", "mmol", "umol", "g", "mg", "ug", "meq")


def _lookup(table, unit, kind):
    try:
        return table[unit]
    except KeyError:
        raise ValueError(f"Unknown {kind} unit {unit!r}; expected one of {list(table)}") from None


def _scale(value, factor):
    return np.asarray(value, dtype=float) * factor


# --- Simple dimensional quantities ------------------------------------------

def length_to_si(x, unit="cm"):
    return _scale(x, _lookup(LENGTH, unit, "length"))


def length_from_si(x, unit="cm"):
    return _scale(x, 1.0 / _lookup(LENGTH, unit, "length"))


def radius_to_si(r, unit="um"):
    """Particle radius; GUI default µm (spec §4)."""
    return length_to_si(r, unit)


def radius_from_si(r, unit="um"):
    return length_from_si(r, unit)


def time_to_si(t, unit="min"):
    return _scale(t, _lookup(TIME, unit, "time"))


def time_from_si(t, unit="min"):
    return _scale(t, 1.0 / _lookup(TIME, unit, "time"))


def volume_to_si(v, unit="mL"):
    return _scale(v, _lookup(VOLUME, unit, "volume"))


def volume_from_si(v, unit="mL"):
    return _scale(v, 1.0 / _lookup(VOLUME, unit, "volume"))


def flow_to_si(q, unit="mL/min"):
    return _scale(q, _lookup(FLOW, unit, "flow"))


def flow_from_si(q, unit="mL/min"):
    return _scale(q, 1.0 / _lookup(FLOW, unit, "flow"))


def velocity_to_si(u, unit="cm/min"):
    """Also used for kf and keff (cm/min)."""
    return _scale(u, _lookup(VELOCITY, unit, "velocity"))


def velocity_from_si(u, unit="cm/min"):
    return _scale(u, 1.0 / _lookup(VELOCITY, unit, "velocity"))


def diffusivity_to_si(d, unit="cm2/min"):
    """Eb (= Dax), Dp, Dm."""
    return _scale(d, _lookup(DIFFUSIVITY, unit, "diffusivity"))


def diffusivity_from_si(d, unit="cm2/min"):
    return _scale(d, 1.0 / _lookup(DIFFUSIVITY, unit, "diffusivity"))


def viscosity_to_si(mu, unit="cP"):
    return _scale(mu, _lookup(VISCOSITY, unit, "viscosity"))


def density_to_si(rho, unit="g/mL"):
    """Fluid (or resin) mass density -> kg/m³."""
    return _scale(rho, _lookup(DENSITY, unit, "density"))


def celsius_to_kelvin(t):
    return _scale(t, 1.0) + 273.15


# --- Amounts and concentrations ---------------------------------------------

def _amount_factor(unit, mw=None, charge=None):
    """Factor converting an amount in ``unit`` to mol.

    ``mw`` is the molar mass [g/mol]; ``charge`` is ν (sign ignored).
    """
    if unit == "mol":
        return 1.0
    if unit == "mmol":
        return 1e-3
    if unit == "umol":
        return 1e-6
    if unit in ("g", "mg", "ug"):
        if not mw:
            raise ValueError(f"Unit {unit!r} requires a molecular weight (MW)")
        return {"g": 1.0, "mg": 1e-3, "ug": 1e-6}[unit] / mw
    if unit == "meq":
        if not charge:
            raise ValueError("Unit 'meq' requires a nonzero charge ν")
        return 1e-3 / abs(charge)
    raise ValueError(f"Unknown amount unit {unit!r}; expected one of {AMOUNT_UNITS}")


def amount_to_si(n, unit, mw=None, charge=None):
    """Amount in ``unit`` -> mol."""
    return _scale(n, _amount_factor(unit, mw, charge))


def amount_from_si(n, unit, mw=None, charge=None):
    """mol -> amount in ``unit`` (e.g. for per-component mass tables)."""
    return _scale(n, 1.0 / _amount_factor(unit, mw, charge))


def liquid_factor(unit, mw=None, charge=None):
    """Factor converting a liquid concentration in ``unit`` to mol/m³ (1 for "pH")."""
    if unit == MODULATOR_UNIT:
        return 1.0
    amount, sep, per = unit.partition("/")
    if not sep or per != "L" or unit not in LIQUID_UNITS:
        raise ValueError(f"Unknown liquid concentration unit {unit!r}; expected one of {LIQUID_UNITS}")
    return _amount_factor(amount, mw, charge) / VOLUME["L"]


def liquid_to_si(c, unit="mmol/L", mw=None, charge=None):
    """Liquid-phase concentration -> mol/m³ (= mmol/L)."""
    return _scale(c, liquid_factor(unit, mw, charge))


def liquid_from_si(c, unit="mmol/L", mw=None, charge=None):
    return _scale(c, 1.0 / liquid_factor(unit, mw, charge))


def _solid_volume_fraction(density_basis, eps_t=None, eps_p=None):
    """Solid-skeleton volume per volume of the reference that ``density`` is given for."""
    if density_basis == "solid":
        return 1.0
    if density_basis == "particle":
        if eps_p is None or not 0.0 <= eps_p < 1.0:
            raise ValueError("Particle density requires particle porosity εp in [0, 1)")
        return 1.0 - eps_p
    if density_basis == "bed":
        if eps_t is None or not 0.0 <= eps_t < 1.0:
            raise ValueError("Bed (packing) density requires total porosity εt in [0, 1)")
        return 1.0 - eps_t
    raise ValueError(f"Unknown density basis {density_basis!r}; expected one of {DENSITY_BASES}")


def parse_solid_unit(unit):
    """Split e.g. "mg/g resin" into ("mg", "g resin")."""
    amount, sep, basis = unit.partition("/")
    if not sep or basis not in SOLID_BASES:
        raise ValueError(f"Unknown solid concentration unit {unit!r}; expected '<amount>/<basis>' "
                         f"with amount in {AMOUNT_UNITS} and basis in {SOLID_BASES}")
    return amount, basis


def solid_factor(unit, mw=None, charge=None, eps_t=None, eps_p=None, density=None, density_basis="solid"):
    """Factor converting a stationary-phase concentration in ``unit`` to mol/m³ solid.

    ``unit`` is "<amount>/<basis>", e.g. "mmol/mL solid", "meq/mL bed", "mg/g resin".
      - "mL solid": per volume of solid skeleton (CADET basis)
      - "mL bed":   per volume of packed bed; q_bed = (1 − εt)·q_solid, needs ``eps_t``
      - "g resin":  per mass of resin, needs ``density`` [g/mL] given per ``density_basis``:
          "solid"    skeletal density  (g per mL solid)
          "particle" particle density  (g per mL particle incl. pores), needs ``eps_p``
          "bed"      packing density   (g per mL packed bed), needs ``eps_t``
    """
    amount, basis = parse_solid_unit(unit)
    per_ml_solid = _amount_factor(amount, mw, charge) / VOLUME["mL"]
    if basis == "mL solid":
        return per_ml_solid
    if basis == "mL bed":
        return per_ml_solid / _solid_volume_fraction("bed", eps_t=eps_t)
    # g resin: mol/g × ρ_solid [g/mL solid]
    if not density:
        raise ValueError("Basis 'g resin' requires a resin density [g/mL]")
    skeletal_density = density / _solid_volume_fraction(density_basis, eps_t=eps_t, eps_p=eps_p)
    return per_ml_solid * skeletal_density


def solid_to_si(q, unit="mmol/mL solid", mw=None, charge=None, eps_t=None, eps_p=None,
                density=None, density_basis="solid"):
    """Stationary-phase concentration (q, qmax, Λ) -> mol/m³ solid."""
    return _scale(q, solid_factor(unit, mw, charge, eps_t, eps_p, density, density_basis))


def solid_from_si(q, unit="mmol/mL solid", mw=None, charge=None, eps_t=None, eps_p=None,
                  density=None, density_basis="solid"):
    return _scale(q, 1.0 / solid_factor(unit, mw, charge, eps_t, eps_p, density, density_basis))


# --- Isotherm constants -----------------------------------------------------
# A constant with dimension [liquid]^a·[solid]^b·[time]^c scales by
# f_liq^a·f_sol^b·f_time^c, where each f is the GUI -> SI factor of that unit.

def isotherm_param_to_si(value, f_liquid=1.0, f_solid=1.0, f_time=1.0, liquid_exp=0, solid_exp=0, time_exp=0):
    """Convert an isotherm constant given its dimension exponents.

    Examples (GUI -> SI):
      Linear K [solid/liquid]:         solid_exp=1, liquid_exp=-1
      Langmuir K = ka/kd [1/liquid]:   liquid_exp=-1
      Langmuir ka [1/(liquid·time)]:   liquid_exp=-1, time_exp=-1
      kd [1/time]:                     time_exp=-1
    The ``f_*`` factors come from ``liquid_factor``/``solid_factor``/``time_factor``.
    """
    factor = f_liquid ** liquid_exp * f_solid ** solid_exp * f_time ** time_exp
    return _scale(value, factor)


def isotherm_param_from_si(value, f_liquid=1.0, f_solid=1.0, f_time=1.0, liquid_exp=0, solid_exp=0, time_exp=0):
    factor = f_liquid ** liquid_exp * f_solid ** solid_exp * f_time ** time_exp
    return _scale(value, 1.0 / factor)


def time_factor(unit="min"):
    return _lookup(TIME, unit, "time")


# --- Derived quantities in GUI units (spec §4 symbols) ----------------------

def total_porosity(eps_b, eps_p):
    """εt = εb + (1 − εb)·εp."""
    return eps_b + (1.0 - eps_b) * eps_p


def cross_section_area(diameter):
    """Column cross-section A = π·D²/4 (same length unit squared as ``diameter``)."""
    return np.pi * np.asarray(diameter, dtype=float) ** 2 / 4.0


def interstitial_velocity(flow_ml_min, diameter_cm, eps_b):
    """u = Q / (εb·A) in cm/min, from Q [mL/min] and D [cm]."""
    return np.asarray(flow_ml_min, dtype=float) / (eps_b * cross_section_area(diameter_cm))


def superficial_velocity(flow_ml_min, diameter_cm):
    """u_s = εb·u = Q / A in cm/min."""
    return np.asarray(flow_ml_min, dtype=float) / cross_section_area(diameter_cm)
