"""Simulated moving bed (SMB) on top of the Batch column definition.

The columns, binding, reactions and numerical settings come from a ``BatchSpec`` (``SMBSpec.base``), so every
Batch column and binding model works in SMB. The SMB part adds the layout (zones and ports), the switch time,
the flow rates and the feed / eluent compositions.

Layouts (liquid flows zone I → II → …; the ports move one column forward every switch):

  4-zone closed   eluent → I → extract | II | feed → III → raffinate | IV → back to I
  4-zone open     as above, but the zone IV outlet goes to waste (no recycle)
  3-zone          eluent → I → extract | II | feed → III → raffinate (all of it)
  5-zone closed   eluent → I → extract 1 | II → extract 2 | III | feed → IV → raffinate | V → back to I
                  (three products: strong, intermediate, weak)
  5-zone open     as above, but the zone V outlet goes to waste

Each layout has one port at the inlet of every zone (node p = inlet of zone p) and, for open layouts, an
outlet that takes the whole flow leaving the last zone. Zone flows are the canonical description; flow rates
can be entered three ways:
  "external": the feed, eluent and extract flows, and the last zone's flow where it is not fixed by them
  "zones":    Q of every zone
  "m":        m_j = (Q_j·t_s − V_c·εt) / (V_c·(1 − εt)) of every zone
"""
from dataclasses import asdict, dataclass, field

import numpy as np
from CADETProcess.modelBuilder import CarouselBuilder, SerialZone
from CADETProcess.processModel import ComponentSystem, Inlet, Outlet

from core import model_builder as mb
from core import units

ZONE_NAMES = ("I", "II", "III", "IV", "V")
FLOW_MODES = ("external", "zones", "m")
CYCLE_MODES = ("steady state", "fixed")
INLETS = ("eluent", "feed")
WASTE = "waste"


@dataclass(frozen=True)
class Layout:
    label: str
    closed: bool
    nodes: tuple            # (kind, name) of the port at the inlet of each zone; kind "in" or "out"
    end: str | None = None  # open layouts: the outlet taking everything that leaves the last zone

    @property
    def n_zones(self):
        return len(self.nodes)

    @property
    def zones(self):
        return ZONE_NAMES[:self.n_zones]

    @property
    def outlets(self):
        """All outlet streams in flow order (products and waste)."""
        return [name for kind, name in self.nodes if kind == "out"] + ([self.end] if self.end else [])

    @property
    def products(self):
        """Outlets whose contents count as products (not the waste)."""
        return [o for o in self.outlets if o != WASTE]

    @property
    def needs_last(self):
        """Whether the last zone's flow is an independent input (else the raffinate fixes it)."""
        return self.closed or (self.end is not None and self.end != "raffinate")

    def external_keys(self):
        keys = ["feed", "eluent"] + [name for kind, name in self.nodes if kind == "out" and name != "raffinate"]
        return keys + (["last"] if self.needs_last else [])


LAYOUTS = {
    "4-zone closed": Layout("4 zones, closed loop (zone IV recycled to zone I)", True,
                            (("in", "eluent"), ("out", "extract"), ("in", "feed"), ("out", "raffinate"))),
    "4-zone open": Layout("4 zones, open loop (zone IV outlet to waste)", False,
                          (("in", "eluent"), ("out", "extract"), ("in", "feed"), ("out", "raffinate")), WASTE),
    "3-zone": Layout("3 zones, open (no zone IV; zone III outlet is the raffinate)", False,
                     (("in", "eluent"), ("out", "extract"), ("in", "feed")), "raffinate"),
    "5-zone closed": Layout("5 zones, closed loop (zone V recycled), two extracts (three products)", True,
                            (("in", "eluent"), ("out", "extract_1"), ("out", "extract_2"), ("in", "feed"),
                             ("out", "raffinate"))),
    "5-zone open": Layout("5 zones, open loop (zone V outlet to waste), two extracts (three products)", False,
                          (("in", "eluent"), ("out", "extract_1"), ("out", "extract_2"), ("in", "feed"),
                           ("out", "raffinate")), WASTE),
}
STREAM_LABELS = {"feed": "feed", "eluent": "eluent", "extract": "extract", "extract_1": "extract 1",
                 "extract_2": "extract 2", "raffinate": "raffinate", WASTE: "waste"}
_SYMBOL = {"feed": "Q_F", "eluent": "Q_D", "extract": "Q_E", "extract_1": "Q_E1", "extract_2": "Q_E2",
           "raffinate": "Q_R", WASTE: "Q_W"}


def flow_labels(layout_name, mode):
    layout = LAYOUTS[layout_name]
    if mode == "zones":
        return [f"Q_{z}" for z in layout.zones]
    if mode == "m":
        return [f"m{chr(0x2080 + i + 1)}" for i in range(layout.n_zones)]
    last = layout.zones[-1]
    return [(f"Q_{last} recycle" if layout.closed else f"Q_{last} → {STREAM_LABELS[layout.end]}") if k == "last"
            else f"{_SYMBOL[k]} {STREAM_LABELS[k]}" for k in layout.external_keys()]


@dataclass
class CycleSettings:
    mode: str = "steady state"      # run until two cycles agree, or a fixed number of cycles
    n_cycles: int = 10              # fixed mode
    max_cycles: int = 50            # steady-state mode: stop here even if not converged
    threshold: float = 1e-3         # steady-state criterion (relative area and NRMSE of every unit)


@dataclass
class SMBSpec:
    base: mb.BatchSpec
    layout: str = "4-zone closed"
    columns_per_zone: list = field(default_factory=lambda: [1, 1, 1, 1])
    switch_time: float = 3.0                     # min
    flow_mode: str = "external"
    flows: list = field(default_factory=lambda: [0.5, 1.5, 1.0, 1.0])
    feed: list = field(default_factory=list)     # each component's liquid unit
    eluent: list = field(default_factory=list)
    cycles: CycleSettings = field(default_factory=CycleSettings)
    profile_interval: float = 0.0                # min between stored column profiles; 0 = automatic
    products: dict = field(default_factory=dict)  # outlet name -> component names collected there
    title: str = ""

    @property
    def components(self):
        return self.base.components

    @property
    def geometry(self) -> Layout:
        if self.layout not in LAYOUTS:
            raise ValueError(f"Unknown SMB layout {self.layout!r}; expected one of {list(LAYOUTS)}")
        return LAYOUTS[self.layout]

    @property
    def n_columns(self):
        return int(sum(self.columns_per_zone))

    @property
    def cycle_time(self):
        """min: every column visits every position once."""
        return self.n_columns * self.switch_time


@dataclass
class FlowSet:
    """All flow rates of an SMB in mL/min (zones and port streams), and the m values."""
    zones: tuple
    ports: dict
    m: tuple

    @property
    def feed(self):
        return self.ports["feed"]

    @property
    def eluent(self):
        return self.ports["eluent"]

    def table(self):
        out = {f"Q_{z}": q for z, q in zip(ZONE_NAMES, self.zones)}
        out.update({f"{_SYMBOL[k]} ({STREAM_LABELS[k]})": v for k, v in self.ports.items()})
        return out


def column_volume(spec: SMBSpec):
    """mL, one column."""
    col = spec.base.column
    return float(np.pi / 4 * col.diameter ** 2 * col.length)


def _eps_t(spec):
    return spec.base.column.total_porosity()


def _values(spec, n):
    if spec.flows is None or len(spec.flows) != n or any(v is None or v != v for v in spec.flows):
        raise ValueError(f"Enter all {n} flow values")
    return [float(v) for v in spec.flows]


def zone_flows(spec: SMBSpec):
    """Q of every zone [mL/min] from whichever flow input the spec uses."""
    layout = spec.geometry
    if spec.flow_mode not in FLOW_MODES:
        raise ValueError(f"Unknown flow input {spec.flow_mode!r}; expected one of {FLOW_MODES}")
    if spec.flow_mode == "zones":
        return tuple(_values(spec, layout.n_zones))
    if spec.flow_mode == "m":
        if not spec.switch_time > 0:
            raise ValueError("The switch time must be positive")
        v, et = column_volume(spec), _eps_t(spec)
        return tuple(v * (m * (1 - et) + et) / spec.switch_time for m in _values(spec, layout.n_zones))
    keys = layout.external_keys()
    given = dict(zip(keys, _values(spec, len(keys))))
    last = given.get("last")
    prev = last if layout.closed else 0.0
    q = []
    for p, (kind, name) in enumerate(layout.nodes):
        if kind == "in":
            cur = prev + given[name]
        elif name in given:
            cur = prev - given[name]
        else:                       # the raffinate in front of the last zone: that zone's flow is given
            cur = last
        q.append(cur)
        prev = cur
    return tuple(q)


def port_flows(spec: SMBSpec, q):
    """Flow of every port stream from the zone flows (positive = the right direction)."""
    layout = spec.geometry
    prev = q[-1] if layout.closed else 0.0
    out = {}
    for p, (kind, name) in enumerate(layout.nodes):
        out[name] = q[p] - prev if kind == "in" else prev - q[p]
        prev = q[p]
    if layout.end:
        out[layout.end] = q[-1]
    return out


def m_values(spec: SMBSpec, q_zones):
    v, et = column_volume(spec), _eps_t(spec)
    return tuple((q * spec.switch_time - v * et) / (v * (1 - et)) for q in q_zones)


def flow_set(spec: SMBSpec) -> FlowSet:
    q = zone_flows(spec)
    return FlowSet(zones=tuple(q), ports=port_flows(spec, q),
                   m=m_values(spec, q) if spec.switch_time > 0 else (np.nan,) * len(q))


def flows_as(spec: SMBSpec, mode):
    """The flow inputs of ``mode`` that give the same SMB (for switching the input mode)."""
    f = flow_set(spec)
    if mode == "zones":
        return list(f.zones)
    if mode == "m":
        return list(f.m)
    return [f.zones[-1] if k == "last" else f.ports[k] for k in spec.geometry.external_keys()]


def flow_problems(spec: SMBSpec):
    """Messages for flow rates that make no SMB (zone and port flows must all be positive)."""
    try:
        f = flow_set(spec)
    except ValueError as e:
        return [str(e)]
    out = []
    for name, q in zip(ZONE_NAMES, f.zones):
        if not q > 0:
            out.append(f"Zone {name} flow Q_{name} = {q:.4g} mL/min must be positive")
    for name, q in f.ports.items():
        if not q > 0:
            out.append(f"{STREAM_LABELS[name].capitalize()} {_SYMBOL[name]} = {q:.4g} mL/min must be positive")
    return out


def check(spec: SMBSpec):
    """Raise ``ValueError`` for an SMB that cannot be simulated."""
    layout = spec.geometry
    n = len(spec.components)
    if len(spec.columns_per_zone) != layout.n_zones or any(int(k) < 1 for k in spec.columns_per_zone):
        raise ValueError(f"Every zone needs at least one column ({layout.n_zones} zones)")
    if not spec.switch_time > 0:
        raise ValueError("The switch time must be positive")
    for name, values in (("feed", spec.feed), ("eluent", spec.eluent)):
        if values is None or len(values) != n or any(v is None or v != v for v in values):
            raise ValueError(f"Enter the {name} concentration of every component")
        if any(v < 0 for v in values):
            raise ValueError(f"The {name} concentrations cannot be negative")
    problems = flow_problems(spec)
    if problems:
        raise ValueError("; ".join(problems))
    cyc = spec.cycles
    if cyc.mode not in CYCLE_MODES:
        raise ValueError(f"Unknown cycle mode {cyc.mode!r}")
    if cyc.mode == "fixed" and int(cyc.n_cycles) < 1:
        raise ValueError("Run at least one cycle")
    if cyc.mode == "steady state" and int(cyc.max_cycles) < 2:
        raise ValueError("Steady state needs at least two cycles to compare")
    names = {c.name for c in spec.components}
    for outlet, chosen in spec.products.items():
        if outlet not in layout.products:
            raise ValueError(f"{outlet!r} is not a product outlet of the {spec.layout} layout")
        unknown = set(chosen) - names
        if unknown:
            raise ValueError(f"Unknown {STREAM_LABELS[outlet]} product(s): {', '.join(sorted(unknown))}")


def _solutes(spec):
    return spec.components[mb.modulator_count(spec.base.binding.model):]


def henry_coefficients(spec: SMBSpec):
    """{name: H} at infinite dilution of the adsorbing solutes for Linear / Langmuir binding (CADET's
    dimensionless form: bound per solid volume / liquid concentration); None otherwise."""
    b = spec.base.binding
    if b.model not in ("Linear", "Langmuir"):
        return None
    comps = spec.components
    binding = mb._build_binding(spec.base, ComponentSystem([c.name for c in comps]))
    ka, kd = np.array(binding.adsorption_rate), np.array(binding.desorption_rate)
    h = ka / kd * (np.array(binding.capacity) if b.model == "Langmuir" else 1.0)
    out = {c.name: float(v) for c, v in zip(comps, h) if c.bound}
    return out if len(out) >= 2 else None


def default_products(spec: SMBSpec):
    """{outlet: [names]}: the solutes ordered by Henry coefficient (strongest first) go to the product outlets
    in flow order (extracts first, raffinate last); with more solutes than outlets the strongest goes to the
    first extract and the weakest to the raffinate. Empty without Henry coefficients."""
    henry = henry_coefficients(spec)
    outlets = spec.geometry.products
    if henry is None:
        return {o: [] for o in outlets}
    order = [name for name, _ in sorted(henry.items(), key=lambda kv: -kv[1])]
    if len(order) == len(outlets):
        return {o: [name] for o, name in zip(outlets, order)}
    out = {o: [] for o in outlets}
    out[outlets[0]], out[outlets[-1]] = [order[0]], [order[-1]]
    return out


def triangle_available(spec: SMBSpec):
    h = henry_coefficients(spec)
    return spec.layout == "4-zone closed" and h is not None and len(h) == 2 and len(_solutes(spec)) == 2


def triangle_design(spec: SMBSpec, gamma=1.05):
    """m₁ … m₄ from the triangle theory (linear: at infinite dilution; Langmuir: CADET-Process's design for
    the feed concentration), with safety factor ``gamma`` (> 1 moves into the triangle). Only for the closed
    4-zone layout with two adsorbing components and Linear or Langmuir binding."""
    from CADETProcess.modelBuilder import LangmuirSMBBuilder, LinearSMBBuilder
    if not triangle_available(spec):
        raise ValueError("The triangle design needs the closed 4-zone layout and exactly two adsorbing "
                         "components with Linear or Langmuir binding")
    comps = spec.components
    cs = ComponentSystem([c.name for c in comps])
    binding = mb._build_binding(spec.base, cs)
    builder_cls = LinearSMBBuilder if spec.base.binding.model == "Linear" else LangmuirSMBBuilder
    builder = builder_cls.__new__(builder_cls)          # only the design maths are used
    c_feed = np.array([float(v) * c.liquid_factor() for v, c in zip(spec.feed, comps)])
    params = builder.get_design_parameters(binding, c_feed)
    m_opt = builder.calculate_m_opt(*params)
    return [float(v) for v in builder.apply_safety_factor(m_opt, *params, gamma=gamma)]


# --- CADET-Process -------------------------------------------------------------------------------

def _inlet(cs, name, values, comps, flow):
    inlet = Inlet(cs, name=name)
    inlet.c = [float(v) * c.liquid_factor() for v, c in zip(values, comps)]
    inlet.flow_rate = float(units.flow_to_si(flow))
    return inlet


def build_builder(spec: SMBSpec):
    """The CADET-Process ``CarouselBuilder`` of the SMB (zones of serial columns)."""
    check(spec)
    layout = spec.geometry
    comps = spec.components
    cs = ComponentSystem([c.name for c in comps])
    f = flow_set(spec)
    builder = CarouselBuilder(cs, "smb")
    builder.column = mb._build_column(spec.base, cs)
    inlets = {"feed": _inlet(cs, "feed", spec.feed, comps, f.feed),
              "eluent": _inlet(cs, "eluent", spec.eluent, comps, f.eluent)}
    for name in INLETS:
        builder.add_unit(inlets[name], feed_inlet=name == "feed", eluent_inlet=name == "eluent")
    outlets = {name: Outlet(cs, name=name) for name in layout.outlets}
    for unit in outlets.values():
        builder.add_unit(unit, product_outlet=True)
    zones = [SerialZone(cs, f"zone_{z}", int(k)) for z, k in zip(layout.zones, spec.columns_per_zone)]
    for zone in zones:
        builder.add_unit(zone)

    if layout.nodes[0] != ("in", "eluent"):
        raise ValueError("The eluent must enter zone I")
    builder.add_connection(inlets["eluent"], zones[0])
    if layout.closed:
        builder.add_connection(zones[-1], zones[0])
    for p in range(1, layout.n_zones):
        kind, name = layout.nodes[p]
        upstream = zones[p - 1]
        if kind == "out":
            builder.add_connection(upstream, outlets[name])           # destinations in this order …
            builder.add_connection(upstream, zones[p])
            w = f.ports[name] / f.zones[p - 1]
            builder.set_output_state(upstream, [w, 1 - w])            # … match the split fractions
        else:
            builder.add_connection(upstream, zones[p])
            builder.add_connection(inlets[name], zones[p])
    if layout.end:
        builder.add_connection(zones[-1], outlets[layout.end])
    builder.switch_time = float(units.time_to_si(spec.switch_time))
    return builder


def build_process(spec: SMBSpec, initial_state=None):
    """CADET-Process ``Process`` for one cycle; ``initial_state`` = (state, derivative) to continue."""
    process = build_builder(spec).build_process()
    if initial_state is not None:
        process.system_state, process.system_state_derivative = (np.asarray(a, dtype=float)
                                                                 for a in initial_state)
    return process


def column_order(spec: SMBSpec, t):
    """Physical column index at each ring position (position 0 = first column of zone I) at time ``t``
    [min]. Every switch moves the ports one column forward, i.e. each column one position back."""
    n = spec.n_columns
    state = int(np.floor(t / spec.switch_time + 1e-9)) % n
    return [(p + state) % n for p in range(n)]


def zone_of_position(spec: SMBSpec):
    out = []
    for zone, k in zip(spec.geometry.zones, spec.columns_per_zone):
        out += [zone] * int(k)
    return out


def port_positions(spec: SMBSpec):
    """{stream: ring position} of every port, in column lengths from the eluent port (open layouts: the end
    outlet at n_columns)."""
    layout = spec.geometry
    starts = np.cumsum([0] + [int(k) for k in spec.columns_per_zone])
    out = {name: int(starts[p]) for p, (_, name) in enumerate(layout.nodes)}
    if layout.end:
        out[layout.end] = spec.n_columns
    return out


def state_structure(spec: SMBSpec) -> dict:
    """What a saved SMB state depends on (for continuing a run)."""
    return {"layout": spec.layout, "columns_per_zone": [int(k) for k in spec.columns_per_zone],
            **mb.state_structure(spec.base)}


# --- Dict round trip -----------------------------------------------------------------------------

def spec_to_dict(spec: SMBSpec) -> dict:
    d = asdict(spec)
    d["base"] = mb.spec_to_dict(spec.base)
    return d


def spec_from_dict(d: dict) -> SMBSpec:
    d = dict(d)
    d["base"] = mb.spec_from_dict(d["base"])
    d["cycles"] = CycleSettings(**d.get("cycles", {}))
    if d.get("layout") == "5-zone":                                    # name before the open variant existed
        d["layout"] = "5-zone closed"
    if "extract_products" in d or "raffinate_products" in d:          # files from the first SMB version
        d["products"] = {"extract": d.pop("extract_products", []), "raffinate": d.pop("raffinate_products", [])}
    return SMBSpec(**d)
