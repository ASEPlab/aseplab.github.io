"""SMB images and videos: the ring-profile animation as MP4 / GIF, and the process layout of every switch as PNG.

Drawn with matplotlib (Agg, no display); videos are encoded by ``core.animation.encode``.
"""
import io
import zipfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import FancyBboxPatch  # noqa: E402

from core import animation, smb  # noqa: E402

PHASE_TITLES = animation.PHASE_TITLES
_SIZE_PX = (1200, 540)       # even dimensions for H.264
_DPI = 120
ZONE_COLORS = {"I": ("#EEEDFE", "#534AB7"), "II": ("#E1F5EE", "#0F6E56"), "III": ("#FAECE7", "#993C1D"),
               "IV": ("#F1EFE8", "#5F5E5A"), "V": ("#FAEEDA", "#854F0B")}
PORT_COLORS = {"eluent": "#1D9E75", "feed": "#D85A30", "extract": "#7F77DD", "extract_1": "#7F77DD",
               "extract_2": "#D4537E", "raffinate": "#BA7517", smb.WASTE: "#888780"}


def _cycle_switch(spec, t):
    cycle = int(t // spec.cycle_time + 1e-9)
    switch = int((t - cycle * spec.cycle_time) // spec.switch_time + 1e-9) % spec.n_columns
    return cycle, switch


# --- Ring-profile video --------------------------------------------------------------------------------

def _ring_frames(result, phase, components, colors, frame_idx, fixed_y):
    spec = result.spec
    data = getattr(result, phase)
    comps = [i for i in components if not np.all(np.isnan(data[..., i]))]
    if not comps:
        raise ValueError(f"No component has {phase} values to animate")
    fig, ax = plt.subplots(figsize=(_SIZE_PX[0] / _DPI, _SIZE_PX[1] / _DPI), dpi=_DPI)
    edges = np.cumsum([0] + [int(v) for v in spec.columns_per_zone])
    for z, (a, b) in enumerate(zip(edges, edges[1:])):
        name = spec.geometry.zones[z]
        ax.axvspan(a, b, color=ZONE_COLORS[name][0], zorder=0)
        ax.text(a + 0.03, 1.0, f"zone {name}", transform=ax.get_xaxis_transform(), va="top", fontsize=9,
                color=ZONE_COLORS[name][1])
    for c in range(1, spec.n_columns):
        ax.axvline(c, color="#888780", lw=0.5, ls=":")
    kinds = {name: kind for kind, name in spec.geometry.nodes}
    for name, x in smb.port_positions(spec).items():
        arrow = "↓" if kinds.get(name) == "in" else "↑"
        ax.text(x, 1.02, f"{smb.STREAM_LABELS[name].capitalize()} {arrow}", transform=ax.get_xaxis_transform(),
                ha="center", va="bottom", fontsize=9, color=PORT_COLORS.get(name, "#444"))
    positions, first = result.ring_profile(phase, frame_idx[0])
    lines = [ax.plot(positions, first[:, i], lw=2, color=colors[i % len(colors)],
                     label=f"{result.components[i].name} [{result.unit(phase, i)}]")[0] for i in comps]
    ax.set_xlim(0, spec.n_columns)
    ax.set_xticks([p + 0.5 for p in range(spec.n_columns)])
    unit_set = {result.unit(phase, i) for i in comps}
    ax.set_ylabel(f"{PHASE_TITLES[phase]} concentration" + (f" [{unit_set.pop()}]" if len(unit_set) == 1 else ""))
    ax.legend(loc="upper right", frameon=False, fontsize=9)
    y_max = float(np.nanmax(data[..., comps]))
    title = fig.suptitle("", fontsize=11)
    fig.subplots_adjust(top=0.86, bottom=0.12, left=0.07, right=0.98)
    try:
        for k in frame_idx:
            positions, values = result.ring_profile(phase, k)
            for line, i in zip(lines, comps):
                line.set_data(positions, values[:, i])
            if fixed_y:
                ax.set_ylim(0, 1.05 * y_max if y_max > 0 else 1.0)
            else:
                ax.relim()
                ax.autoscale_view(scalex=False)
            t = result.profile_time[k]
            ax.set_xticklabels([f"col {c + 1}" for c in smb.column_order(spec, t)])
            cycle, switch = _cycle_switch(spec, t)
            title.set_text(f"t = {t:.4g} min · cycle {cycle + 1} · switch {switch + 1} of {spec.n_columns}")
            fig.canvas.draw()
            yield np.asarray(fig.canvas.buffer_rgba())[:, :, :3].copy()
    finally:
        plt.close(fig)


def ring_video(result, phase, components, colors, fmt="mp4", fps=10, max_frames=300, fixed_y=True,
               frame_range=None):
    """The ring profile of ``phase`` over ``frame_range`` = (first, last) profile index (default: the whole
    run), at most ``max_frames`` evenly spaced frames; returns the file bytes."""
    lo, hi = frame_range or (0, len(result.profile_time) - 1)
    idx = np.unique(np.round(np.linspace(lo, hi, min(hi - lo + 1, max_frames))).astype(int))
    return animation.encode(_ring_frames(result, phase, list(components), colors, idx, fixed_y), fmt, fps,
                            size=_SIZE_PX)


# --- Process layout images --------------------------------------------------------------------------------

def layout_figure(spec: smb.SMBSpec, state):
    """matplotlib figure of the columns, pipes and ports during switch ``state`` (0-based) of a cycle."""
    n = spec.n_columns
    layout = spec.geometry
    flows = smb.flow_set(spec).ports
    zones = smb.zone_of_position(spec)
    fig, ax = plt.subplots(figsize=(12, 4.2), dpi=_DPI)
    ax.set_xlim(-1.2, n * 1.6 + 0.6)
    ax.set_ylim(-3.0, 2.3)
    ax.axis("off")
    w, h, gap = 1.1, 0.8, 0.5
    x = lambda c: c * (w + gap)                                  # noqa: E731  left edge of physical column c
    pos = lambda c: (c - state) % n                              # noqa: E731  ring position of column c
    at_ring = lambda p: (p + state) % n                          # noqa: E731  column at ring position p
    broken = None if layout.closed else at_ring(n - 1)
    arrow = dict(arrowstyle="-|>", color="#888780", lw=1.5, shrinkA=0, shrinkB=0)
    for c in range(n):
        fill, edge = ZONE_COLORS[zones[pos(c)]]
        ax.add_patch(FancyBboxPatch((x(c), -h / 2), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                    facecolor=fill, edgecolor=edge, lw=1.2))
        ax.text(x(c) + w / 2, 0.12, f"col {c + 1}", ha="center", va="center", fontsize=10, color=edge)
        ax.text(x(c) + w / 2, -0.18, f"zone {zones[pos(c)]}", ha="center", va="center", fontsize=9, color=edge)
        if c < n - 1 and c != broken:
            ax.annotate("", xy=(x(c + 1), 0), xytext=(x(c) + w, 0), arrowprops=arrow)
    if broken != n - 1:                                          # recycle: last physical column back to the first
        right, left, y = x(n - 1) + w + 0.3, -0.4, -2.6
        ax.plot([x(n - 1) + w, right, right, left, left], [0, 0, y, y, 0], color="#888780", lw=1.5)
        ax.annotate("", xy=(x(0), 0), xytext=(left, 0), arrowprops=arrow)
    kinds = {name: kind for kind, name in layout.nodes}
    n_in = n_out = 0
    for name, p in smb.port_positions(spec).items():
        color = PORT_COLORS.get(name, "#888780")
        label = f"{smb.STREAM_LABELS[name].capitalize()} {flows[name]:.3g} mL/min"
        if kinds.get(name) == "in":
            c = at_ring(p)
            xx, top = (x(c) - 0.12 if c else -0.25), 1.2 + 0.45 * n_in
            n_in += 1
            ax.annotate("", xy=(xx, h / 2 - 0.05), xytext=(xx, top),
                        arrowprops=dict(arrowstyle="-|>", color=color, lw=2))
            ax.text(xx + 0.05, top + 0.05, label, color=color, fontsize=9, va="bottom")
        else:
            c = at_ring(p - 1)
            xx, bottom = x(c) + w + 0.12, -0.9 - 0.4 * n_out
            n_out += 1
            ax.annotate("", xy=(xx, bottom), xytext=(xx, -h / 2 + 0.05),
                        arrowprops=dict(arrowstyle="-|>", color=color, lw=2))
            ax.text(xx + 0.05, bottom - 0.05, label, color=color, fontsize=9, va="top")
    t0 = state * spec.switch_time
    ax.set_title((f"{spec.title} · " if spec.title else "") + f"{layout.label}\nSwitch {state + 1} of {n} "
                 f"(t = {t0:g}–{t0 + spec.switch_time:g} min in every cycle)", fontsize=11)
    fig.tight_layout()
    return fig


def layout_png(spec: smb.SMBSpec, state):
    fig = layout_figure(spec, state)
    try:
        buffer = io.BytesIO()
        fig.savefig(buffer, format="png", dpi=_DPI)
        return buffer.getvalue()
    finally:
        plt.close(fig)


def layout_zip(spec: smb.SMBSpec):
    """ZIP of ``switch_01.png`` … one image per switch of a cycle."""
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as z:
        for s in range(spec.n_columns):
            z.writestr(f"switch_{s + 1:02d}.png", layout_png(spec, s))
    return buffer.getvalue()
