"""Everything about a run in one Excel workbook (.xlsx).

Sheets
  Summary           title and dates, inputs, mass-transfer coefficients, dimensionless numbers, results — as
                    text and small tables, stacked on one sheet (everything the Results viewer and the Batch
                    screen show)
  Data              graphable columns: time, inlet, outlet (and the column outlet when there is dead volume)
  Charts            native Excel charts of the Data columns
  Profile <phase>   concentrations along the column at evenly spaced times (bulk / pore / solid);
                    only when asked for (``include_profiles``)
  Input parameters  every input as ``parameter, value`` (flat list)

All values are in GUI units. The outlet is the system outlet, i.e. after the outlet dead-volume tank;
the Data sheet also has the concentration leaving the column itself when there is dead volume.
"""
import datetime
import io
import math

import numpy as np
import xlsxwriter

from core import correlations, dimensionless, mass, tolerances, units
from core.model_builder import modulator_count, spec_to_dict
from core.naming import stamped
from core.palette import SERIES_COLORS

SUMMARY, DATA, CHARTS, INPUTS = "Summary", "Data", "Charts", "Input parameters"
PROFILE_SHEETS = {"bulk": "Profile bulk", "pore": "Profile pore", "solid": "Profile solid"}
PHASE_NAMES = {"bulk": "bulk liquid", "pore": "pore liquid (particle average)", "solid": "solid (particle average)"}
SUMMARY_WIDTHS = [36, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16]


# --- cell writing ---------------------------------------------------------------------------------

def _formats(wb):
    return {
        "title": wb.add_format({"bold": True, "font_size": 15}),
        "section": wb.add_format({"bold": True, "font_size": 12, "bg_color": "#DCE6F1", "border": 1}),
        "header": wb.add_format({"bold": True, "bottom": 1, "text_wrap": True, "valign": "top"}),
        "label": wb.add_format({}),
        "note": wb.add_format({"italic": True, "font_color": "#595959"}),
        "bold": wb.add_format({"bold": True}),
    }


def _write(ws, r, c, v, fmt=None):
    """One cell: numbers as numbers (inf shown as ∞, NaN blank), bool as yes/no, lists comma-joined."""
    if v is None:
        return
    if isinstance(v, (bool, np.bool_)):
        ws.write_string(r, c, "yes" if v else "no", fmt)
    elif isinstance(v, (int, float, np.integer, np.floating)):
        v = float(v)
        if math.isnan(v):
            return
        if math.isinf(v):
            ws.write_string(r, c, "∞" if v > 0 else "−∞", fmt)
        else:
            ws.write_number(r, c, v, fmt)
    elif isinstance(v, (list, tuple, np.ndarray)):
        ws.write_string(r, c, ", ".join(str(x) for x in v), fmt)
    else:
        ws.write_string(r, c, str(v), fmt)


class _Page:
    """Sequential writer for the Summary sheet."""

    def __init__(self, ws, fmt):
        self.ws, self.fmt, self.row = ws, fmt, 0

    def title(self, text):
        self.ws.write_string(self.row, 0, text, self.fmt["title"])
        self.row += 1

    def section(self, text):
        self.row += 1
        self.ws.merge_range(self.row, 0, self.row, 7, text, self.fmt["section"])
        self.row += 1

    def kv(self, label, value, unit=""):
        self.ws.write_string(self.row, 0, label, self.fmt["label"])
        _write(self.ws, self.row, 1, value)
        if unit:
            self.ws.write_string(self.row, 2, unit, self.fmt["note"])
        self.row += 1

    def note(self, text):
        self.ws.write_string(self.row, 0, text, self.fmt["note"])
        self.row += 1

    def table(self, headers, rows):
        for c, h in enumerate(headers):
            self.ws.write_string(self.row, c, str(h), self.fmt["header"])
        self.row += 1
        for r in rows:
            for c, v in enumerate(r):
                _write(self.ws, self.row, c, v)
            self.row += 1
        self.row += 1


def _try(page, what, fn):
    """Run one summary section; if it cannot be computed say so instead of failing the export."""
    try:
        fn()
    except (ValueError, TypeError, KeyError, ZeroDivisionError, IndexError, AttributeError) as e:
        page.note(f"{what}: not available ({e})")


# --- Summary sheet --------------------------------------------------------------------------------

def _binding_table(spec):
    b, comps, g = spec.binding, spec.components, spec.binding.giex
    k = modulator_count(b.model)
    kin = b.kinetic
    cols = []
    if b.model == "Freundlich":
        cols = [("K_F", b.equilibrium), ("n", b.exponent)] + ([("k_LDF [1/min]", b.ldf_rate)] if kin else [])
    elif b.model != "None":
        cols = [("ka", b.adsorption_rate), ("kd [1/min]", b.desorption_rate)] if kin else [("K", b.equilibrium)]
        if b.model in ("Langmuir", "AntiLangmuir", "BiLangmuir"):
            cols.append(("qmax", b.capacity))
        if b.model == "AntiLangmuir":
            cols.append(("p (±1)", b.sign))
        if b.model == "BiLangmuir" and b.site2 is not None:
            cols += ([("ka2", b.site2.adsorption_rate), ("kd2 [1/min]", b.site2.desorption_rate)] if kin
                     else [("K2", b.site2.equilibrium)]) + [("qmax2", b.site2.capacity)]
        if b.model in ("SMA", "GIEX") and g is not None:
            cols += [("σ", g.steric_factor), ("ν (charge)", [c.charge for c in comps])]
        if b.model == "GIEX" and g is not None:
            for tag, field in (("ln ka", "adsorption_ph"), ("ln kd", "desorption_ph"), ("ν", "charge_ph")):
                if field == "desorption_ph" and not kin:
                    continue
                triples = getattr(g, field)
                for j in range(3):
                    cols.append((f"{tag}·x^{j + 1}", [None if t is None else t[j] for t in triples]
                                 if triples is not None else None))
            for tag, field in (("ka salt", "adsorption_salt"), ("kd salt", "desorption_salt"),
                               ("ka protein", "adsorption_protein"), ("kd protein", "desorption_protein")):
                vals = getattr(g, field)
                if vals is not None and any(v for v in vals if v):
                    cols.append((tag, vals))
    headers = ["component", "liquid unit", "solid unit"] + [name for name, _ in cols]
    rows = []
    for i, comp in enumerate(comps):
        if not comp.bound or i < k:
            continue
        rows.append([comp.name, comp.liquid_unit, comp.solid_unit]
                    + [vals[i] if vals is not None and i < len(vals) else None for _, vals in cols])
    return headers, rows


def _program_rows(spec):
    segments = spec.operation.program()
    duration = spec.settings.duration
    ends = [s.start for s in segments[1:]] + [duration]
    rows = []
    for seg, end in zip(segments, ends):
        if seg.start > duration:
            break
        end = min(end, duration)
        tau = end - seg.start
        polys = [list(p) + [0.0] * (4 - len(p)) for p in seg.coefficients]
        rows.append([seg.start, end] + [p[0] for p in polys]
                    + [sum(a * tau ** k for k, a in enumerate(p)) for p in polys])
    return rows


def _when(text):
    """'2026-10-06T13:56:00' -> '2026-10-06 13:56:00' (None if unknown)."""
    try:
        return datetime.datetime.fromisoformat(text).strftime("%Y-%m-%d %H:%M:%S") if text else None
    except ValueError:
        return text


def export_filename(result, when=None):
    """``<title>_YYYYMMDD_HHMMSS.xlsx`` (``cadet_results_…`` without a title)."""
    return stamped(result.spec.title, "xlsx", when)


def _summary_sheet(wb, fmt, result, created):
    ws = wb.add_worksheet(SUMMARY)
    for c, w in enumerate(SUMMARY_WIDTHS):
        ws.set_column(c, c, w)
    page = _Page(ws, fmt)
    spec, s = result.spec, result.summary
    comps, col, op, st, b = spec.components, spec.column, spec.operation, spec.settings, spec.binding
    names = [c.name for c in comps]
    n_mod = modulator_count(b.model)
    flow = op.flow_rate
    ecv = bool(op.dead_volume and op.dead_volume > 0)

    page.title(spec.title or "Untitled simulation")
    page.kv("Simulation completed", _when(s.get("completed")) or "(date not stored in this result)")
    page.kv("Workbook created", created.strftime("%Y-%m-%d %H:%M:%S"))
    page.note("CADET GUI simulation summary. All values in GUI units (cm, mL, mL/min, min, µm; concentrations in "
              "each component's own unit).")

    page.section("Run")
    page.kv("Status", "OK" if s.get("exit_flag") == 0 else f"exit flag {s.get('exit_flag')}: {s.get('exit_message', '')}")
    page.kv("Computation time", s.get("time_elapsed_s"), "s")
    page.kv("Output points", len(result.time))
    page.kv("Column model", col.model)
    page.kv("Binding model", b.model + (" (kinetic)" if b.kinetic else " (rapid equilibrium)") if b.model != "None" else "None")
    page.kv("Components", len(comps))
    page.kv("Mobile-phase reactions", len(spec.reactions.reactions) if spec.reactions else 0)
    if spec.initial_state_source:
        page.kv("Started from", spec.initial_state_source)

    page.section("Components")
    page.table(["name", "MW [g/mol]", "charge ν", "adsorbs", "liquid unit", "solid unit", "role"],
               [[c.name, c.mw, c.charge, c.bound, c.liquid_unit, c.solid_unit,
                 ("salt (counter-ion)" if i == 0 else "pH modulator") if i < n_mod else "solute"]
                for i, c in enumerate(comps)])

    page.section("Column and process")
    area = float(units.cross_section_area(col.diameter))
    page.kv("Length L", col.length, "cm")
    page.kv("Diameter D", col.diameter, "cm")
    page.kv("Column volume", col.length * area, "mL")
    page.kv("Bed porosity εb", col.eps_b)
    page.kv("Particle porosity εp", col.eps_p)
    page.kv("Total porosity εt", col.total_porosity())
    page.kv("Particle radius R", col.radius, "µm")
    page.kv("Flow rate Q", flow, "mL/min")
    _try(page, "Velocities", lambda: (
        page.kv("Interstitial velocity u", dimensionless.velocity(col, flow), "cm/min"),
        page.kv("Superficial velocity u_s", float(units.superficial_velocity(flow, col.diameter)), "cm/min")))
    page.kv("Extra-column (dead) volume", op.dead_volume if ecv else 0.0, "mL" + (" (two tanks of V/2)" if ecv else ""))
    if op.injection is not None:
        inj = op.injection
        page.kv("Injection volume", inj.volume, "mL")
        page.kv("Injection start", inj.start, "min")
        page.kv("Injection time V/Q", inj.volume / flow, "min")
        page.kv("Injection end", inj.start + inj.volume / flow, "min")
        page.table(["component", "feed concentration", "unit"],
                   [[c.name, f, c.liquid_unit] for c, f in zip(comps, inj.feed or [])])

    page.section("Inlet / eluent program (what the column receives; injection included)")
    _try(page, "Inlet program", lambda: page.table(
        ["from [min]", "to [min]"] + [f"start: {c.name} [{c.liquid_unit}]" for c in comps]
        + [f"end: {c.name} [{c.liquid_unit}]" for c in comps], _program_rows(spec)))

    page.section("Initial state")
    liquid = col.initial_liquid or [0.0] * len(comps)
    solid = col.initial_solid or [0.0] * len(comps)
    page.table(["component", "c0 (bulk and pore liquid)", "liquid unit", "q0 (bound)", "solid unit"],
               [[c.name, liquid[i], c.liquid_unit, solid[i] if c.bound else None, c.solid_unit if c.bound else None]
                for i, c in enumerate(comps)])

    page.section("Binding")
    if b.model == "None":
        page.note("No adsorption.")
    else:
        headers, rows = _binding_table(spec)
        page.table(headers, rows)
        if b.giex is not None and n_mod:
            g = b.giex
            page.kv("Capacity Λ", g.capacity, g.capacity_unit)
            page.kv("c_ref (salt)", g.reference_liquid, comps[0].liquid_unit)
            page.kv("q_ref", g.capacity if g.reference_solid is None else g.reference_solid, g.capacity_unit)
            if b.model == "GIEX":
                page.kv("pH_ref", g.ph_ref)

    page.section("Mass transfer")
    cor = spec.correlation
    page.kv("Source", "correlation estimate" if cor else "direct input")
    page.kv("Axial dispersion Eb", col.axial_dispersion, "cm²/min")
    kf_name = {"GRM": "kf [cm/min]", "LRMP": "kf [cm/min]", "LRM_keff": "keff [cm/min]"}.get(col.model)
    if kf_name and col.film_diffusion is not None:
        headers = ["component", kf_name]
        columns = [col.film_diffusion]
        if col.model == "GRM" and col.pore_diffusion is not None:
            headers.append("Dp [cm²/min]")
            columns.append(col.pore_diffusion)
        if cor and cor.molecular_diffusion is not None:
            headers.append("Dm [cm²/min]")
            columns.append(cor.molecular_diffusion)
        page.table(headers, [[c.name] + [v[i] if v is not None and i < len(v) else None for v in columns]
                             for i, c in enumerate(comps)])
    elif col.model == "LRM":
        page.note("LRM (CADET original): mass transfer is lumped into the binding kinetics.")
    if cor:
        def estimates():
            fluid = correlations.Fluid(cor.viscosity, cor.density)
            use_dp = cor.pore_diffusion if (col.model == "GRM" or cor.keff_from_glueckauf) else None
            est = correlations.estimate(flow, col.diameter, col.radius, col.eps_b, col.eps_p,
                                        cor.molecular_diffusion, fluid, dp_cm2_min=use_dp)
            page.kv("Viscosity μ", cor.viscosity, "cP")
            page.kv("Density ρ", cor.density, "g/mL")
            page.kv("Reynolds number Re", est.re)
            page.kv("Chung & Wen Eb", est.axial_dispersion, "cm²/min")
            headers = ["component", "Sc", "kf, Wilson & Geankoplis [cm/min]"]
            rows = [[c.name, est.sc[i], est.film_diffusion[i]] for i, c in enumerate(comps)]
            if est.keff is not None:
                headers.append("keff, Glueckauf [cm/min]")
                rows = [r + [est.keff[i]] for i, r in enumerate(rows)]
            page.table(headers, rows)
            for w in est.warnings:
                page.note("Warning: " + w)
        _try(page, "Correlation estimates", estimates)

    if spec.reactions is not None and spec.reactions.reactions:
        page.section("Mobile-phase reactions")
        page.kv("Rate-constant concentration basis", spec.reactions.basis)
        page.table(["reaction", "k+", "k−", "Ka = k+/k−"],
                   [[r.equation, r.k_fwd, r.k_bwd, r.equilibrium] for r in spec.reactions.reactions])
        _try(page, "Reaction numbers", lambda: page.table(
            ["reaction", "Nk+", "Nk−", "Nk+/Nk−", "note"],
            [[g["reaction"], g["Nk+"], g["Nk−"], g["Nk+/Nk−"], g["note"]]
             for g in dimensionless.reaction_groups(spec)]))

    page.section("Simulation settings")
    page.kv("Total time", st.duration, "min")
    page.kv("Output interval", st.output_interval, "min")
    page.kv("Axial cells", st.n_col)
    if col.model == "GRM":
        page.kv("Particle cells", st.n_par)
    page.kv("Max computation time", st.timeout, "s")

    def tol():
        t = tolerances.effective_tolerances(spec)
        page.kv("Solver tolerances", "automatic (scaled to the concentrations)" if st.tolerance_mode == "auto" else "manual")
        page.kv("reltol", t.reltol)
        page.kv("abstol", t.abstol, "mol/m³")
        page.kv("algtol", t.algtol)
        page.kv("WENO epsilon", t.weno_eps)
    _try(page, "Solver tolerances", tol)

    page.section("Dimensionless numbers")

    def groups():
        values = dimensionless.groups(col, flow, len(comps))
        page.table(["component"] + list(values), [[names[i]] + [v[i] for v in values.values()]
                                                  for i in range(len(comps))])
        for message in dimensionless.diagnose(values, names):
            page.note(message)
    _try(page, "Dimensionless groups", groups)

    page.section("Results")
    _try(page, "Amounts", lambda: (page.note("Amount = ∫ C·Q dt: input exactly from the inlet program, "
                                            "output by the trapezoid rule at the outlet."),
                                    _amounts(page, result)))
    _try(page, "Peaks", lambda: _peaks(page, result))
    _try(page, "Numerical checks", lambda: page.table(
        ["component", "NaN values", "negative undershoot / peak"],
        [[i, r["NaN values"], r["negative undershoot / peak"]] for i, r in mass.numerical_checks(result).iterrows()]))
    page.note("CADET-Core 5.1.1 does not report step counts or error-test / Newton failures; NaNs and negative "
              "undershoot of the outlet are shown instead.")
    page.note("Outlet = the system outlet" + (" (after the outlet dead volume); the Data sheet also has the "
                                               "concentration leaving the column itself." if ecv else "."))
    ws.freeze_panes(1, 0)


def _amounts(page, result):
    table = mass.mass_table(result)
    page.table(["component", "unit", "input", "output"], [[i, r["unit"], r["input"], r["output"]]
                                                          for i, r in table.iterrows()])


def _peaks(page, result):
    rows = []
    for i, comp in enumerate(result.components):
        if comp.liquid_unit == units.MODULATOR_UNIT:
            continue
        c = result.outlet[:, i]
        if not np.isfinite(c).all() or c.max() <= 0:
            continue
        area = np.trapezoid(c, result.time)
        rows.append([comp.name, float(c.max()), float(result.time[c.argmax()]),
                     float(np.trapezoid(result.time * c, result.time) / area) if area > 0 else None, comp.liquid_unit])
    if rows:
        page.table(["component", "peak concentration", "time of peak [min]", "mean elution time [min]", "unit"], rows)


# --- Data and Charts sheets ---------------------------------------------------------------------------

def _data_sheet(wb, fmt, result):
    """Graphable columns; returns the column index of each series for the charts."""
    ws = wb.add_worksheet(DATA)
    spec, comps = result.spec, result.components
    ecv = bool(spec.operation.dead_volume and spec.operation.dead_volume > 0)
    outlet_tag = "outlet (after dead volume)" if ecv else "outlet"
    cols = [("time [min]", result.time)]
    index = {"inlet": {}, "outlet": {}, "column_outlet": {}}
    for i, c in enumerate(comps):
        index["inlet"][i] = len(cols)
        cols.append((f"inlet {c.name} [{c.liquid_unit}]", result.inlet[:, i]))
    for i, c in enumerate(comps):
        index["outlet"][i] = len(cols)
        cols.append((f"{outlet_tag} {c.name} [{c.liquid_unit}]", result.outlet[:, i]))
    if ecv and result.column_outlet is not None:
        for i, c in enumerate(comps):
            index["column_outlet"][i] = len(cols)
            cols.append((f"column outlet (before dead volume) {c.name} [{c.liquid_unit}]", result.column_outlet[:, i]))
    for c, (header, values) in enumerate(cols):
        ws.write_string(0, c, header, fmt["header"])
        ws.set_column(c, c, max(14, min(34, len(header) * 0.9)))
        ws.write_column(1, c, np.asarray(values, dtype=float))
    ws.freeze_panes(1, 1)
    return index


def _charts_sheet(wb, fmt, result, index):
    ws = wb.add_worksheet(CHARTS)
    spec, comps, nt = result.spec, result.components, len(result.time)
    n_mod = modulator_count(spec.binding.model)
    duration = float(result.time[-1])

    def chart(title, series, y_title, x=0, y=0):
        ch = wb.add_chart({"type": "scatter", "subtype": "straight"})
        for kind, i in series:
            col = index[kind][i]
            label = {"inlet": "inlet", "outlet": "outlet", "column_outlet": "column outlet"}[kind]
            ch.add_series({
                "name": f"{label} {comps[i].name}",
                "categories": [DATA, 1, 0, nt, 0], "values": [DATA, 1, col, nt, col],
                "line": {"color": SERIES_COLORS[i % len(SERIES_COLORS)], "width": 1.75,
                         "dash_type": "dash" if kind == "inlet" else "solid"},
                "marker": {"type": "none"},
            })
        ch.set_title({"name": title, "name_font": {"size": 12}})
        ch.set_x_axis({"name": "Time [min]", "min": 0, "max": duration, "major_gridlines": {"visible": True,
                                                                                            "line": {"color": "#E5E5E5"}}})
        ch.set_y_axis({"name": y_title, "major_gridlines": {"visible": True, "line": {"color": "#E5E5E5"}}})
        ch.set_legend({"position": "bottom"})
        ch.set_size({"width": 760, "height": 340})
        ws.insert_chart(y, x, ch)

    solutes = list(range(n_mod, len(comps)))
    units_set = {comps[i].liquid_unit for i in solutes}
    y_title = f"Concentration [{next(iter(units_set))}]" if len(units_set) == 1 else "Concentration"
    ws.write_string(0, 0, "Charts of the Data sheet. Change the series there to plot other columns.", fmt["note"])
    row = 1
    if solutes:
        chart("Outlet concentration", [("outlet", i) for i in solutes], y_title, 0, row)
        chart("Inlet concentration (injection included)", [("inlet", i) for i in solutes], y_title, 13, row)
        row += 18
    for i in range(n_mod):
        unit = comps[i].liquid_unit
        chart(f"{comps[i].name}: inlet and outlet", [("inlet", i), ("outlet", i)],
              "pH" if unit == units.MODULATOR_UNIT else f"Concentration [{unit}]", 0 if i == 0 else 13, row)
    return ws


def _profile_sheet(wb, fmt, result, phase, n_times):
    ws = wb.add_worksheet(PROFILE_SHEETS[phase])
    data = getattr(result, phase)
    nt = len(result.time)
    idx = np.unique(np.round(np.linspace(0, nt - 1, min(nt, n_times))).astype(int))
    comps = [i for i in range(len(result.components)) if not np.all(np.isnan(data[:, :, i]))]
    ws.write_string(0, 0, "t [min] →", fmt["bold"])
    ws.write_string(1, 0, "z [cm] ↓   component →", fmt["bold"])
    ws.write_column(2, 0, result.z)
    ws.set_column(0, 0, 22)
    col = 1
    for k in idx:
        for i in comps:
            ws.write_number(0, col, float(result.time[k]), fmt["bold"])
            ws.write_string(1, col, f"{result.components[i].name} [{result.unit(phase, i)}]", fmt["header"])
            ws.write_column(2, col, data[k, :, i])
            ws.set_column(col, col, 13)
            col += 1
    ws.freeze_panes(2, 1)
    ws.write_string(len(result.z) + 3, 0, f"{PHASE_NAMES[phase].capitalize()} concentration along the column at "
                                          f"{len(idx)} evenly spaced output times (the first and last included).",
                    fmt["note"])


def _flatten(node, path=""):
    if isinstance(node, dict):
        for k, v in node.items():
            yield from _flatten(v, f"{path}.{k}" if path else str(k))
    elif isinstance(node, (list, tuple)):
        for i, v in enumerate(node):
            yield from _flatten(v, f"{path}[{i}]")
    else:
        yield path, node


def _input_sheet(wb, fmt, spec):
    ws = wb.add_worksheet(INPUTS)
    ws.set_column(0, 0, 58)
    ws.set_column(1, 1, 26)
    ws.write_string(0, 0, "parameter", fmt["header"])
    ws.write_string(0, 1, "value", fmt["header"])
    for r, (path, value) in enumerate(_flatten(spec_to_dict(spec)), start=1):
        ws.write_string(r, 0, path)
        _write(ws, r, 1, value)
    ws.freeze_panes(1, 0)


# --- entry point ---------------------------------------------------------------------------------------

def build_workbook(result, profile_times=21, include_profiles=False, created=None) -> bytes:
    """The workbook as bytes.

    ``include_profiles``: add the Profile sheets (concentrations along the column), ``profile_times`` output
    times each. ``created``: the creation time shown in the Summary (now by default).
    """
    created = created or datetime.datetime.now()
    buffer = io.BytesIO()
    wb = xlsxwriter.Workbook(buffer, {"in_memory": True, "nan_inf_to_errors": True})
    wb.set_properties({"title": result.spec.title or "Untitled simulation", "subject": "CADET GUI simulation",
                       "author": "CADET GUI", "created": created})
    fmt = _formats(wb)
    _summary_sheet(wb, fmt, result, created)
    index = _data_sheet(wb, fmt, result)
    _charts_sheet(wb, fmt, result, index)
    if include_profiles:
        for phase in result.phases():
            _profile_sheet(wb, fmt, result, phase, profile_times)
    _input_sheet(wb, fmt, result.spec)
    wb.close()
    return buffer.getvalue()
