"""Build a CADET-Process ``Process`` for a single-column batch run (spec §5).

All inputs are in GUI units (spec §4); conversion to SI happens here via
``core.units`` / ``Component`` factors only.

Column models (spec §5.1):
  "GRM"       -> GeneralRateModel
  "LRMP"      -> LumpedRateModelWithPores
  "LRM_keff"  -> LumpedRateModelWithPores with kf = keff, rapid-equilibrium binding
  "LRM"       -> LumpedRateModelWithoutPores (mass transfer lumped into ka/kd)

Binding models: "None", "Linear", "Langmuir" (competitive, multicomponent), "AntiLangmuir",
"BiLangmuir" (two independent site types), "Freundlich" (driving-force form), "SMA" (steric mass action,
component 0 = salt) and "GIEX" (generalized ion exchange, component 0 = salt, component 1 = pH, spec §5.4).
Mobile-phase mass-action reactions apply in bulk and pore liquid (spec §5.5).
Extra-column volume (spec §5.6): Inlet -> CSTR(V/2) -> Column -> CSTR(V/2) -> Outlet.
"""
import math
from dataclasses import asdict, dataclass, field

import numpy as np
from CADETProcess.processModel import (
    AntiLangmuir, BiLangmuir, ComponentSystem, Cstr, FlowSheet, FreundlichLDF, GeneralizedIonExchange,
    GeneralRateModel, Inlet, Langmuir, Linear, LumpedRateModelWithoutPores, LumpedRateModelWithPores,
    MassActionLaw, MassActionLawParticle, NoBinding, Outlet, Process, StericMassAction,
)

from core import reactions as rx
from core import tolerances, units
from core.components import Component

COLUMN_MODELS = ("GRM", "LRMP", "LRM_keff", "LRM")
BINDING_MODELS = ("None", "Linear", "Langmuir", "AntiLangmuir", "BiLangmuir", "Freundlich", "SMA", "GIEX")
MODULATORS = {"SMA": 1, "GIEX": 2}      # components in front of the solutes: salt (SMA), salt and pH (GIEX)


def modulator_count(model):
    return MODULATORS.get(model, 0)

_MIN = units.time_factor("min")


@dataclass
class ColumnSpec:
    model: str = "GRM"
    length: float = 10.0               # L [cm]
    diameter: float = 1.0              # D [cm]
    eps_b: float = 0.37                # εb
    eps_p: float = 0.5                 # εp
    radius: float = 25.0               # R [µm]
    axial_dispersion: float = 1e-3     # Eb [cm²/min]
    film_diffusion: list | None = None  # kf (GRM, LRMP) or keff (LRM_keff) [cm/min], per component
    pore_diffusion: list | None = None  # Dp [cm²/min], per component (GRM)
    eps_t: float | None = None         # LRM only; default εb + (1 − εb)·εp
    resin_density: float | None = None  # [g/mL], for "g resin" solid units
    density_basis: str = "solid"        # "solid", "particle" or "bed"
    # Initial column state per component (fresh column). None or blank entries = 0.
    initial_liquid: list | None = None   # bulk and pore liquid, GUI liquid units
    initial_solid: list | None = None    # bound phase, GUI solid units (adsorbing components);
                                         # GIEX salt is set by electroneutrality, q_salt = Λ − Σ ν_j·q_j

    def total_porosity(self):
        if self.model == "LRM" and self.eps_t is not None:
            return self.eps_t
        return units.total_porosity(self.eps_b, self.eps_p)


@dataclass
class GiexSpec:
    """GIEX-specific inputs (spec §5.4). Per-component lists cover all components;
    entries for salt (0), pH (1) and non-adsorbing components are ignored.

    Binding (CADET GIEX), with x = pH − pH_ref:
      dq_i/dt = ka_i(x)·c_i·(q̄0/q_ref)^ν_i(x) − kd_i(x)·q_i·(c_0/c_ref)^ν_i(x)
      ka_i(x) = ka_i·exp(a1·x + a2·x² + a3·x³ + ka_salt·c_0 + ka_protein·c_i)   (kd_i alike)
      ν_i(x)  = ν_i + n1·x + n2·x² + n3·x³,     q̄0 = Λ − Σ_j (ν_j + σ_j)·q_j
    ν_i is the component charge. Rapid equilibrium uses K = ka/kd with the
    ``adsorption_ph`` coefficients applied to K.
    """
    capacity: float = 1.0                  # Λ
    capacity_unit: str = "meq/mL solid"    # solid unit; meq counted as monovalent equivalents
    reference_liquid: float = 1.0          # c_ref, in the salt's liquid unit
    reference_solid: float | None = None   # q_ref, in capacity_unit; None -> Λ
    ph_ref: float = 7.0
    steric_factor: list | None = None      # σ
    adsorption_ph: list | None = None      # per component [a1, a2, a3] for ka (or K)
    desorption_ph: list | None = None      # per component [d1, d2, d3] for kd (kinetic)
    charge_ph: list | None = None          # per component [n1, n2, n3] for ν
    adsorption_salt: list | None = None    # [1/salt liquid unit]
    desorption_salt: list | None = None
    adsorption_protein: list | None = None  # [1/own liquid unit]
    desorption_protein: list | None = None


@dataclass
class SecondSite:
    """Bi-Langmuir: the second binding-site type (same units as the first; sites do not interact)."""
    equilibrium: list | None = None      # K2
    capacity: list | None = None         # qmax2
    adsorption_rate: list | None = None  # ka2
    desorption_rate: list | None = None  # kd2


@dataclass
class BindingSpec:
    """Per-component lists; entries for non-adsorbing components are ignored.

    Units follow each component's liquid/solid unit (K = ka/kd):
      Linear       rapid-eq: K [solid/liquid]            kinetic: ka [solid/(liquid·min)], kd [1/min]
      Langmuir     rapid-eq: K [1/liquid], qmax [solid]   kinetic: ka [1/(liquid·min)], kd [1/min], qmax
      AntiLangmuir like Langmuir, plus ``sign`` p = ±1 per component
      BiLangmuir   like Langmuir for each of two sites (the first here, the second in ``site2``)
      Freundlich   q = K·c^(1/n): ``equilibrium`` = K [solid/liquid^(1/n)], ``exponent`` = n;
                   kinetic (driving force): dq/dt = k_LDF·(q* − q) with ``ldf_rate`` k_LDF [1/min]
      SMA / GIEX   like Linear, plus ``giex``
    """
    model: str = "None"
    kinetic: bool = False
    equilibrium: list | None = None      # K (rapid-eq); Freundlich: K_F
    adsorption_rate: list | None = None  # ka (kinetic)
    desorption_rate: list | None = None  # kd (kinetic)
    capacity: list | None = None         # qmax (Langmuir family)
    giex: GiexSpec | None = None         # SMA and GIEX
    exponent: list | None = None         # Freundlich n
    ldf_rate: list | None = None         # Freundlich k_LDF [1/min]
    sign: list | None = None             # Anti-Langmuir p (+1 / −1)
    site2: SecondSite | None = None      # Bi-Langmuir


@dataclass
class InletSegment:
    """Inlet concentration from ``start`` [min] until the next segment.

    ``coefficients[i] = [a0, a1, a2, a3]`` for component i:
    c_i(τ) = a0 + a1·τ + a2·τ² + a3·τ³ with τ = t − start [min], in the
    component's liquid unit. Covers step, linear and polynomial gradients.
    """
    start: float
    coefficients: list


def constant(start, concentrations):
    """Step to constant concentrations at ``start`` [min]."""
    return InletSegment(start, [[c, 0.0, 0.0, 0.0] for c in concentrations])


def linear_gradient(start, end, c_start, c_end):
    """Linear ramp from ``c_start`` at ``start`` to ``c_end`` at ``end`` [min]."""
    duration = end - start
    if duration <= 0:
        raise ValueError("Gradient end must be after its start")
    return InletSegment(start, [[a, (b - a) / duration, 0.0, 0.0] for a, b in zip(c_start, c_end)])


INLET_SHAPES = ("step", "linear")


def inlet_from_table(starts, shapes, concentrations):
    """Inlet segments from a table of breakpoints (GUI inlet table).

    Row i gives concentrations at ``starts[i]`` [min]. ``shapes[i]``:
      "step"   hold row i's concentrations until the next row
      "linear" ramp linearly to the next row's concentrations at its start
    The last row is always held to the end of the simulation.
    """
    if not len(starts) == len(shapes) == len(concentrations):
        raise ValueError("Inlet table rows are inconsistent")
    segments = []
    for i, (start, shape, c) in enumerate(zip(starts, shapes, concentrations)):
        if shape not in INLET_SHAPES:
            raise ValueError(f"Unknown inlet shape {shape!r}; expected one of {INLET_SHAPES}")
        if shape == "linear" and i + 1 < len(starts):
            segments.append(linear_gradient(start, starts[i + 1], c, concentrations[i + 1]))
        else:
            segments.append(constant(start, c))
    return segments


@dataclass
class Injection:
    """A pulse injection laid over the inlet program: from ``start`` for ``volume / Q`` the
    inlet carries the ``feed`` concentrations instead of the program's."""
    volume: float = 0.5               # injected volume [mL]
    start: float = 0.0                # injection start [min]
    feed: list | None = None          # per component, GUI liquid units


def _shift(coefficients, delta):
    """Coefficients of p(τ + delta) for p(τ) = a0 + a1·τ + a2·τ² + a3·τ³."""
    a = list(coefficients) + [0.0] * (4 - len(coefficients))
    return [a[0] + a[1] * delta + a[2] * delta ** 2 + a[3] * delta ** 3,
            a[1] + 2 * a[2] * delta + 3 * a[3] * delta ** 2, a[2] + 3 * a[3] * delta, a[3]]


@dataclass
class OperationSpec:
    flow_rate: float = 1.0                         # Q [mL/min]
    inlet: list = field(default_factory=list)      # InletSegment: the inlet / eluent program, first starts at 0
    dead_volume: float = 0.0                       # total extra-column volume [mL]; 0 = none
    injection: Injection | None = None             # optional pulse laid over ``inlet``

    def program(self):
        """The inlet program the column receives: ``inlet`` with the injection laid over it."""
        inj = self.injection
        if inj is None:
            return list(self.inlet)
        if not (inj.volume is not None and inj.volume > 0):
            raise ValueError("The injection volume must be positive")
        if inj.start is None or inj.start < 0:
            raise ValueError("The injection start cannot be negative")
        if not self.flow_rate > 0:
            raise ValueError("The flow rate must be positive")
        if not self.inlet:
            raise ValueError("Inlet needs at least one segment")
        t0, t1 = inj.start, inj.start + inj.volume / self.flow_rate
        ends = [seg.start for seg in self.inlet[1:]] + [math.inf]
        pieces = []
        for seg, end in zip(self.inlet, ends):
            if seg.start < t0:                                 # before the injection
                pieces.append(InletSegment(seg.start, [list(p) for p in seg.coefficients]))
            if end > t1:                                       # after the injection
                start = max(seg.start, t1)
                pieces.append(InletSegment(start, [_shift(p, start - seg.start) for p in seg.coefficients]))
        pieces.append(InletSegment(t0, [[float(c), 0.0, 0.0, 0.0] for c in (inj.feed or [])]))
        return sorted(pieces, key=lambda seg: seg.start)


@dataclass
class SimulationSettings:
    duration: float = 30.0          # total time [min]
    output_interval: float = 0.05   # [min]
    n_col: int = 100                # axial cells
    n_par: int = 5                  # particle (radial) cells, GRM only
    record_profiles: bool = True    # bulk/particle/solid for the column profile viewer
    timeout: float = 600.0          # max wall-clock time for the solver [s]
    # Solver tolerances: "auto" scales them to the concentrations (core.tolerances);
    # "manual" uses the values below.
    tolerance_mode: str = "auto"
    reltol: float = 1e-6
    abstol: float = 1e-8            # [mol/m³]
    algtol: float = 1e-12
    weno_eps: float = 1e-10


@dataclass
class CorrelationInputs:
    """Inputs used when mass-transfer parameters were estimated (spec §5.2 option B).

    Kept with the spec for reproducibility; the estimated values themselves are
    written into ``ColumnSpec`` (Eb, kf/keff), which is what the simulation uses.
    """
    viscosity: float = 0.89                 # μ [cP]
    density: float = 0.997                  # ρ [g/mL]
    molecular_diffusion: list | None = None  # Dm [cm²/min], per component
    keff_from_glueckauf: bool = False
    pore_diffusion: list | None = None       # Dp [cm²/min] for Glueckauf (kept so an input file is complete)
    molar_volume: list | None = None         # V_A [cm³/mol], Wilke & Chang helper for Dm
    temperature: float = 25.0                # [°C], Wilke & Chang helper


@dataclass
class BatchSpec:
    components: list
    column: ColumnSpec
    binding: BindingSpec
    operation: OperationSpec
    settings: SimulationSettings = field(default_factory=SimulationSettings)
    correlation: CorrelationInputs | None = None   # None: mass transfer entered directly
    reactions: rx.ReactionSystem | None = None
    initial_state_source: str | None = None        # label of a loaded column state, for logs
    title: str = ""                                # the user's name for this simulation (file names, reports)


def spec_to_dict(spec: BatchSpec) -> dict:
    """JSON-serialisable form of a spec (for result files and logs)."""
    return asdict(spec)


def spec_from_dict(d: dict) -> BatchSpec:
    op = d["operation"]
    return BatchSpec(
        components=[Component(**c) for c in d["components"]],
        column=ColumnSpec(**d["column"]),
        binding=BindingSpec(**{**d["binding"],
                               "giex": GiexSpec(**d["binding"]["giex"]) if d["binding"].get("giex") else None,
                               "site2": SecondSite(**d["binding"]["site2"]) if d["binding"].get("site2") else None}),
        operation=OperationSpec(flow_rate=op["flow_rate"], inlet=[InletSegment(**s) for s in op["inlet"]],
                                dead_volume=op.get("dead_volume", 0.0),
                                injection=Injection(**op["injection"]) if op.get("injection") else None),
        settings=SimulationSettings(**d["settings"]),
        correlation=CorrelationInputs(**d["correlation"]) if d.get("correlation") else None,
        reactions=rx.ReactionSystem(basis=d["reactions"]["basis"],
                                    reactions=[rx.ReactionSpec.from_dict(r) for r in d["reactions"]["reactions"]])
        if d.get("reactions") else None,
        initial_state_source=d.get("initial_state_source"),
        title=d.get("title", ""),
    )


def _is_missing(v):
    return v is None or v != v


def _require_values(values, comps, name, hint, mask=None):
    """Raise if a value is empty for a component in ``mask`` (default: all components).

    An empty value would become NaN in the CADET input, and CADET then runs forever
    without reporting an error.
    """
    for i, (v, comp) in enumerate(zip(values, comps)):
        if (mask is None or mask[i]) and _is_missing(v):
            raise ValueError(f"{name} is empty for component {comp.name!r}; {hint}")
    return values


def _per_component(values, n, name, required=True):
    if values is None:
        if required:
            raise ValueError(f"{name} is required (one value per component)")
        return None
    if len(values) != n:
        raise ValueError(f"{name} needs {n} values (one per component), got {len(values)}")
    return list(values)


def recenter_polynomial(coeffs, x0):
    """Rewrite a1·(x−x0) + a2·(x−x0)² + a3·(x−x0)³ as b0 + b1·x + b2·x² + b3·x³."""
    a1, a2, a3 = (list(coeffs) + [0.0, 0.0, 0.0])[:3]
    return (-a1 * x0 + a2 * x0 ** 2 - a3 * x0 ** 3,
            a1 - 2 * a2 * x0 + 3 * a3 * x0 ** 2,
            a2 - 3 * a3 * x0,
            a3)


def _check_modulators(model, comps):
    """The salt (and pH) components that SMA / GIEX need in front of the solutes."""
    n_mod = modulator_count(model)
    if len(comps) < n_mod + 1:
        raise ValueError(f"{model} needs " + ("salt, pH" if n_mod == 2 else "salt")
                         + " and at least one adsorbing solute")
    if not comps[0].bound:
        raise ValueError(f"{model}: component 1 is the salt counter-ion and must be marked as adsorbing")
    if n_mod == 2 and (comps[1].bound or comps[1].liquid_unit != units.MODULATOR_UNIT):
        raise ValueError(f"{model}: component 2 is the pH modulator (unit 'pH', not adsorbing)")
    for c in comps[n_mod:]:
        if c.bound and not c.charge:
            raise ValueError(f"{model}: adsorbing component {c.name!r} needs its charge ν")


def _converter(comps, active, f_l, f_s):
    """``convert(values, name, liquid_exp, solid_exp, time_exp, fill)``: GUI isotherm constants -> SI.

    Entries of components that do not use the isotherm get ``fill``; an empty entry of an adsorbing
    component is an error (it would become NaN, and CADET then runs forever without a message).
    """
    n = len(comps)

    def convert(values, name, liquid_exp, solid_exp, time_exp, fill):
        values = _per_component(values, n, name)
        _require_values(values, comps, name, "enter it in the Binding table, or untick 'adsorbs' for "
                        "components that do not bind", mask=active)
        return [
            float(units.isotherm_param_to_si(v, f_liquid=f_l[i], f_solid=f_s[i], f_time=_MIN,
                                             liquid_exp=liquid_exp, solid_exp=solid_exp, time_exp=time_exp))
            if active[i] else fill
            for i, v in enumerate(values)
        ]

    return convert


def _build_binding(spec: BatchSpec, component_system):
    comps, col, b = spec.components, spec.column, spec.binding
    n = len(comps)
    if b.model not in BINDING_MODELS:
        raise ValueError(f"Unknown binding model {b.model!r}; expected one of {BINDING_MODELS}")
    if col.model == "LRM_keff" and b.kinetic:
        raise ValueError("LRM (keff) requires rapid-equilibrium binding (kinetics are in keff)")
    if b.model == "None":
        return NoBinding()
    n_mod = modulator_count(b.model)
    if n_mod:
        _check_modulators(b.model, comps)

    eps_t = col.total_porosity()
    bed = dict(eps_t=eps_t, eps_p=col.eps_p, density=col.resin_density, density_basis=col.density_basis)
    f_l = [c.liquid_factor() for c in comps]
    f_s = [c.solid_factor(**bed) if c.bound else 1.0 for c in comps]
    bound = [c.bound for c in comps]
    # Components whose isotherm parameters are used (SMA / GIEX: not salt and pH).
    active = [c.bound and i >= n_mod for i, c in enumerate(comps)]
    if not any(active):
        raise ValueError(f"{b.model} binding selected but no component adsorbs")
    convert = _converter(comps, active, f_l, f_s)

    if b.model == "Freundlich":
        return _build_freundlich(spec, component_system, active, f_l, f_s, convert)
    if b.model == "BiLangmuir":
        return _build_bilangmuir(spec, component_system, convert)

    # Dimension exponents [liquid, solid] of K and ka for each isotherm.
    k_dims = {"Linear": (-1, 1), "Langmuir": (-1, 0), "AntiLangmuir": (-1, 0), "SMA": (-1, 1),
              "GIEX": (-1, 1)}[b.model]
    if b.kinetic:
        ka = convert(b.adsorption_rate, "ka", *k_dims, -1, fill=0.0)
        kd = convert(b.desorption_rate, "kd", 0, 0, -1, fill=1.0)
    else:
        # Rapid equilibrium: CADET only uses the ratio ka/kd.
        ka = convert(b.equilibrium, "K", *k_dims, 0, fill=0.0)
        kd = [1.0] * n
    if n_mod:
        return _build_ion_exchange(spec, component_system, ka, kd, active, f_l, bed)

    model = {"Linear": Linear, "Langmuir": Langmuir, "AntiLangmuir": AntiLangmuir}[b.model](
        component_system, name=b.model.lower())
    model.bound_states = [1 if c else 0 for c in bound]
    model.is_kinetic = b.kinetic
    model.adsorption_rate = ka
    model.desorption_rate = kd
    if b.model == "Langmuir":
        model.capacity = convert(b.capacity, "qmax", 0, 1, 0, fill=0.0)
    if b.model == "AntiLangmuir":
        model.capacity = convert(b.capacity, "qmax", 0, 1, 0, fill=1.0)
        signs = _per_component(b.sign, n, "p", required=False) or [1.0] * n
        signs = [float(v) if active[i] and v is not None else 1.0 for i, v in enumerate(signs)]
        for i, v in enumerate(signs):
            if active[i] and v not in (1.0, -1.0):
                raise ValueError(f"Anti-Langmuir: p must be +1 (Langmuir) or −1 (anti-Langmuir) for component "
                                 f"{comps[i].name!r}, got {v:g}")
        model.antilangmuir = signs
    return model


def _build_freundlich(spec, component_system, active, f_l, f_s, convert):
    """q* = K·c^(1/n) per component (no interaction); kinetic: dq/dt = k_LDF·(q* − q)."""
    comps, b = spec.components, spec.binding
    n = len(comps)
    exponents = _per_component(b.exponent, n, "n")
    _require_values(exponents, comps, "n", "enter the Freundlich exponent in the Binding table", mask=active)
    for i, v in enumerate(exponents):
        if active[i] and not v > 0:
            raise ValueError(f"Freundlich: the exponent n must be positive for component {comps[i].name!r}")
    kf = _per_component(b.equilibrium, n, "K_F")
    _require_values(kf, comps, "K_F", "enter it in the Binding table, or untick 'adsorbs'", mask=active)
    # q [solid] = K·c^(1/n)  ->  K_SI = K·f_solid·f_liquid^(−1/n)
    k_si = [float(units.isotherm_param_to_si(kf[i], f_liquid=f_l[i], f_solid=f_s[i], liquid_exp=-1.0 / exponents[i],
                                             solid_exp=1)) if active[i] else 0.0 for i in range(n)]
    ldf = convert(b.ldf_rate, "k_LDF", 0, 0, -1, fill=1.0) if b.kinetic else [1.0] * n
    model = FreundlichLDF(component_system, name="freundlich")
    model.bound_states = [1 if c.bound else 0 for c in comps]
    model.is_kinetic = b.kinetic
    model.freundlich_coefficient = k_si
    model.exponent = [float(v) if active[i] else 1.0 for i, v in enumerate(exponents)]
    model.driving_force_coefficient = ldf
    return model


def _build_bilangmuir(spec, component_system, convert):
    """Two independent Langmuir site types; every component gets both sites (inert ones: ka = 0)."""
    comps, b = spec.components, spec.binding
    s2 = b.site2
    if s2 is None:
        raise ValueError("Bi-Langmuir needs the parameters of the second site (K2, qmax2, ...)")
    n = len(comps)

    def site(equilibrium, capacity, adsorption, desorption, tag):
        if b.kinetic:
            ka = convert(adsorption, f"ka{tag}", -1, 0, -1, fill=0.0)
            kd = convert(desorption, f"kd{tag}", 0, 0, -1, fill=1.0)
        else:
            ka = convert(equilibrium, f"K{tag}", -1, 0, 0, fill=0.0)
            kd = [1.0] * n
        return ka, kd, convert(capacity, f"qmax{tag}", 0, 1, 0, fill=1.0)

    ka1, kd1, q1 = site(b.equilibrium, b.capacity, b.adsorption_rate, b.desorption_rate, "")
    ka2, kd2, q2 = site(s2.equilibrium, s2.capacity, s2.adsorption_rate, s2.desorption_rate, "2")
    model = BiLangmuir(component_system, name="bilangmuir", n_binding_sites=2)
    model.is_kinetic = b.kinetic
    # CADET orders the parameters site by site: [comp 0..n-1 of site 1, comp 0..n-1 of site 2]
    model.adsorption_rate = ka1 + ka2
    model.desorption_rate = kd1 + kd2
    model.capacity = q1 + q2
    return model


def _build_ion_exchange(spec, component_system, ka, kd, active, f_l, bed):
    """SMA (salt in front of the solutes) or GIEX (salt and pH)."""
    comps, b, g = spec.components, spec.binding, spec.binding.giex
    giex = b.model == "GIEX"
    n_mod = modulator_count(b.model)
    if g is None:
        raise ValueError(f"{b.model} selected but its parameters (Λ, references"
                         + (", pH_ref" if giex else "") + ") are missing")
    n = len(comps)

    def per_comp(values, name, default):
        values = _per_component(values, n, name, required=False) or [default] * n
        return [v if active[i] and v is not None else default for i, v in enumerate(values)]

    f_cap = units.solid_factor(g.capacity_unit, charge=1, **bed)
    f_salt = f_l[0]
    if not giex:
        model = StericMassAction(component_system, name="sma")
        model.bound_states = [1 if c.bound else 0 for c in comps]
        model.is_kinetic = b.kinetic
        model.adsorption_rate = [ka[i] if active[i] else 0.0 for i in range(n)]
        model.desorption_rate = [kd[i] if active[i] else 1.0 for i in range(n)]
        model.characteristic_charge = [abs(c.charge) if active[i] else 0.0 for i, c in enumerate(comps)]
        model.steric_factor = [float(v) for v in per_comp(g.steric_factor, "σ", 0.0)]
        model.capacity = g.capacity * f_cap
        model.reference_liquid_phase_conc = g.reference_liquid * f_salt
        model.reference_solid_phase_conc = (g.capacity if g.reference_solid is None else g.reference_solid) * f_cap
        return model

    zeros3 = [0.0, 0.0, 0.0]
    a_ph = [recenter_polynomial(c, g.ph_ref) for c in per_comp(g.adsorption_ph, "ka pH coefficients", zeros3)]
    d_ph = [recenter_polynomial(c, g.ph_ref) for c in per_comp(g.desorption_ph, "kd pH coefficients", zeros3)] \
        if b.kinetic else [(0.0,) * 4] * n
    n_ph = [recenter_polynomial(c, g.ph_ref) for c in per_comp(g.charge_ph, "ν pH coefficients", zeros3)]

    model = GeneralizedIonExchange(component_system, name="giex")
    model.bound_states = [1, 0] + [1 if c.bound else 0 for c in comps[2:]]
    model.is_kinetic = b.kinetic
    # Constant terms of the re-centred pH polynomials fold into the base values.
    model.adsorption_rate = [ka[i] * np.exp(a_ph[i][0]) if active[i] else 0.0 for i in range(n)]
    model.desorption_rate = [kd[i] * np.exp(d_ph[i][0]) if active[i] else 1.0 for i in range(n)]
    model.adsorption_rate_linear = [p[1] for p in a_ph]
    model.adsorption_rate_quadratic = [p[2] for p in a_ph]
    model.adsorption_rate_cubic = [p[3] for p in a_ph]
    model.desorption_rate_linear = [p[1] for p in d_ph]
    model.desorption_rate_quadratic = [p[2] for p in d_ph]
    model.desorption_rate_cubic = [p[3] for p in d_ph]
    model.characteristic_charge = [abs(c.charge) + n_ph[i][0] if active[i] else 0.0
                                   for i, c in enumerate(comps)]
    model.characteristic_charge_linear = [p[1] for p in n_ph]
    model.characteristic_charge_quadratic = [p[2] for p in n_ph]
    model.characteristic_charge_cubic = [p[3] for p in n_ph]
    model.steric_factor = [float(v) for v in per_comp(g.steric_factor, "σ", 0.0)]
    # Salt / protein exponent coefficients: [1/liquid] -> divide by the liquid factor.
    model.adsorption_rate_salt = [v / f_salt for v in per_comp(g.adsorption_salt, "ka salt", 0.0)]
    model.desorption_rate_salt = [v / f_salt for v in per_comp(g.desorption_salt, "kd salt", 0.0)]
    model.adsorption_rate_protein = [v / f_l[i] for i, v in
                                     enumerate(per_comp(g.adsorption_protein, "ka protein", 0.0))]
    model.desorption_rate_protein = [v / f_l[i] for i, v in
                                     enumerate(per_comp(g.desorption_protein, "kd protein", 0.0))]
    model.capacity = g.capacity * f_cap
    model.reference_liquid_phase_conc = g.reference_liquid * f_salt
    model.reference_solid_phase_conc = (g.capacity if g.reference_solid is None else g.reference_solid) * f_cap
    return model


def _build_column(spec: BatchSpec, component_system):
    col, s = spec.column, spec.settings
    n = len(spec.components)
    if col.model not in COLUMN_MODELS:
        raise ValueError(f"Unknown column model {col.model!r}; expected one of {COLUMN_MODELS}")

    if col.model == "LRM":
        unit = LumpedRateModelWithoutPores(component_system, name="column")
        unit.total_porosity = col.total_porosity()
    else:
        cls = GeneralRateModel if col.model == "GRM" else LumpedRateModelWithPores
        unit = cls(component_system, name="column")
        unit.bed_porosity = col.eps_b
        unit.particle_porosity = col.eps_p
        unit.particle_radius = float(units.radius_to_si(col.radius))
        kf_name = "keff" if col.model == "LRM_keff" else "kf"
        hint = "enter it in the Mass transfer table (every component, also salt and pH, needs a value)"
        film = _require_values(_per_component(col.film_diffusion, n, kf_name), spec.components, kf_name, hint)
        unit.film_diffusion = list(units.velocity_to_si(film))
        if col.model == "GRM":
            pore = _require_values(_per_component(col.pore_diffusion, n, "Dp"), spec.components, "Dp", hint)
            unit.pore_diffusion = list(units.diffusivity_to_si(pore))
            unit.discretization.npar = s.n_par

    unit.length = float(units.length_to_si(col.length))
    unit.diameter = float(units.length_to_si(col.diameter))
    unit.axial_dispersion = float(units.diffusivity_to_si(col.axial_dispersion))
    unit.discretization.ncol = s.n_col
    weno = getattr(unit.discretization, "weno_parameters", None)
    if weno is not None:
        weno.weno_eps = tolerances.effective_tolerances(spec).weno_eps
    unit.binding_model = _build_binding(spec, component_system)
    _build_reactions(unit, spec, component_system)
    _set_initial_state(unit, spec)

    if s.record_profiles:
        rec = unit.solution_recorder
        rec.write_solution_bulk = True
        rec.write_solution_solid = True
        if col.model != "LRM":
            rec.write_solution_particle = True
    return unit


def _build_reactions(unit, spec: BatchSpec, component_system):
    system = spec.reactions
    if system is None or not system.reactions:
        return
    names = [c.name for c in spec.components]
    modulators = {c.name for c in spec.components if c.liquid_unit == units.MODULATOR_UNIT}
    bulk = MassActionLaw(component_system, name="bulk_reactions")
    particle = MassActionLawParticle(component_system, name="pore_reactions")
    for reaction in system.reactions:
        reactants, products = rx.parse_equation(reaction.equation, names)
        if modulators & (set(reactants) | set(products)):
            raise ValueError(f"Reaction {reaction.equation!r}: the pH modulator cannot take part in reactions")
        n_fwd, n_bwd = rx.orders(reactants, products)
        k_fwd, k_bwd = rx.rates(reaction)
        species = list(reactants) + list(products)
        coefficients = [-reactants[n] for n in reactants] + [products[n] for n in products]
        kwargs = dict(k_fwd=rx.rate_to_si(k_fwd, n_fwd, system.basis),
                      k_bwd=rx.rate_to_si(k_bwd, n_bwd, system.basis), is_kinetic=True)
        bulk.add_reaction(species, coefficients, **kwargs)
        particle.add_liquid_reaction(species, coefficients, **kwargs)
    # LRM (no pores) has a single liquid phase, carried by its particle reaction model.
    if unit.supports_bulk_reaction:
        unit.bulk_reaction_model = bulk
    unit.particle_reaction_model = particle


def _initial_values(values, n, name):
    if values is None:
        return [0.0] * n
    return [0.0 if v is None or v != v else float(v) for v in _per_component(values, n, name)]


def _initial_liquid(spec: BatchSpec):
    """Initial liquid concentrations in GUI units (``ColumnSpec.initial_liquid``, default 0)."""
    init = _initial_values(spec.column.initial_liquid, len(spec.components), "Initial liquid concentration")
    model = spec.binding.model
    n_mod = modulator_count(model)
    if n_mod >= 1 and init[0] <= 0:
        raise ValueError(f"{model}: set the initial salt concentration (Initial state section); the column must "
                         "start equilibrated with a salt-containing buffer")
    if n_mod == 2 and init[1] <= 0:
        raise ValueError("GIEX: set the initial pH (Initial state section)")
    return init


def _set_initial_state(unit, spec: BatchSpec):
    comps, col = spec.components, spec.column
    liquid = _initial_liquid(spec)
    c = [v * comp.liquid_factor() for v, comp in zip(liquid, comps)]
    unit.c = c
    if col.model != "LRM":
        unit.cp = c
    binding = unit.binding_model
    model = spec.binding.model
    if model == "None" or binding.n_bound_states == 0:
        return
    solid = _initial_values(col.initial_solid, len(comps), "Initial solid concentration")
    if model == "BiLangmuir":
        if any(solid):
            raise ValueError("An initial bound amount q₀ is not available for Bi-Langmuir (the amount on each "
                             "site is unknown); leave q₀ at 0")
        return
    bed = dict(eps_t=col.total_porosity(), eps_p=col.eps_p, density=col.resin_density,
               density_basis=col.density_basis)
    q_si = [v * comp.solid_factor(**bed) if comp.bound else 0.0 for v, comp in zip(solid, comps)]
    n_mod = modulator_count(model)
    if n_mod:
        # Salt holds the sites not taken by the solutes (GIEX: ν evaluated at the initial pH).
        ph = liquid[1] if n_mod == 2 else 0.0
        nu = [binding.characteristic_charge[i] + (
            binding.characteristic_charge_linear[i] * ph + binding.characteristic_charge_quadratic[i] * ph ** 2
            + binding.characteristic_charge_cubic[i] * ph ** 3 if n_mod == 2 else 0.0) for i in range(len(comps))]
        taken = sum(nu[i] * q_si[i] for i in range(n_mod, len(comps)) if comps[i].bound)
        q_salt = binding.capacity - taken
        if q_salt < 0:
            raise ValueError(f"{model}: the initial bound amounts exceed the capacity Λ")
        unit.q = [q_salt] + [q_si[i] for i in range(n_mod, len(comps)) if comps[i].bound]
    else:
        unit.q = [q for q, comp in zip(q_si, comps) if comp.bound]


def _inlet_events(process, spec: BatchSpec):
    comps = spec.components
    inj = spec.operation.injection
    if inj is not None and (inj.feed is None or len(inj.feed) != len(comps)):
        raise ValueError(f"The injection needs one feed concentration per component ({len(comps)}), "
                         f"got {0 if inj.feed is None else len(inj.feed)}")
    segments = spec.operation.program()
    if not segments:
        raise ValueError("Inlet needs at least one segment")
    starts = [seg.start for seg in segments]
    if starts[0] != 0:
        raise ValueError("First inlet segment must start at t = 0")
    if any(b <= a for a, b in zip(starts, starts[1:])):
        raise ValueError("Inlet segment start times must be strictly increasing")
    if starts[-1] >= spec.settings.duration:
        raise ValueError("Inlet segments must start before the end of the simulation")

    n = len(comps)
    for k, seg in enumerate(segments):
        coeffs = _per_component(seg.coefficients, n, f"Inlet segment {k} coefficients")
        si = []
        for comp, poly in zip(comps, coeffs):
            poly = list(poly) + [0.0] * (4 - len(poly))
            if len(poly) != 4:
                raise ValueError("Inlet polynomials have at most 4 coefficients (cubic)")
            f = comp.liquid_factor()
            # a_k [liquid/min^k] -> [mol/m³ / s^k]
            si.append([a * f / _MIN ** p for p, a in enumerate(poly)])
        process.add_event(f"inlet_{k}", "flow_sheet.inlet.c", si, float(units.time_to_si(seg.start)))


def state_structure(spec: BatchSpec) -> dict:
    """What a saved CADET state vector depends on; two specs with equal structure can
    exchange states (sequential runs)."""
    col, b = spec.column, spec.binding
    return {
        "column_model": col.model,
        "n_col": spec.settings.n_col,
        "n_par": spec.settings.n_par if col.model == "GRM" else None,
        "components": [c.name for c in spec.components],
        "bound": [bool(c.bound) and b.model != "None" for c in spec.components],
        "binding_model": b.model,
        "binding_kinetic": bool(b.kinetic) if b.model != "None" else None,
        "extra_column_volume": bool(spec.operation.dead_volume and spec.operation.dead_volume > 0),
    }


def build_process(spec: BatchSpec, initial_state=None) -> Process:
    """Translate a GUI-unit ``BatchSpec`` into a CADET-Process ``Process``.

    ``initial_state``: optional ``(state, state_derivative)`` arrays from an earlier
    run with the same ``state_structure`` (overrides the initial liquid/solid values).
    """
    if not spec.components:
        raise ValueError("Define at least one component")
    names = [c.name for c in spec.components]
    if len(set(names)) != len(names):
        raise ValueError("Component names must be unique")

    cs = ComponentSystem(names)
    flow = float(units.flow_to_si(spec.operation.flow_rate))
    inlet = Inlet(cs, name="inlet")
    inlet.flow_rate = flow
    column = _build_column(spec, cs)
    outlet = Outlet(cs, name="outlet")

    dead_volume = spec.operation.dead_volume or 0.0
    if dead_volume < 0:
        raise ValueError("Dead volume cannot be negative")
    chain = [inlet, column, outlet]
    if dead_volume > 0:
        c0 = [v * comp.liquid_factor() for v, comp in zip(_initial_liquid(spec), spec.components)]
        tanks = []
        for name in ("ecv_inlet", "ecv_outlet"):
            tank = Cstr(cs, name=name)
            tank.init_liquid_volume = float(units.volume_to_si(dead_volume / 2))
            tank.flow_rate = flow
            tank.c = c0
            tanks.append(tank)
        chain = [inlet, tanks[0], column, tanks[1], outlet]

    fs = FlowSheet(cs)
    for unit in chain:
        fs.add_unit(unit)
    for upstream, downstream in zip(chain, chain[1:]):
        fs.add_connection(upstream, downstream)

    process = Process(fs, "batch")
    process.cycle_time = float(units.time_to_si(spec.settings.duration))
    _inlet_events(process, spec)
    if initial_state is not None:
        process.system_state, process.system_state_derivative = (np.asarray(a, dtype=float)
                                                                 for a in initial_state)
    return process
