"""MP4 / GIF export of the column-profile animation (spec §6 결과 뷰어 💾 GIF/MP4).

Frames are drawn with matplotlib (Agg, no display) and encoded with the ffmpeg
binary shipped by ``imageio-ffmpeg`` (MP4, H.264) or Pillow (GIF).
"""
import io

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

PHASE_TITLES = {"bulk": "Bulk liquid", "pore": "Pore liquid", "solid": "Solid (bound)"}
VIDEO_FORMATS = ("mp4", "gif")
_SIZE_PX = (960, 540)    # even dimensions, required by H.264 / yuv420p
_DPI = 120


def frame_indices(n_times, max_frames):
    return np.unique(np.round(np.linspace(0, n_times - 1, min(n_times, max_frames))).astype(int))


def _frames(result, phase, components, colors, max_frames, fixed_y):
    data = getattr(result, phase)
    comps = [i for i in components if not np.all(np.isnan(data[:, :, i]))]
    if not comps:
        raise ValueError(f"No component has {phase} values to animate")
    fig, ax = plt.subplots(figsize=(_SIZE_PX[0] / _DPI, _SIZE_PX[1] / _DPI), dpi=_DPI)
    lines = [ax.plot(result.z, data[0, :, i], lw=2, color=colors[i % len(colors)],
                     label=f"{result.components[i].name} [{result.unit(phase, i)}]")[0] for i in comps]
    ax.set_xlim(0, result.spec.column.length)
    ax.set_xlabel("Axial position z [cm]")
    unit_set = {result.unit(phase, i) for i in comps}
    ax.set_ylabel(f"{PHASE_TITLES[phase]} concentration" + (f" [{unit_set.pop()}]" if len(unit_set) == 1 else ""))
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right", frameon=False)
    y_max = float(np.nanmax(data[:, :, comps]))
    title = ax.set_title("")
    try:
        for k in frame_indices(len(result.time), max_frames):
            for line, i in zip(lines, comps):
                line.set_ydata(data[k, :, i])
            if fixed_y:
                ax.set_ylim(0, 1.05 * y_max if y_max > 0 else 1.0)
            else:
                ax.relim()
                ax.autoscale_view(scalex=False)
            title.set_text(f"t = {result.time[k]:.4g} min")
            fig.canvas.draw()
            yield np.asarray(fig.canvas.buffer_rgba())[:, :, :3].copy()
    finally:
        plt.close(fig)


def profile_video(result, phase, components, colors, fmt="mp4", fps=10, max_frames=200, fixed_y=True):
    """Encode the axial profile of ``phase`` over time; returns the file bytes."""
    if fmt not in VIDEO_FORMATS:
        raise ValueError(f"Unknown video format {fmt!r}; expected one of {VIDEO_FORMATS}")
    return encode(_frames(result, phase, list(components), colors, max_frames, fixed_y), fmt, fps)


def encode(frames, fmt="mp4", fps=10, size=_SIZE_PX):
    """MP4 (H.264) or GIF bytes from an iterable of RGB frames of ``size`` pixels."""
    if fmt not in VIDEO_FORMATS:
        raise ValueError(f"Unknown video format {fmt!r}; expected one of {VIDEO_FORMATS}")
    if fmt == "gif":
        from PIL import Image
        images = [Image.fromarray(f) for f in frames]
        buffer = io.BytesIO()
        images[0].save(buffer, format="GIF", save_all=True, append_images=images[1:],
                       duration=int(1000 / fps), loop=0)
        return buffer.getvalue()

    import os
    import tempfile

    import imageio_ffmpeg
    fd, path = tempfile.mkstemp(suffix=".mp4", prefix="cadet_gui_")
    os.close(fd)
    try:
        writer = imageio_ffmpeg.write_frames(path, size, fps=fps, codec="libx264", pix_fmt_out="yuv420p",
                                             macro_block_size=1, quality=7)
        writer.send(None)                       # start the generator
        for frame in frames:
            writer.send(np.ascontiguousarray(frame))
        writer.close()
        with open(path, "rb") as f:
            return f.read()
    finally:
        os.remove(path)
