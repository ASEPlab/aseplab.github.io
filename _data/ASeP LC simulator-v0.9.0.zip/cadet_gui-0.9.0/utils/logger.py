"""Automatic run logs: ``logs/YYYYMMDD_HHMMSS_simulation.json`` (spec §7).

Each log holds the full input in GUI units, the outcome, per-component amounts
and dimensionless groups, so a run can be audited or rebuilt later
(``core.model_builder.spec_from_dict(log["input"])``).
"""
import json
from datetime import datetime
from pathlib import Path

import numpy as np

from core import dimensionless, mass, tolerances
from core.model_builder import spec_to_dict


def _jsonable(value):
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def build_log(spec, result=None, error=None, status=None, timestamp=None):
    timestamp = timestamp or datetime.now()
    log = {
        "timestamp": timestamp.isoformat(timespec="seconds"),
        "status": status or ("done" if result is not None else "failed"),
        "error": error,
        "input": spec_to_dict(spec),
    }
    try:
        log["solver_tolerances"] = tolerances.effective_tolerances(spec).as_dict()
        log["dimensionless"] = dimensionless.groups(spec.column, spec.operation.flow_rate, len(spec.components))
        log["reaction_numbers"] = dimensionless.reaction_groups(spec)
    except (ValueError, TypeError) as e:
        log["dimensionless_error"] = str(e)
    if result is not None:
        log["summary"] = result.summary
        log["amounts"] = mass.mass_table(result).reset_index().to_dict(orient="records")
        log["numerical_checks"] = mass.numerical_checks(result).reset_index().to_dict(orient="records")
    return _jsonable(log)


def write_log(logs_dir, spec, result=None, error=None, status=None, timestamp=None):
    """Write the log file and return its path."""
    timestamp = timestamp or datetime.now()
    logs_dir = Path(logs_dir)
    logs_dir.mkdir(parents=True, exist_ok=True)
    stem = timestamp.strftime("%Y%m%d_%H%M%S")
    path = logs_dir / f"{stem}_simulation.json"
    k = 1
    while path.exists():                      # two runs within the same second
        path = logs_dir / f"{stem}_{k}_simulation.json"
        k += 1
    path.write_text(json.dumps(build_log(spec, result, error, status, timestamp), indent=2, ensure_ascii=False))
    return path


def build_smb_log(spec, result=None, error=None, status=None, timestamp=None):
    from core import smb, smb_results
    timestamp = timestamp or datetime.now()
    log = {
        "timestamp": timestamp.isoformat(timespec="seconds"),
        "kind": "smb",
        "status": status or ("done" if result is not None else "failed"),
        "error": error,
        "input": smb.spec_to_dict(spec),
    }
    try:
        log["solver_tolerances"] = tolerances.effective_tolerances(spec.base).as_dict()
        log["flows"] = smb.flow_set(spec).table() | {"m": list(smb.flow_set(spec).m)}
    except (ValueError, TypeError) as e:
        log["flows_error"] = str(e)
    if result is not None:
        log["summary"] = result.summary
        try:
            log["performance"] = smb_results.performance(result)
            log["cycles"] = smb_results.cycle_table(result).reset_index().to_dict(orient="records")
        except (ValueError, KeyError, IndexError) as e:
            log["performance_error"] = str(e)
    return _jsonable(log)


def write_smb_log(logs_dir, spec, result=None, error=None, status=None, timestamp=None):
    """``logs/YYYYMMDD_HHMMSS_smb.json``; returns its path."""
    timestamp = timestamp or datetime.now()
    logs_dir = Path(logs_dir)
    logs_dir.mkdir(parents=True, exist_ok=True)
    stem = timestamp.strftime("%Y%m%d_%H%M%S")
    path = logs_dir / f"{stem}_smb.json"
    k = 1
    while path.exists():
        path = logs_dir / f"{stem}_{k}_smb.json"
        k += 1
    path.write_text(json.dumps(build_smb_log(spec, result, error, status, timestamp), indent=2, ensure_ascii=False))
    return path
