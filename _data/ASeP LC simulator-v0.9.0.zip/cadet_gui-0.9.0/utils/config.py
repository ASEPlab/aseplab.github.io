"""App settings from ``config.yaml`` (spec §1: log/result paths are configurable)."""
import os
from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
CONFIG_FILE = ROOT / "config.yaml"
ENV_VAR = "CADET_GUI_CONFIG"   # optional override of the config file path


@dataclass
class Config:
    logs_dir: Path
    results_dir: Path
    auto_save_results: bool = False


def load_config(path=None) -> Config:
    path = Path(path or os.environ.get(ENV_VAR) or CONFIG_FILE)
    data = yaml.safe_load(path.read_text()) if path.exists() else {}
    data = data or {}

    def resolve(value, default):
        p = Path(value or default).expanduser()
        return p if p.is_absolute() else path.parent / p

    return Config(logs_dir=resolve(data.get("logs_dir"), "logs"),
                  results_dir=resolve(data.get("results_dir"), "results"),
                  auto_save_results=bool(data.get("auto_save_results", False)))
