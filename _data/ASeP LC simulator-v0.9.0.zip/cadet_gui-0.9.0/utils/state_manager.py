"""Save / load the final column profile for sequential runs (spec §7, HDF5, no pickle).

A state file holds CADET's full state vector and its time derivative at the end
of a run, plus the ``state_structure`` it belongs to. It can seed a later run only
if that run has the same structure (column model, cells, components, binding,
ECV); the inlet program, flow rate and parameters may differ.
"""
import io
import json
from dataclasses import dataclass
from pathlib import Path

import h5py
import numpy as np

from core.model_builder import state_structure

FILE_FORMAT = "cadet_gui.column_state"
FILE_VERSION = 1


@dataclass
class ColumnState:
    structure: dict
    state: np.ndarray
    state_derivative: np.ndarray
    source: str = ""          # e.g. original result time / file name

    def arrays(self):
        return self.state, self.state_derivative


def state_from_result(result, source=""):
    if result.final_state is None:
        raise ValueError("This result has no final column state")
    return ColumnState(state_structure(result.spec), result.final_state, result.final_state_derivative,
                       source or f"end of a {result.spec.column.model} run at t = {result.time[-1]:g} min")


def save_state(state: ColumnState, target=None):
    """Write to a path or file-like object; with no target, return bytes."""
    buffer = io.BytesIO() if target is None else None
    with h5py.File(buffer if buffer is not None else target, "w") as f:
        f.attrs["format"] = FILE_FORMAT
        f.attrs["version"] = FILE_VERSION
        f.attrs["structure"] = json.dumps(state.structure)
        f.attrs["source"] = state.source
        f.create_dataset("state", data=state.state)
        f.create_dataset("state_derivative", data=state.state_derivative)
    return buffer.getvalue() if buffer is not None else None


def _as_bytes(source):
    if isinstance(source, (bytes, bytearray)):
        return bytes(source)
    if isinstance(source, (str, Path)):
        return Path(source).read_bytes()
    return source.read()


def load_state(source) -> ColumnState:
    """A column profile file, or a result file (its run's final state)."""
    data = _as_bytes(source)
    with h5py.File(io.BytesIO(data), "r") as f:
        fmt = f.attrs.get("format")
        if fmt == FILE_FORMAT:
            if int(f.attrs["version"]) > FILE_VERSION:
                raise ValueError("Column profile file is newer than this app supports")
            return ColumnState(json.loads(f.attrs["structure"]), f["state"][()], f["state_derivative"][()],
                               str(f.attrs.get("source", "")))
    if fmt == "cadet_gui.batch_result":                  # a result file carries its final state as well
        from core.results_io import load_h5
        return state_from_result(load_h5(data), source="the final state in a result file")
    raise ValueError("Not a column profile file (.cprofile) or a result file")


def incompatibilities(state: ColumnState, spec):
    """Human-readable differences between the saved structure and ``spec`` (empty if compatible)."""
    current = state_structure(spec)
    return [f"{key}: saved {state.structure.get(key)!r}, now {current[key]!r}"
            for key in current if state.structure.get(key) != current[key]]
