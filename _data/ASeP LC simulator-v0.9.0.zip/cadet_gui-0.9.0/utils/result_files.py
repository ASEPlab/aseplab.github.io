"""Saving a file to a folder the user picks (the app runs on the user's own machine)."""
from pathlib import Path

from core.naming import file_stem
from utils.config import ROOT


def file_name(name, extension, fallback="cadet_results"):
    """A safe file name that ends in ``.extension`` (a path or a wrong extension in ``name`` is cleaned)."""
    stem = Path(str(name or "").strip()).name
    if stem.lower().endswith("." + extension.lower()):
        stem = stem[: -len(extension) - 1]
    return f"{file_stem(stem, fallback)}.{extension}"


def target_path(folder, name, extension):
    """``folder/name.extension``; ``~`` is expanded and a relative folder is relative to the app folder."""
    folder = Path(str(folder).strip() or ".").expanduser()
    if not folder.is_absolute():
        folder = ROOT / folder
    return folder / file_name(name, extension)


def save_file(folder, name, extension, data, overwrite=False):
    """Write ``data`` (bytes) to ``folder/name.extension``, creating the folder; returns the path."""
    path = target_path(folder, name, extension)
    if path.exists() and not overwrite:
        raise FileExistsError(f"{path} already exists")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return path
