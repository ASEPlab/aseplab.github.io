"""File-level helpers: configuration, column state files, run logs."""
