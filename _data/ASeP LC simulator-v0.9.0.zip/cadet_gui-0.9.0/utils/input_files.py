"""Input files: the complete input of a run in GUI units, saved and loaded as JSON.

``save_input`` writes exactly what the form holds (``BatchSpec``); ``load_input``
reads that file, and also takes the inputs back out of a run log (``logs/*.json``)
or a result file (``.h5``), so any earlier run can be reopened and changed.
"""
import json
from datetime import datetime

from core import smb
from core.model_builder import BatchSpec, spec_from_dict, spec_to_dict
from core.results_io import read_spec
from utils.logger import _jsonable

FORMAT = "cadet_gui.input"
SMB_FORMAT = "cadet_gui.smb_input"
VERSION = 1
_HDF5_MAGIC = b"\x89HDF\r\n\x1a\n"


def save_input(spec: BatchSpec) -> bytes:
    doc = {"format": FORMAT, "version": VERSION, "saved": datetime.now().isoformat(timespec="seconds"),
           "spec": _jsonable(spec_to_dict(spec))}
    return json.dumps(doc, indent=2, ensure_ascii=False).encode("utf-8")


def _spec_from(d) -> BatchSpec:
    try:
        return spec_from_dict(d)
    except (KeyError, TypeError) as e:        # missing or unknown field
        raise ValueError(f"the input is incomplete or from an incompatible version ({type(e).__name__}: {e})") from None


def load_input(data: bytes) -> BatchSpec:
    """The ``BatchSpec`` in an input file, run log or result file."""
    if data[:8] == _HDF5_MAGIC:
        return read_spec(data)
    try:
        doc = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("not an input file (expected .json from this program, a run log or a result .h5)") from None
    if not isinstance(doc, dict):
        raise ValueError("not an input file")
    if doc.get("format") == FORMAT:
        if int(doc.get("version", 1)) > VERSION:
            raise ValueError(f"input file version {doc['version']} is newer than this program supports")
        return _spec_from(doc["spec"])
    if "input" in doc and "timestamp" in doc:           # a run log
        return _spec_from(doc["input"])
    if "components" in doc and "column" in doc:         # a bare spec
        return _spec_from(doc)
    raise ValueError("not a CADET GUI input file")


# --- SMB ------------------------------------------------------------------------------------------

def save_smb_input(spec: smb.SMBSpec) -> bytes:
    doc = {"format": SMB_FORMAT, "version": VERSION, "saved": datetime.now().isoformat(timespec="seconds"),
           "spec": _jsonable(smb.spec_to_dict(spec))}
    return json.dumps(doc, indent=2, ensure_ascii=False).encode("utf-8")


def _smb_from(d) -> smb.SMBSpec:
    try:
        return smb.spec_from_dict(d)
    except (KeyError, TypeError) as e:
        raise ValueError(f"the input is incomplete or from an incompatible version ({type(e).__name__}: {e})") from None


def load_smb_input(data: bytes):
    """``("smb", SMBSpec)`` from an SMB input file, SMB run log or SMB result file, or ``("batch", BatchSpec)``
    from any Batch input (its column, binding and settings can start an SMB)."""
    if data[:8] == _HDF5_MAGIC:
        from core import smb_results
        try:
            return "smb", smb_results.read_spec(data)
        except ValueError as e:
            if "Batch result" not in str(e):
                raise
            return "batch", read_spec(data)
    try:
        doc = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        raise ValueError("not an input file (expected .json from this program, a run log or a result .h5)") from None
    if isinstance(doc, dict) and doc.get("format") == SMB_FORMAT:
        if int(doc.get("version", 1)) > VERSION:
            raise ValueError(f"input file version {doc['version']} is newer than this program supports")
        return "smb", _smb_from(doc["spec"])
    if isinstance(doc, dict) and isinstance(doc.get("input"), dict) and "base" in doc["input"]:   # SMB run log
        return "smb", _smb_from(doc["input"])
    return "batch", load_input(data)
