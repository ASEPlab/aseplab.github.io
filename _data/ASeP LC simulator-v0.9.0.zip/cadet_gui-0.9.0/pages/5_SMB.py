"""Screen 2: four-zone simulated moving bed."""
from datetime import datetime

import streamlit as st

from core import smb_results as sr
from core.naming import stamped
from core.smb_sim import SMBJob
from ui import smb_form, smb_views
from utils import logger
from utils.config import load_config

st.set_page_config(page_title="SMB — CADET GUI", layout="wide")
st.title("SMB (simulated moving bed)")
st.caption("Four zones, ports moving one column forward every switch. Columns, binding and mass transfer as in the "
           "Batch screen.")

spec, error, initial_state = smb_form.render()
if error:
    st.error(error)

st.divider()
job = st.session_state.get("smb_job")
running = job is not None and not job.done
if st.button("▶ Run SMB simulation", type="primary", disabled=spec is None or running, key="smb_run"):
    st.session_state.pop("smb_error", None)
    st.session_state["smb_job"] = SMBJob(spec, initial_state).start()
    st.rerun()


def _clock(seconds):
    seconds = int(round(seconds))
    return f"{seconds // 60}:{seconds % 60:02d}"


@st.fragment(run_every=0.5)
def _progress_panel():
    job = st.session_state.get("smb_job")
    if job is None:
        return
    if not job.done:
        goal = (f"of {job.max_cycles}" if job.spec.cycles.mode == "fixed"
                else f"(steady state, at most {job.max_cycles})")
        st.progress(job.progress, text=f"Running CADET… cycle {job.cycle + 1} {goal} · elapsed {_clock(job.elapsed)}")
        st.button("■ Cancel", on_click=job.cancel, key="smb_cancel")
        return
    del st.session_state["smb_job"]
    result = None
    if job.status == "done":
        try:
            result = sr.from_cadet(job.results, job.spec, job.converged, job.differences)
            st.session_state["smb_result"] = result
            for key in [k for k in st.session_state if k.startswith("smbview_")]:
                del st.session_state[key]
        except Exception as e:  # shown in the UI, not as a traceback page
            st.session_state["smb_error"] = f"Could not read the results: {e}"
    else:
        st.session_state.pop("smb_result", None)
        st.session_state["smb_error"] = ("Simulation cancelled." if job.status == "cancelled"
                                         else f"Simulation failed: {job.error}")
    _save_records(job, result)
    st.rerun()


def _save_records(job, result):
    cfg = load_config()
    stamp = datetime.now()
    notes = []
    try:
        path = logger.write_smb_log(cfg.logs_dir, job.spec, result, error=job.error, status=job.status,
                                    timestamp=stamp)
        notes.append(f"Run log: {path}")
        if result is not None and cfg.auto_save_results:
            cfg.results_dir.mkdir(parents=True, exist_ok=True)
            target = cfg.results_dir / stamped(job.spec.title, sr.EXTENSION, stamp, "smb_result")
            sr.save_h5(result, target)
            notes.append(f"Result file: {target}")
    except OSError as e:
        notes.append(f"Could not write the run records: {e}")
    st.session_state["smb_log_note"] = " · ".join(notes)


_progress_panel()

if st.session_state.get("smb_error"):
    st.error(st.session_state["smb_error"])

result = st.session_state.get("smb_result")
if result is not None:
    st.subheader("Result")
    s = result.summary
    st.caption((f"**{result.spec.title}** · " if result.spec.title else "")
               + f"{result.spec.layout} · {result.spec.n_columns} columns ({'-'.join(str(k) for k in result.spec.columns_per_zone)}) · "
               f"switch time {result.spec.switch_time:g} min · completed {s.get('completed', '').replace('T', ' ')}")
    smb_views.metrics(result)
    products = result.spec.geometry.products
    smb_views.outlet_grid(result, products, per_row=len(products), key="smb_brief", height=300)
    st.caption("Last cycle. Solid lines: concentration; points joined by dashed lines: average concentration of "
               "each switch interval.")
    if st.session_state.get("smb_log_note"):
        st.caption(st.session_state["smb_log_note"])
    st.page_link("pages/6_SMB_Results.py", label="Open the SMB results (all cycles, profiles, animation, export)",
                 icon="📈")
