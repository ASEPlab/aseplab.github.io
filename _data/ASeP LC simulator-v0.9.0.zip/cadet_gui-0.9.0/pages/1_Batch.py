"""Screen 1: single-column batch simulation."""
from datetime import datetime

import streamlit as st

from core.results_io import from_cadet, save_h5
from core.simulator import SimulationJob
from ui import batch_form, plots, result_views
from utils import logger, state_manager
from utils.config import load_config

st.set_page_config(page_title="Batch — CADET GUI", layout="wide")
st.title("Batch column")

spec, error, initial_state = batch_form.render()
if error:
    st.error(error)

job = st.session_state.get("batch_job")
running = job is not None and not job.done
if st.button("▶ Run simulation", type="primary", disabled=spec is None or running):
    st.session_state.pop("batch_error", None)
    st.session_state["batch_job"] = SimulationJob(
        spec, initial_state.arrays() if initial_state is not None else None).start()
    st.rerun()


def _clock(seconds):
    seconds = int(round(seconds))
    return f"{seconds // 60}:{seconds % 60:02d}"


@st.fragment(run_every=0.5)
def _progress_panel():
    """Poll the background job; hand the result to the page when it finishes."""
    job = st.session_state.get("batch_job")
    if job is None:
        return
    if not job.done:
        eta = f" · remaining ~{job.eta:.0f} s" if job.eta is not None else ""
        st.progress(job.progress, text=f"Running CADET… {job.progress:.0%} · elapsed {_clock(job.elapsed)}{eta}")
        st.button("■ Cancel", on_click=job.cancel)
        return
    del st.session_state["batch_job"]
    result = None
    if job.status == "done":
        try:
            result = from_cadet(job.results, job.spec)
            st.session_state["batch_result"] = result
        except Exception as e:  # conversion problems surface in the UI, not as a traceback page
            st.session_state["batch_error"] = f"Could not read the results: {e}"
    else:
        st.session_state.pop("batch_result", None)
        st.session_state["batch_error"] = ("Simulation cancelled." if job.status == "cancelled"
                                           else f"Simulation failed: {job.error}")
    _save_records(job, result)
    st.rerun()


def _save_records(job, result):
    """Automatic run log (always) and result file (if configured), per config.yaml."""
    cfg = load_config()
    stamp = datetime.now()
    try:
        path = logger.write_log(cfg.logs_dir, job.spec, result, error=job.error, status=job.status, timestamp=stamp)
        note = f"Log saved to {path}"
        if result is not None and cfg.auto_save_results:
            cfg.results_dir.mkdir(parents=True, exist_ok=True)
            result_path = cfg.results_dir / f"{stamp:%Y%m%d_%H%M%S}_result.h5"
            save_h5(result, result_path)
            note += f" · result saved to {result_path}"
        st.session_state["batch_log_note"] = note
    except OSError as e:
        st.session_state["batch_log_note"] = f"Could not save the run log: {e}"


if "batch_job" in st.session_state:
    _progress_panel()
if "batch_error" in st.session_state:
    st.error(st.session_state["batch_error"])
if "batch_log_note" in st.session_state:
    st.caption(st.session_state["batch_log_note"])

result = st.session_state.get("batch_result")
if result:
    s = result.summary
    status = "OK" if s["exit_flag"] == 0 else f"exit flag {s['exit_flag']}: {s['exit_message']}"
    st.subheader("Chromatogram")
    st.caption((f"**{result.spec.title}** · " if result.spec.title else "")
               + f"Computation time {s['time_elapsed_s']:.2f} s · {status}")
    shown = result_views.component_selector(result, "batch_components_shown")
    st.plotly_chart(plots.chromatogram(result, components=shown), width="stretch")
    result_views.modifier_plots(result)
    with st.expander("Simulation summary — amounts, dimensionless groups, checks"):
        result_views.summary_panel(result, "batch")
    result_views.excel_button(result, "batch")
    c1, c2, c3 = st.columns([1, 1, 3])
    if c1.button("Open results viewer →"):
        st.session_state["viewer_source"] = "Last simulation"
        st.switch_page("pages/3_Results_Viewer.py")
    c2.download_button("💾 Outlet CSV", result.outlet_dataframe().to_csv(index=False), "outlet.csv", "text/csv")
    if result.final_state is not None:
        c3.download_button("💾 Column profile", state_manager.save_state(state_manager.state_from_result(result)),
                           "column_profile.cprofile", "application/x-hdf5",
                           help="The concentrations inside the column at the end of this run. Use it in this "
                                "screen under Initial state → Load column profile (not in the Results viewer).")
