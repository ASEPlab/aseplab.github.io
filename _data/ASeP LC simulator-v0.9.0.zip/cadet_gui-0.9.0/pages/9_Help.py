"""Help: inputs, model equations and outputs (spec §2 Help screen)."""
import streamlit as st

st.set_page_config(page_title="Help — CADET GUI", layout="wide")
st.title("Help")
st.caption("GUI units: cm, mL, mL/min, min, particle radius in µm. CADET runs in SI; all conversions are automatic.")

inputs, equations, outputs, smb_tab = st.tabs(["Inputs", "Model equations", "Outputs", "SMB"])

# --- Inputs ---------------------------------------------------------------------
with inputs:
    st.subheader("Input file")
    st.markdown("""
The Batch screen is one page; scroll down through Components, Column, Binding, Reactions, Mass transfer,
Inlet / process, Initial state and Simulation.

- **Save input file** writes everything on the page (GUI units) to a `.json` file.
- **Load an input file**: choose that file and the page fills in automatically. A **run log**
  (`logs/…_simulation.json`) or a **result file** (`.h5`) works too, so any earlier run can be reopened
  and changed. Loading replaces the whole page.
- **Examples** load ready-made inputs. **New** starts over: the form returns to its startup values and the
  previous result is cleared (save the input file first if you want to keep it).
""")
    st.subheader("Components")
    st.markdown("""
Add a solute with **+ Add component**, remove one with its **−** button (at least one stays).

| Field | Meaning |
|---|---|
| name | Unique name, used in reactions and plots |
| MW [g/mol] | Needed for g/L, mg/L and mg/g units |
| charge ν | Needed for meq units; is the GIEX characteristic charge |
| adsorbs | Has a bound state (ignored by the binding model if unchecked) |
| liquid unit | mol/L, mmol/L, g/L, mg/L, meq/L |
| solid unit | amount per **mL solid** (CADET basis), **mL bed** (packed bed), or **g resin** |

Isotherm constants are entered in each component's own units and converted with them
(e.g. Langmuir K in 1/(mmol/L) or 1/(mg/L)).

**salt** and **pH** are not listed: choosing the GIEX binding model adds them (salt: counter-ion with its
unit and the capacity unit; pH: modulator without a unit), and they then appear in the mass transfer,
inlet and initial state tables.
""")
    st.subheader("Column")
    st.markdown("""
| Field | Unit | Notes |
|---|---|---|
| Column model | — | GRM, LRMP, LRM (keff), LRM (CADET original) — see *Model equations* |
| L, D | cm | Length, diameter |
| εb, εp | — | Bed and particle porosity; εt = εb + (1 − εb)·εp |
| R | µm | Particle radius |
| εt | — | LRM only (default from εb, εp) |
| Resin density | g/mL | Only for "g resin" units: skeletal (per mL solid), particle (per mL particle) or packing (per mL bed) |
""")
    st.subheader("Binding")
    st.markdown("""
Model names link to the CADET 5.1.1 documentation of that binding model
([overview of all binding models](https://cadet.github.io/v5.1.1/modelling/binding/index.html)).
Each model works in **rapid equilibrium** (K only) or **kinetic** (ka, kd; Freundlich: k_LDF) mode.

| Model | Inputs per solute | Notes |
|---|---|---|
| **[Linear](https://cadet.github.io/v5.1.1/modelling/binding/linear.html)** | K, or ka and kd | q = K·c |
| **[Langmuir](https://cadet.github.io/v5.1.1/modelling/binding/multi_component_langmuir.html)** | K (or ka, kd), qmax | Competitive multi-component: all components share the sites |
| **[Anti-Langmuir](https://cadet.github.io/v5.1.1/modelling/binding/multi_component_anti_langmuir.html)** | as Langmuir, plus p = ±1 | p = −1: that component raises the loading of the others. Rapid equilibrium may not converge when K·c of an anti component is large; use kinetic mode |
| **[Bi-Langmuir](https://cadet.github.io/v5.1.1/modelling/binding/multi_component_bi_langmuir.html)** | K, qmax (site 1) and K2, qmax2 (site 2) | Two independent site types; bound amount = sum over sites. No initial q₀ |
| **[Freundlich](https://cadet.github.io/v5.1.1/modelling/binding/freundlich_ldf.html)** | K_F, n (and k_LDF in kinetic mode) | q = K_F·c^(1/n); no competition between components |
| **[SMA](https://cadet.github.io/v5.1.1/modelling/binding/steric_mass_action.html)** | K (or ka, kd), σ; ν = charge | Salt counter-ion added automatically; Λ, c_ref, q_ref |
| **[GIEX](https://cadet.github.io/v5.1.1/modelling/binding/generalized_ion_exchange.html)** | as SMA, plus pH coefficients | Salt and pH added automatically; pH_ref |

- Constants are entered in each component's own units and converted with them. For Freundlich, K_F has the
  unit (solid)/(liquid)^(1/n).
- **LRM (keff)** always uses rapid-equilibrium binding (the kinetics are in keff).
- GIEX with all pH coefficients 0 is the SMA model.
""")
    st.subheader("Reactions")
    st.markdown("""
Tick **Include mobile-phase reactions** to show the inputs. Mass-action reactions in the mobile phase,
applied in the bulk **and** pore liquid. Write
`M1 + L = M1L` or `M + B-C = B-M + C`; a coefficient is a number and a space (`2 L`).
Rate constants use a molar basis (mol/L or mmol/L) independent of the display units:
k+ [basis^(1−n+)/min] and k− [basis^(1−n−)/min] are entered for every reaction; Ka = k+/k− is
shown. Fast reactions (Nk− ≫ 1) stay close to equilibrium, so then mainly Ka matters.
""")
    st.subheader("Mass transfer")
    st.markdown("""
- **Direct input**: Eb [cm²/min]; kf [cm/min] (GRM, LRMP), keff [cm/min] (LRM (keff)), Dp [cm²/min] (GRM).
- **Correlation estimate**: viscosity μ [cP], density ρ [g/mL] and Dm [cm²/min] per component
  (optionally from Wilke & Chang with V_A [cm³/mol]); Eb and kf are computed, keff via Glueckauf
  when Dp is given. Dp has no correlation.
""")
    st.subheader("Inlet / process")
    st.markdown("""
- **Q** [mL/min]. **Extra-column volume** [mL]: split into an inlet and an outlet CSTR of V/2.
- **Pulse injection**: tick it, enter the **injection volume** [mL], the **start** [min] and the **feed
  concentration** of every component. From the start for V/Q minutes the inlet carries the feed; before
  and after, it follows the eluent program below. Untick it for continuous loading (e.g. a breakthrough
  curve), where the table alone defines the inlet.
- **Eluent program** (or **Inlet program** without an injection): each row sets the concentrations from its
  start time [min]. *step* holds them until the next row; *linear* ramps to the next row's values; the last
  row is held to the end. Salt and pH gradients are rows of this table.
- The graph **Inlet over time** shows what the column receives (injection included); with GIEX, salt and pH
  are drawn on their own axes.
""")
    st.subheader("Initial state")
    st.markdown("""
- **Fresh column**: per component c₀ (bulk and pore liquid, liquid unit) and q₀ (bound, solid unit),
  uniform along the column; default 0. GIEX: enter the initial salt and pH (the buffer the column was
  equilibrated with); salt on the resin is set by electroneutrality, q_salt = Λ − Σ ν·q.
  With rapid-equilibrium binding CADET re-partitions pore liquid and resin to equilibrium at t = 0,
  keeping the total amount.
- **Final state of the last run** or **Load column profile** (a file saved with the *Column profile* button
  of a result): continue a sequential run. A saved profile only fits a setup with the same column model,
  cells, components, binding and ECV.
""")
    st.subheader("Simulation")
    st.markdown("""
Total time and output interval [min]; axial cells; particle cells (GRM); max computation time [s].

**Solver tolerances** (expander). *Automatic* scales the absolute tolerance, algebraic tolerance and WENO
epsilon to the smallest solute concentration: at mM and above they equal CADET's defaults, for trace
concentrations they are lowered so the result does not depend on the concentration level (fixed defaults
distort a 1 nM peak by ~5 %). *Manual* takes the four values you type (e.g. `1e-8`); raising reltol
(e.g. `1e-4`) speeds up very stiff problems at some cost in accuracy. Smaller numbers are stricter.
The values used are written to the run log.
""")

# --- Equations ----------------------------------------------------------------------
with equations:
    st.markdown("Symbols: $c_b$ bulk, $c_p$ pore liquid, $q$ solid; $u = Q/(\\varepsilon_b A)$ interstitial "
                "velocity; $E_b$ axial dispersion; $D_p$ pore diffusivity (excludes $\\varepsilon_p$).")
    st.markdown("CADET 5.1.1 documentation: [general rate model](https://cadet.github.io/v5.1.1/modelling/unit_operations/general_rate_model.html), "
                "[lumped rate model with pores](https://cadet.github.io/v5.1.1/modelling/unit_operations/lumped_rate_model_with_pores.html), "
                "[lumped rate model without pores](https://cadet.github.io/v5.1.1/modelling/unit_operations/lumped_rate_model_without_pores.html), "
                "[binding models](https://cadet.github.io/v5.1.1/modelling/binding/index.html).")
    st.subheader("GRM — general rate model")
    st.latex(r"\frac{\partial c_b}{\partial t} = E_b \frac{\partial^2 c_b}{\partial z^2} - u \frac{\partial c_b}"
             r"{\partial z} - \frac{3(1-\varepsilon_b)k_f}{\varepsilon_b R}\left(c_b - c_p|_{r=R}\right)")
    st.latex(r"\frac{\partial c_p}{\partial t} + \frac{1-\varepsilon_p}{\varepsilon_p}\frac{\partial q}{\partial t}"
             r" = D_p \frac{1}{r^2}\frac{\partial}{\partial r}\left(r^2 \frac{\partial c_p}{\partial r}\right),"
             r"\qquad \varepsilon_p D_p \left.\frac{\partial c_p}{\partial r}\right|_{R} = k_f (c_b - c_p|_R)")
    st.subheader("LRMP — lumped rate model with pores")
    st.latex(r"\frac{\partial c_b}{\partial t} = E_b \frac{\partial^2 c_b}{\partial z^2} - u \frac{\partial c_b}"
             r"{\partial z} - \frac{3(1-\varepsilon_b)k_f}{\varepsilon_b R}(c_b - c_p),\qquad"
             r"\varepsilon_p \frac{\partial c_p}{\partial t} + (1-\varepsilon_p)\frac{\partial q}{\partial t}"
             r" = \frac{3 k_f}{R}(c_b - c_p)")
    st.subheader("LRM (keff)")
    st.markdown("The LRMP with $k_f = k_{eff}$ and rapid-equilibrium binding ($c^*$ in equilibrium with $q$); "
                "exact for non-linear isotherms. Glueckauf: $1/k_{eff} = 1/k_f + R/(5\\varepsilon_p D_p)$.")
    st.subheader("LRM (CADET original)")
    st.latex(r"\varepsilon_t \frac{\partial c}{\partial t} + (1-\varepsilon_t)\frac{\partial q}{\partial t} = "
             r"\varepsilon_t\left(E_b \frac{\partial^2 c}{\partial z^2} - u_t \frac{\partial c}{\partial z}\right),"
             r"\qquad u_t = \frac{Q}{\varepsilon_t A}")
    st.markdown("Mass transfer is lumped into the binding kinetics. For a linear isotherm "
                "$k_a = 3k_{eff}/R$, $k_d = 3k_{eff}/(RK)$.")

    st.subheader("Binding")
    st.latex(r"\text{Linear: } \frac{\partial q_i}{\partial t} = k_{a,i} c_i - k_{d,i} q_i \quad"
             r"\text{Langmuir: } \frac{\partial q_i}{\partial t} = k_{a,i} c_i (q_{max,i} - q_i) - k_{d,i} q_i")
    st.latex(r"\text{GIEX: } \frac{\partial q_i}{\partial t} = k_{a,i}(x)\, c_i \left(\frac{\bar q_0}{q_{ref}}"
             r"\right)^{\nu_i(x)} - k_{d,i}(x)\, q_i \left(\frac{c_0}{c_{ref}}\right)^{\nu_i(x)},\quad"
             r"\bar q_0 = \Lambda - \sum_j (\nu_j + \sigma_j) q_j")
    st.latex(r"k_{a,i}(x) = k_{a,i}\exp\left(a_1 x + a_2 x^2 + a_3 x^3 + k_{a,salt} c_0 + k_{a,prot} c_i\right)"
             r"\quad (k_{d,i} \text{ alike})")
    st.latex(r"\nu_i(x) = \nu_i + n_1 x + n_2 x^2 + n_3 x^3, \qquad x = \mathrm{pH} - \mathrm{pH_{ref}}")
    st.markdown("Rapid equilibrium sets the right-hand side to zero with $K = k_a/k_d$. "
                "SMA is the GIEX equation without the pH terms (and without salt/protein exponents).")
    st.markdown("**ka, kd and K in SMA / GIEX.** $K_i = k_{a,i}/k_{d,i}$ is the distribution ratio $q_i/c_i$ at "
                "the reference state ($\\bar q_0 = q_{ref}$, $c_0 = c_{ref}$, pH = pH_ref), in the units of a "
                "Linear K. *Kinetic*: enter $k_a$ and $k_d$. *Rapid equilibrium*: enter $K$ only (the program "
                "uses $k_d = 1$, $k_a = K$; only the ratio matters). In the pH polynomials, the table columns "
                "are $\\ln k_a$ (kinetic) or $\\ln K$ (rapid equilibrium) versus $x = \\mathrm{pH} - "
                "\\mathrm{pH_{ref}}$; the effective $\\ln K(x)$ is the $k_a$ polynomial minus the $k_d$ one.")
    st.latex(r"\text{Anti-Langmuir: } \frac{\partial q_i}{\partial t} = k_{a,i} c_i q_{max,i}\left(1 - \sum_j p_j "
             r"\frac{q_j}{q_{max,j}}\right) - k_{d,i} q_i, \quad p_j = \pm 1, \qquad "
             r"q_i^* = \frac{q_{max,i} K_i c_i}{1 + \sum_j p_j K_j c_j}")
    st.latex(r"\text{Bi-Langmuir (site } s\text{): } \frac{\partial q_{i,s}}{\partial t} = k_{a,i}^{(s)} c_i q_{max,i}^{(s)}"
             r"\left(1 - \sum_j \frac{q_{j,s}}{q_{max,j}^{(s)}}\right) - k_{d,i}^{(s)} q_{i,s}, \qquad q_i = \sum_s q_{i,s}")
    st.latex(r"\text{Freundlich: } q_i^* = K_{F,i}\, c_i^{1/n_i}, \qquad "
             r"\frac{\partial q_i}{\partial t} = k_{LDF,i}\,(q_i^* - q_i)\ \text{(kinetic)}")

    st.subheader("Reactions (bulk and pore liquid)")
    st.latex(r"r = k_+ \prod_{\text{reactants}} c^{\nu} - k_- \prod_{\text{products}} c^{\nu},\qquad K_a = k_+/k_-")

    st.subheader("Correlations")
    st.latex(r"Re = \frac{d_p \rho u_s}{\mu}, \qquad Sc = \frac{\mu}{\rho D_m}, \qquad u_s = \varepsilon_b u")
    st.latex(r"\text{Chung \& Wen: } E_b = \frac{d_p u \varepsilon_b}{0.2 + 0.011 Re^{0.48}}")
    st.latex(r"\text{Wilson \& Geankoplis } (0.0016 < Re < 55): "
             r"k_f = \frac{1.09}{\varepsilon_b}\left(\frac{D_m^2 u_s}{d_p^2}\right)^{1/3}")
    st.latex(r"\text{Wilke \& Chang: } D_m\,[\mathrm{cm^2/s}] = "
             r"\frac{7.4\times10^{-8}\,(\varphi M_B)^{1/2}\, T}{\mu\, V_A^{0.6}}")

    st.subheader("Dimensionless groups and diagnostics")
    st.markdown("""
| Group | Definition | Models |
|---|---|---|
| 1/Pe | Eb/(u·L) | all |
| Nf | 3(L/R)(1−εb)kf/(εb·u) | GRM, LRMP |
| ND | (1−εb)εp·L·Dp/(εb·u·R²) | GRM |
| Bi | kf·R/(εp·Dp) = Nf/(3·ND) | GRM |
| N_eff | 3(L/R)(1−εb)keff/(εb·u) | LRM (keff) |
| Nk+ | L·k+·C/u (C: largest inlet reactant conc.) | reactions |
| Nk− | L·k−/u | reactions |

Nk− ≫ 1: the reaction stays near equilibrium; Nk− ~ 1: reaction kinetics shape the result. Bi > 1: pore diffusion limits;
Bi < 1: film diffusion limits. 1/Pe < 0.01: dispersion has a small effect.
""")

# --- Outputs -------------------------------------------------------------------------
with outputs:
    st.subheader("Chromatogram")
    st.markdown("Outlet concentration vs time at the **system outlet** (after the outlet ECV tank), in each "
                "component's liquid unit. With GIEX, salt and pH are drawn on their own axes below.")
    st.subheader("Column profile (Results viewer)")
    st.markdown("""
Concentration along the column at one time, for the **bulk liquid**, **pore liquid** (particle-volume
average) or **solid** (particle-volume average, in the solid unit). Click the chromatogram, use the
step buttons or the slider to pick the time; ▶ 1x / 2x / 5x animates it in the browser.
*Save the animation as MP4 / GIF* encodes it (frames per second and number of frames selectable).
""")
    st.subheader("Simulation summary")
    st.markdown("""
- Computation time, output points, exit status.
- **Per-component amount**: input = ∫C_in·Q dt (exact, from the inlet program), output = ∫C_out·Q dt
  (trapezoid rule), in the component's unit or one you choose (mol, mmol, µmol, g, mg, meq).
- Dimensionless groups, reaction numbers and diagnostics.
- **Numerical checks**: NaN count and negative undershoot of the outlet. CADET-Core 5.1.1 does not report
  step counts or error-test / Newton failures.
""")
    st.subheader("Files")
    st.markdown("""
The **Simulation title** (Batch → Input file) names the input file and the Excel workbook
(`<title>_YYYYMMDD_HHMMSS.xlsx`) and is shown in the Summary.

| File | Content | Where to use it |
|---|---|---|
| **Excel workbook** (`.xlsx`) | everything about a run in one file: see below | open in Excel |
| Outlet CSV | time [min] and outlet concentrations | any program |
| Profile CSV | z [cm] and the selected phase at the selected time | any program |
| Amounts CSV | per-component input / output amount | any program |
| **Result file** (`.h5`, HDF5) | all inputs and the full solution | Results viewer → *Load result file*; also *Load an input file* |
| **Column profile** (`.cprofile`) | the concentrations inside the column at the end of a run | Batch → Initial state → *Load column profile*, to continue from it (not for the Results viewer) |
| Input file (`.json`) | the complete input | *Load an input file* |
| Run log | `logs/YYYYMMDD_HHMMSS_simulation.json` after every run: inputs, outcome, amounts, groups | *Load an input file* |

`.h5` and `.hdf5` are the same HDF5 format; only the extension differs (this app writes `.h5`).
In the Results viewer, *Save the result file with a chosen name and folder* writes the `.h5` file to a folder
you type (default `results_dir` of `config.yaml`) under a file name you choose; it will not overwrite
an existing file unless you tick the box. The folder is on the computer that runs the app. The browser download
buttons use the browser's own download location.
A result file also works under *Load column profile* (its run's final state is used).
The result file and the column profile are both HDF5 files with different content; the different extension
keeps them apart, and opening one in the wrong place tells you where it belongs.

**Excel workbook sheets**
1. **Summary**: the simulation title, when the simulation finished and when the workbook was created, run information, components, column and process, the inlet program, initial state, binding
   parameters, mass-transfer coefficients (with the correlation estimates if used), reactions and reaction
   numbers, simulation settings and solver tolerances, dimensionless numbers with diagnostics, the amounts,
   peak positions and numerical checks.
2. **Data**: one table for plotting — time, inlet, outlet (and the column outlet when there is dead volume),
   one column per component.
3. **Charts**: Excel charts of the Data columns.
4. **Profile bulk / pore / solid** (only if *Include column profiles* is ticked next to the Excel button):
   concentrations along the column at 21 evenly spaced times.
5. **Input parameters**: every input as `parameter, value`.

**Dead volume**: the *outlet* columns (CSV and Excel) are the system outlet, i.e. after the outlet
dead-volume tank. With dead volume the Excel Data sheet also has *column outlet (before dead volume)*.
The inlet columns are what enters the system (before the inlet tank). The column profiles are inside the column.

Log and result folders are set in `config.yaml` (e.g. a shared OneDrive folder).
""")

# --- SMB ----------------------------------------------------------------------
with smb_tab:
    st.markdown("""
The **SMB** screen simulates a four-zone simulated moving bed. Every column is the Batch column: all column
models, binding models and mobile-phase reactions work. The SMB form keeps its own values (separate from the
Batch form); **Copy from Batch** takes the components, column, binding, reactions, mass transfer and settings
from the Batch screen. Input files, examples and *New* work as on the Batch screen; the input file can also be
saved straight to a folder (*Save the input file with a chosen name and folder*), independent of the browser's
downloads.
""")
    st.subheader("Layout")
    st.markdown("""
Liquid flows zone I → II → …; every switch time t_s the ports move one column forward (equivalently the columns
move one position back), so one cycle is (number of columns) · t_s. Columns per zone: 1–8 each.

| Layout | Ports (in flow order) | Products | Use |
|---|---|---|---|
| **4 zones, closed** | eluent → I → extract · II · feed → III → raffinate · IV → back to I | 2 | the standard SMB; zone IV regenerates the eluent, least eluent |
| **4 zones, open** | as closed, but the zone IV outlet goes to waste | 2 | when the eluent cannot be recycled |
| **3 zones** | eluent → I → extract · II · feed → III → raffinate (all of it) | 2 | simplest; no zone IV |
| **5 zones, closed** | eluent → I → extract 1 · II → extract 2 · III · feed → IV → raffinate · V → back to I | 3 | strong / intermediate / weak solute |
| **5 zones, open** | as 5 zones closed, but the zone V outlet goes to waste | 3 | three products without eluent recycle |

Changing the layout carries the zone flows over where they still make a valid SMB (otherwise defaults) and shows
them as zone flows; check them.
""")
    st.latex(r"m_j = \frac{Q_j t_s - V_c\,\varepsilon_t}{V_c (1-\varepsilon_t)}")
    st.markdown("""
| Flow input | Values | |
|---|---|---|
| External flows | Q_F, Q_D, the extract flow(s), and the last zone's flow (closed: the recycle; 4-zone open: to waste) | Q_R follows from the balance |
| Zone flows | Q of every zone | |
| m values | m of every zone | the flow-rate ratios of the triangle theory |

Switching the input keeps the same SMB (the values are converted). All zone flows and all port flows (feed, eluent,
extracts, raffinate, waste) must be positive; the table under the inputs shows every flow and m value.

**Triangle design** (closed 4-zone layout, two adsorbing components, Linear or Langmuir): with safety factor γ the m values are placed
inside the complete-separation region (γ = 1: the optimal vertex). For other binding models enter the flows
directly. The plot shows the linear triangle at infinite dilution and the operating point (m₂, m₃).

**Feed and eluent**: constant concentrations of every component (salt and pH too for SMA / GIEX).
**Process layout**: under the flows the SMB screen animates one cycle from the inputs alone: the columns stay in
place and the four ports move one column forward every switch (play, previous / next switch, slider).

**Products**: which components are collected in each product outlet (purity and recovery); by default
the solutes go to the outlets in order of their Henry coefficients (strongest to the first extract).

**Mass transfer**: one set of coefficients for all columns. Correlations use the mean zone flow.

**Cycles**: run until cyclic steady state (two successive cycles agree within the tolerance in relative
area and normalised RMS error of every outlet stream and every column outlet, per component; at most
*max cycles*) or a fixed number of cycles. A warning appears when the last two cycles still differ by more than
the tolerance (also after a fixed number of cycles); then run more cycles or continue from the final state. Each cycle is one CADET run that continues from the previous state, so progress is shown per cycle.
*Final state of the last SMB run* continues a run (e.g. after it stopped before steady state); *Load an SMB
result file* continues from the end of a saved run (.smbh5). Layout, columns per zone, column model, grid,
components and binding must match; flows, switch time and feed / eluent may change (e.g. to run operating
conditions one after another).
""")
    st.subheader("Results")
    st.markdown("""
The SMB screen shows the headline numbers and the last cycle's outlets. The **SMB results** page has:

- **Outlets**: one plot per outlet stream (choose which, how many per row and the height); last cycle or all
  cycles. Solid lines: the concentration; points joined by dashed lines: the average concentration of each switch
  interval (what a fraction collected over that switch would contain). Also the outlet of any single column.
- **Cycles**: purity and recovery per cycle (convergence) and the amounts fed / collected per cycle.
- **Column profiles**: bulk / pore / solid along the ring (zone I first, zones shaded, ports marked) at any
  time from the first cycle to the last: step one profile time, one switch or one cycle, or play this cycle or
  the whole run. Profiles are stored at every output time (thinned automatically only for very long runs, or at
  the *Column profile interval* set under Simulation).
  *Save the animation as MP4 / GIF*: this cycle or the whole run, frames and speed chosen.
- **Process animation**: the columns stay in place while the ports move; play, previous / next switch, slider.
  *Save the layout as images*: one PNG per switch (single image or a ZIP of all), also on the SMB screen.
- **Export**: Excel workbook (Summary, Data, Cycles, Charts, Column outlets, Input parameters; ring profiles on
  request; an Average concentration sheet), CSV, and the SMB result file (.smbh5: an HDF5 file with its own extension, so it is not mixed up with Batch results), also with a chosen name and folder. A result file can be reopened
  here, loaded on the SMB screen to restore its input, or made the 'last SMB run' to continue from it.

**Definitions** (per cycle, solutes only — salt and pH are not counted):
purity of an outlet = products in it / all solutes in it; recovery = product in its outlet / product fed with
the feed in the same cycle; productivity = product per hour per litre of all columns; eluent use = litres of
eluent per amount of product.
""")
