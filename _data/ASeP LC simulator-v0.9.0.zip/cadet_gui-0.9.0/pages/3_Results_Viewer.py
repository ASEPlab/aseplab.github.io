"""Results viewer: chromatogram linked to the column-internal concentration profile."""
import numpy as np
import streamlit as st

from datetime import datetime

from core import animation, mass
from core.naming import stamped
from core.results_io import load_h5, save_h5
from ui import plots, result_views
from utils import result_files, state_manager
from utils.config import load_config

st.set_page_config(page_title="Results viewer — CADET GUI", layout="wide")
st.title("Results viewer")

source = st.radio("Source", ["Last simulation", "Load result file"], horizontal=True, key="viewer_source")
if source == "Load result file":
    upload = st.file_uploader("CADET GUI result file (.h5)", type=["h5", "hdf5"])
    if upload is not None and st.session_state.get("viewer_file_id") != upload.file_id:
        try:
            st.session_state["viewer_file_result"] = load_h5(upload.getvalue())
            st.session_state["viewer_file_id"] = upload.file_id
        except (OSError, ValueError, KeyError) as e:
            st.session_state.pop("viewer_file_result", None)
            st.error(f"Could not read {upload.name}: {e}")
    result = st.session_state.get("viewer_file_result") if upload is not None else None
else:
    result = st.session_state.get("batch_result")

if result is None:
    st.info("Run a simulation on the Batch screen, or load a result file.")
    st.stop()

s = result.summary
status = "OK" if s.get("exit_flag") == 0 else f"exit flag {s.get('exit_flag')}: {s.get('exit_message')}"
st.caption((f"**{result.spec.title}** · " if result.spec.title else "")
           + f"{result.spec.column.model} · {len(result.components)} components · "
           f"computation time {s.get('time_elapsed_s', float('nan')):.2f} s · {status}")

# --- Time selection: chromatogram click, step buttons and slider ------------
nt = len(result.time)
T_KEY = "viewer_t_index"
if st.session_state.get(T_KEY, 0) >= nt:
    st.session_state[T_KEY] = 0

selection = st.session_state.get("viewer_chromatogram", {}).get("selection", {}).get("points", [])
if selection:
    clicked = (selection[0]["x"], selection[0].get("curve_number"))
    if clicked != st.session_state.get("viewer_last_click"):
        st.session_state["viewer_last_click"] = clicked
        st.session_state[T_KEY] = int(np.abs(result.time - clicked[0]).argmin())

t_index = st.session_state.get(T_KEY, 0)
st.subheader("Chromatogram")
st.caption("Click a point to show the column profile at that time.")
shown = result_views.component_selector(result, "viewer_components_shown")
st.plotly_chart(plots.chromatogram(result, result.time[t_index], components=shown), width="stretch",
                on_select="rerun", selection_mode="points", key="viewer_chromatogram")
result_views.modifier_plots(result, result.time[t_index])


def _step(delta=None, to=None):
    i = st.session_state.get(T_KEY, 0)
    st.session_state[T_KEY] = to if to is not None else int(np.clip(i + delta, 0, nt - 1))


phases = result.phases()
if not phases:
    st.info("This result has no column profiles (profile recording was off).")
else:
    st.subheader("Column profile")
    c = st.columns([1, 1, 1, 1, 9, 4, 4], vertical_alignment="center")
    steps = [("first_page", "viewer_first", {"to": 0}, "First output time"),
             ("chevron_left", "viewer_prev", {"delta": -1}, "Previous output time"),
             ("chevron_right", "viewer_next", {"delta": 1}, "Next output time"),
             ("last_page", "viewer_last", {"to": nt - 1}, "Last output time")]
    for col, (icon, key, kwargs, tip) in zip(c, steps):
        col.button("", icon=f":material/{icon}:", key=key, on_click=_step, kwargs=kwargs, help=tip)
    c[4].select_slider("Time", options=range(nt), key=T_KEY, label_visibility="collapsed",
                       format_func=lambda i: f"t = {result.time[i]:.4g} min")
    phase = c[5].selectbox("Phase", phases, format_func=plots.PHASE_LABELS.get, key="viewer_phase",
                           label_visibility="collapsed")
    fixed_y = c[6].toggle("Fixed y-axis", value=True, key="viewer_fixed_y",
                          help="Same y range for all times (for animation). Off: fit the current time.")
    st.plotly_chart(plots.column_profile(result, phase, st.session_state[T_KEY], fixed_y=fixed_y,
                                         components=shown), width="stretch")
    st.caption("▶ 1x / 2x / 5x play the profile over time in the browser; the slider under the plot scrubs it.")
    with st.expander("💾 Save the animation as MP4 / GIF"):
        v = st.columns([2, 2, 2, 1], vertical_alignment="bottom")
        fmt = v[0].selectbox("Format", animation.VIDEO_FORMATS, format_func=str.upper, key="viewer_video_fmt")
        fps = v[1].number_input("Frames per second", min_value=1, max_value=60, value=10, key="viewer_video_fps")
        n_frames = v[2].number_input("Frames", min_value=10, max_value=1000, value=150, step=10,
                                     key="viewer_video_frames", help="Evenly spaced over the run")
        if v[3].button("Create", key="viewer_video_create"):
            try:
                with st.spinner(f"Encoding {fmt.upper()}…"):
                    data = animation.profile_video(result, phase, shown, plots.SERIES_COLORS, fmt=fmt,
                                                   fps=int(fps), max_frames=int(n_frames), fixed_y=fixed_y)
                st.session_state["viewer_video"] = {"fmt": fmt, "phase": phase, "data": data, "for": result}
            except (ValueError, OSError, RuntimeError) as e:
                st.error(f"Could not create the animation: {e}")
        video = st.session_state.get("viewer_video")
        if video and video["for"] is result:
            mime = "video/mp4" if video["fmt"] == "mp4" else "image/gif"
            if video["fmt"] == "mp4":
                st.video(video["data"], format=mime)
            else:
                st.image(video["data"])
            st.download_button(f"💾 Download {video['fmt'].upper()}", video["data"],
                               f"profile_{video['phase']}.{video['fmt']}", mime)

# --- Summary ----------------------------------------------------------------
st.subheader("Simulation summary")
result_views.summary_panel(result, "viewer")

# --- Export -----------------------------------------------------------------
st.subheader("Export")
st.caption("The outlet columns are the system outlet, after the outlet dead volume if there is one; the Excel "
           "workbook also has the concentration leaving the column itself.")
result_views.excel_button(result, "viewer")
c = st.columns(5)
c[0].download_button("💾 Outlet CSV", result.outlet_dataframe().to_csv(index=False), "outlet.csv", "text/csv")
if st.session_state.get("viewer_h5_for") is not result:   # serialise once per result
    st.session_state["viewer_h5"] = save_h5(result)
    st.session_state["viewer_h5_for"] = result
c[1].download_button("💾 Result file (.h5)", st.session_state["viewer_h5"],
                     result_files.file_name(st.session_state.get("viewer_h5_name"), "h5", "result"),
                     "application/x-hdf5", help="Downloads with the file name below.")
c[2].download_button("💾 Amounts CSV", mass.mass_table(result).to_csv(), "amounts.csv", "text/csv")
if phases:
    t_now = st.session_state[T_KEY]
    c[3].download_button("💾 Profile CSV (this time)",
                         result.profile_dataframe(phase, t_now).to_csv(index=False),
                         f"profile_{phase}_t{result.time[t_now]:g}min.csv", "text/csv")
if result.final_state is not None:
    c[4].download_button("💾 Column profile", state_manager.save_state(state_manager.state_from_result(result)),
                         "column_profile.cprofile", "application/x-hdf5",
                         help="Concentrations inside the column at the end of this run, to continue from it: "
                              "Batch → Initial state → Load column profile.")

# --- Save the result file under a chosen name, in a chosen folder ---------------
if st.session_state.get("viewer_h5_name_for") is not result:        # a new result: suggest title + time
    st.session_state["viewer_h5_name"] = stamped(result.spec.title, "h5", datetime.now(), "result")
    st.session_state["viewer_h5_name_for"] = result
st.session_state.setdefault("viewer_h5_folder", str(load_config().results_dir))
with st.expander("Save the result file with a chosen name and folder"):
    n1, n2 = st.columns(2)
    n1.text_input("File name", key="viewer_h5_name", help="The extension .h5 is added if missing.")
    n2.text_input("Folder", key="viewer_h5_folder", help="The default is results_dir from config.yaml. "
                  "A new folder is created. This is a folder on the computer that runs the app.")
    target = result_files.target_path(st.session_state["viewer_h5_folder"], st.session_state["viewer_h5_name"], "h5")
    taken = target.exists()
    overwrite = st.checkbox(f"{target.name} already exists in this folder: overwrite it", key="viewer_h5_overwrite") \
        if taken else False
    st.caption(f"Will be saved as `{target}`")
    if st.button("💾 Save to this folder", key="viewer_h5_save", disabled=taken and not overwrite):
        try:
            saved = result_files.save_file(st.session_state["viewer_h5_folder"], st.session_state["viewer_h5_name"],
                                           "h5", st.session_state["viewer_h5"], overwrite=overwrite)
            st.success(f"Saved {saved}")
        except OSError as e:
            st.error(f"Could not save the file: {e}")
