"""SMB results: outlets over all cycles, convergence, ring profiles, process animation and export."""
from datetime import datetime

import numpy as np
import streamlit as st

from core import animation, smb, smb_excel, smb_media
from core import smb_results as sr
from core.naming import stamped
from core.palette import SERIES_COLORS
from ui import save_panel, smb_animation, smb_views
from ui.plots import PHASE_LABELS

st.set_page_config(page_title="SMB results — CADET GUI", layout="wide")
st.title("SMB results")

source = st.radio("Source", ["Last SMB simulation", "Load SMB result file"], horizontal=True, key="smbview_source")
if source == "Load SMB result file":
    upload = st.file_uploader(f"SMB result file (.{sr.EXTENSION})", type=[sr.EXTENSION, "h5", "hdf5"],
                              key="smbview_upload", help="Older SMB results saved as .h5 open too.")
    result = None
    if upload is not None:
        try:
            result = sr.load_h5(upload.getvalue())
        except (ValueError, OSError, KeyError) as e:
            st.error(f"Could not open {upload.name}: {e}")
        if result is not None:
            st.button("Continue from this result in the SMB screen", key="smbview_adopt",
                      on_click=lambda r=result: st.session_state.update(smb_result=r),
                      help="Makes it the 'last SMB run', so the SMB screen can start from its final state.")
else:
    result = st.session_state.get("smb_result")
if result is None:
    st.info("Run an SMB simulation on the SMB screen, or load an SMB result file.")
    st.stop()

spec, s = result.spec, result.summary
st.caption((f"**{spec.title}** · " if spec.title else "")
           + f"{spec.layout} · {spec.n_columns} columns ({'-'.join(str(k) for k in spec.columns_per_zone)}) · switch time "
           f"{spec.switch_time:g} min · cycle {spec.cycle_time:g} min · {spec.base.column.model}, "
           f"{spec.base.binding.model} · completed {s.get('completed', '').replace('T', ' ')}")
smb_views.metrics(result)

tabs = st.tabs(["Outlets", "Cycles", "Column profiles", "Process animation", "Export"])

with tabs[0]:
    names = [comp.name for comp in result.components]
    labels = {o: smb.STREAM_LABELS[o] for o in result.outlets}
    c = st.columns([3, 3, 2])
    shown = c[0].multiselect("Outlets", list(result.outlets), default=spec.geometry.products,
                             format_func=labels.get, key="smbview_outlets")
    chosen = c[1].multiselect("Components", names, default=[names[i] for i in result.solutes()],
                              key="smbview_comps")
    whole = c[2].toggle("All cycles", value=False, key="smbview_all")
    d = st.columns([2, 2, 2, 3])
    curve = d[0].checkbox("Concentration", value=True, key="smbview_curve")
    averages = d[1].checkbox("Average concentration", value=True, key="smbview_avg",
                             help="Average concentration of every switch interval (a point in its middle): what a "
                                  "fraction collected over that switch would contain.")
    per_row = d[2].radio("Plots per row", [1, 2, 3], index=1, horizontal=True, key="smbview_per_row")
    height = d[3].slider("Plot height [px]", 220, 700, 340, step=20, key="smbview_height")
    idx = [names.index(n) for n in chosen]
    if not shown:
        st.info("Choose one or more outlets.")
    else:
        smb_views.outlet_grid(result, shown, per_row=per_row, key="smbview_outlet", last_cycle=not whole,
                              components=idx, height=height, curve=curve, averages=averages)
        st.caption("Solid lines: concentration; points joined by dashed lines: average concentration of each "
                   "switch interval."
                   + (" Dotted lines: cycle boundaries." if whole else ""))
    if result.column_outlets is not None:
        with st.expander("Outlet of a single column"):
            j = st.selectbox("Column", range(spec.n_columns), format_func=lambda j: f"column {j + 1}",
                             key="smbview_col")
            import plotly.graph_objects as go
            fig = go.Figure()
            for i in idx:
                fig.add_trace(go.Scatter(x=result.time, y=result.column_outlets[j, :, i], mode="lines",
                                         name=names[i]))
            fig.update_layout(xaxis_title="time [min]", height=320, margin=dict(l=10, r=10, t=30, b=10))
            st.plotly_chart(fig, width="stretch", key="smbview_colfig")
            st.caption("The column moves through all zones, one position per switch.")

with tabs[1]:
    st.plotly_chart(smb_views.convergence_figure(result), width="stretch", key="smbview_conv")
    table = sr.cycle_table(result)
    shown = table.copy()
    for col in shown.columns:
        if col.startswith(("purity", "recovery")):
            shown[col] = 100 * shown[col]
    shown = shown.rename(columns=lambda c: c + " [%]" if c.startswith(("purity", "recovery")) else c)
    st.dataframe(shown.style.format("{:.4g}"), width="stretch")
    st.caption("Amounts in mol per cycle. At cyclic steady state the amount fed in a cycle leaves in the same cycle.")

with tabs[2]:
    phases = result.phases()
    if not phases:
        st.info("This run has no recorded column profiles.")
    else:
        pt = result.profile_time
        nt = len(pt)
        K = "smbview_k"
        st.session_state[K] = min(st.session_state.get(K, 0), nt - 1)
        cycle_t, switch_t = spec.cycle_time, spec.switch_time

        def _at(t):
            return int(np.clip(np.searchsorted(pt, t - 1e-9), 0, nt - 1))

        def _step(delta=None, to=None, by=None):
            i = st.session_state.get(K, 0)
            if to is not None:
                st.session_state[K] = to
            elif by is not None:               # jump to the next / previous switch or cycle boundary
                t, step = pt[i], by[1]
                boundary = (np.floor(t / step + 1e-9) + (1 if by[0] > 0 else -1)) * step
                if by[0] < 0 and t - np.floor(t / step + 1e-9) * step > 1e-9:
                    boundary = np.floor(t / step + 1e-9) * step   # first back to the start of this one
                st.session_state[K] = _at(boundary)
            else:
                st.session_state[K] = int(np.clip(i + delta, 0, nt - 1))

        c = st.columns([1, 1, 1, 1, 1, 1, 1, 1, 8], vertical_alignment="center")
        steps = [("first_page", "smbview_first", {"to": 0}, "Start of the run"),
                 ("skip_previous", "smbview_prev_cycle", {"by": (-1, cycle_t)}, "One cycle back"),
                 ("keyboard_double_arrow_left", "smbview_prev_switch", {"by": (-1, switch_t)}, "One switch back"),
                 ("chevron_left", "smbview_prev", {"delta": -1}, "Previous profile time"),
                 ("chevron_right", "smbview_next", {"delta": 1}, "Next profile time"),
                 ("keyboard_double_arrow_right", "smbview_next_switch", {"by": (1, switch_t)}, "One switch forward"),
                 ("skip_next", "smbview_next_cycle", {"by": (1, cycle_t)}, "One cycle forward"),
                 ("last_page", "smbview_last", {"to": nt - 1}, "End of the run")]
        for col, (icon, key, kwargs, tip) in zip(c, steps):
            col.button("", icon=f":material/{icon}:", key=key, on_click=_step, kwargs=kwargs, help=tip)
        c[8].select_slider("Time", options=range(nt), key=K, label_visibility="collapsed",
                           format_func=lambda i: f"t = {pt[i]:.4g} min")
        k = st.session_state[K]
        cyc = min(int(pt[k] // cycle_t), result.n_cycles - 1)
        d = st.columns([3, 3, 2, 3], vertical_alignment="center")
        phase = d[0].selectbox("Phase", phases, format_func=PHASE_LABELS.get, key="smbview_phase")
        span = d[1].radio("Play", ["This cycle", "Whole run"], horizontal=True, key="smbview_play_span",
                          help="What the ▶ buttons under the plot play through.")
        fixed = d[2].toggle("Fixed y-axis", value=True, key="smbview_fixed",
                            help="Same y range for all times (for animation). Off: fit the current time.")
        d[3].markdown(f"**Cycle {cyc + 1}** of {result.n_cycles} · switch "
                      f"{int((pt[k] - cyc * cycle_t) // switch_t) % spec.n_columns + 1} of {spec.n_columns}")
        names = [comp.name for comp in result.components]
        shown_comps = [names.index(n) for n in st.session_state.get("smbview_comps", [names[i] for i in result.solutes()])]
        frame_range = (0, nt - 1) if span == "Whole run" else (_at(cyc * cycle_t), _at((cyc + 1) * cycle_t))
        st.plotly_chart(smb_views.ring_figure(result, phase, k, components=shown_comps, fixed_y=fixed,
                                              frame_range=frame_range), width="stretch", key="smbview_ring")
        stride = s.get("profile_stride", 1)
        with st.expander("💾 Save the animation as MP4 / GIF"):
            v = st.columns([2, 2, 2, 2, 1], vertical_alignment="bottom")
            fmt = v[0].selectbox("Format", animation.VIDEO_FORMATS, format_func=str.upper, key="smbview_video_fmt")
            fps = v[1].number_input("Frames per second", min_value=1, max_value=60, value=10, key="smbview_video_fps")
            n_frames = v[2].number_input("Frames", min_value=10, max_value=2000, value=200, step=10,
                                         key="smbview_video_frames", help="Evenly spaced over the range")
            video_span = v[3].radio("Range", ["This cycle", "Whole run"], key="smbview_video_span")
            if v[4].button("Create", key="smbview_video_create"):
                try:
                    with st.spinner(f"Encoding {fmt.upper()}…"):
                        rng = (0, nt - 1) if video_span == "Whole run" else (_at(cyc * cycle_t),
                                                                            _at((cyc + 1) * cycle_t))
                        data = smb_media.ring_video(result, phase, shown_comps, SERIES_COLORS, fmt=fmt, fps=int(fps),
                                                    max_frames=int(n_frames), fixed_y=fixed, frame_range=rng)
                    st.session_state["smbview_video"] = {"fmt": fmt, "phase": phase, "data": data, "for": result}
                except (ValueError, OSError, RuntimeError) as e:
                    st.error(f"Could not create the animation: {e}")
            video = st.session_state.get("smbview_video")
            if video and video["for"] is result:
                if video["fmt"] == "mp4":
                    st.video(video["data"], format="video/mp4")
                else:
                    st.image(video["data"])
                st.download_button(f"💾 Download {video['fmt'].upper()}", video["data"],
                                   f"smb_ring_{video['phase']}.{video['fmt']}",
                                   "video/mp4" if video["fmt"] == "mp4" else "image/gif", key="smbview_video_dl")
        st.caption("Column profiles from the first cycle to the last"
                   + (f" (every {stride}. output time, i.e. every {stride * spec.base.settings.output_interval:.3g} min)"
                      if stride > 1 else "") + ". ▶ 1x / 2x / 5x play this cycle or the whole run in the browser; the "
                   "buttons above step one profile time, one switch or one cycle. Along the ring from the eluent port "
                   "(zone I first); the column labels show which physical column is at each position.")

with tabs[3]:
    total = st.radio("Animate", ["One cycle", "Whole run"], horizontal=True, key="smbview_anim_span")
    span = spec.cycle_time if total == "One cycle" else result.time[-1]
    st.iframe(smb_animation.process_html(spec, span), height=smb_animation.HEIGHT)   # our own HTML (numbers from the spec only)
    st.caption("The columns stay in place; the ports move one column "
               "forward every switch. Colours mark the zone each column is in.")
    smb_views.layout_images(spec, "smbview_layout")

with tabs[4]:
    c = st.columns([2, 3], vertical_alignment="center")
    include = c[1].checkbox("Include ring profiles (bulk / pore / solid)", key="smbview_xlsx_profiles")
    cached = st.session_state.get("smbview_xlsx")
    if cached is None or cached[0] is not result or cached[1] != include:
        created = datetime.now()
        cached = (result, include, smb_excel.build_workbook(result, include_profiles=include, created=created),
                  smb_excel.export_filename(result, created))
        st.session_state["smbview_xlsx"] = cached
    c[0].download_button("📊 Excel workbook (all data)", cached[2], cached[3],
                         "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", key="smbview_xlsx_btn",
                         help="Summary, data, cycles, charts, column outlets, inputs.")
    d = st.columns(3)
    d[0].download_button("💾 Outlets CSV", result.outlet_dataframe().to_csv(index=False), "smb_outlets.csv",
                         "text/csv", key="smbview_csv")
    d[1].download_button("💾 Cycles CSV", sr.cycle_table(result).to_csv(), "smb_cycles.csv", "text/csv",
                         key="smbview_cycles_csv")
    if st.session_state.get("smbview_h5_for") is not result:
        st.session_state["smbview_h5"] = sr.save_h5(result)
        st.session_state["smbview_h5_for"] = result
        st.session_state["smbview_h5_stamp"] = stamped(spec.title, sr.EXTENSION, datetime.now(), "smb_result")
    default_name = st.session_state["smbview_h5_stamp"]
    d[2].download_button(f"💾 Result file (.{sr.EXTENSION})", st.session_state["smbview_h5"], default_name,
                         "application/x-hdf5", key="smbview_h5_btn",
                         help="Reopen here, or load it on the SMB screen to restore the input. An HDF5 file with its "
                              "own extension (.smbh5) so it is not mixed up with Batch results (.h5).")
    save_panel.folder_save("smbview_h5", st.session_state["smbview_h5"], default_name.rsplit(".", 1)[0], sr.EXTENSION,
                           label="Save the result file with a chosen name and folder")
