@echo off
rem CADET GUI: installs (first time) or updates (later) the app's conda environment. Double-click this file.
rem Everything goes into %USERPROFILE%\.cadet_gui (or %CADET_GUI_HOME%); nothing else on the computer is changed.
setlocal
cd /d "%~dp0"
call :paths
set /p VERSION=<VERSION
echo CADET GUI %VERSION% - installing into %ROOT%
if exist "%MINIFORGE%\Scripts\conda.exe" goto :env
if not exist "%ROOT%" mkdir "%ROOT%"
echo Downloading Miniforge...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing -Uri 'https://github.com/conda-forge/miniforge/releases/latest/download/Miniforge3-Windows-x86_64.exe' -OutFile '%ROOT%\miniforge.exe'"
if errorlevel 1 goto :fail
echo Installing Miniforge (a minute or two)...
start /wait "" "%ROOT%\miniforge.exe" /InstallationType=JustMe /RegisterPython=0 /AddToPath=0 /S /D=%MINIFORGE%
del "%ROOT%\miniforge.exe"
if not exist "%MINIFORGE%\Scripts\conda.exe" goto :fail
:env
if exist "%ENV_DIR%\conda-meta" goto :update
echo Creating the app environment (CADET, Python packages; about 1 GB, 5-15 minutes)...
call "%MINIFORGE%\Scripts\conda.exe" env create -p "%ENV_DIR%" -f environment.yml
if errorlevel 1 goto :fail
goto :check
:update
echo Updating the app environment...
call "%MINIFORGE%\Scripts\conda.exe" env update -p "%ENV_DIR%" -f environment.yml --prune
if errorlevel 1 goto :fail
:check
echo Checking the installation...
call "%MINIFORGE%\Scripts\activate.bat" "%ENV_DIR%"
python -c "from core.simulator import cadet_root; from core import __version__; print('CADET GUI', __version__, '- CADET found in', cadet_root())"
if errorlevel 1 goto :fail
echo.
echo Installation finished. Start the app with run.bat.
pause
exit /b 0
:fail
echo.
echo Installation failed - see the messages above.
pause
exit /b 1
:paths
rem The same folders as run.bat. conda cannot install into paths with spaces: fall back to C:\cadet_gui.
if defined CADET_GUI_HOME (set "ROOT=%CADET_GUI_HOME%") else (set "ROOT=%USERPROFILE%\.cadet_gui")
if not "%ROOT%"=="%ROOT: =%" set "ROOT=%SystemDrive%\cadet_gui"
set "MINIFORGE=%ROOT%\miniforge"
set "ENV_DIR=%ROOT%\env"
exit /b 0
