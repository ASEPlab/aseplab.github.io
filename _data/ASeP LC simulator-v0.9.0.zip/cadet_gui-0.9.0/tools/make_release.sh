#!/bin/bash
# Builds dist/cadet_gui-<version>.zip from the last commit (what collaborators download and unzip).
set -euo pipefail
cd "$(dirname "$0")/.."
VERSION="$(cat VERSION)"
if [ -n "$(git status --porcelain)" ]; then echo "Commit your changes first (the zip is built from the last commit)."; exit 1; fi
mkdir -p dist
git archive --format=zip --prefix="cadet_gui-$VERSION/" -o "dist/cadet_gui-$VERSION.zip" HEAD
echo "dist/cadet_gui-$VERSION.zip"
