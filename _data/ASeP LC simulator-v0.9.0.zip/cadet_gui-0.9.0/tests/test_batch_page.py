"""Headless tests of the Batch page: running, progress, sequential runs, examples."""
from pathlib import Path

import numpy as np
import pytest
from streamlit.testing.v1 import AppTest

from core import model_builder as mb
from core.examples import EXAMPLES

PAGE = Path(__file__).resolve().parents[1] / "pages" / "1_Batch.py"
GIEX_EXAMPLE, LIGAND_EXAMPLE = list(EXAMPLES)[1], list(EXAMPLES)[2]


def run_simulation(at):
    """Click Run, wait for the background job, and rerun so the page collects the result."""
    next(b for b in at.button if "Run simulation" in b.label).click().run()
    if "batch_job" in at.session_state:         # a fast failure may already be collected
        at.session_state["batch_job"].wait()
        at.run()
    return at


def load_example(at, name):
    at.selectbox(key="example_choice").set_value(name).run()
    next(b for b in at.button if b.label == "Load example").click().run()
    assert not at.exception
    return at


@pytest.fixture(scope="module")
def app():
    return AppTest.from_file(str(PAGE), default_timeout=120).run()


@pytest.mark.parametrize("model", mb.COLUMN_MODELS)
def test_run_each_model(app, model):
    app.radio(key="col_model").set_value(model).run()
    run_simulation(app)
    assert not app.exception
    assert not app.error
    result = app.session_state["batch_result"]
    assert result.summary["exit_flag"] == 0
    assert result.spec.column.model == model
    assert result.outlet.max() > 0


@pytest.mark.parametrize("model", mb.COLUMN_MODELS)
def test_correlation_mode(app, model):
    app.radio(key="col_model").set_value(model).run()
    app.radio(key="mt_method").set_value("Correlation estimate").run()
    assert not app.exception
    run_simulation(app)
    assert not app.exception and not app.error
    result = app.session_state["batch_result"]
    assert result.spec.correlation is not None
    assert result.spec.column.axial_dispersion == pytest.approx(0.0316, rel=0.01)   # Chung & Wen, default case
    assert result.summary["exit_flag"] == 0
    app.radio(key="mt_method").set_value("Direct input").run()


@pytest.mark.parametrize("kinetic", [False, True])
def test_giex_example(kinetic):
    at = load_example(AppTest.from_file(str(PAGE), default_timeout=120).run(), GIEX_EXAMPLE)
    at.toggle(key="binding_kinetic").set_value(kinetic).run()
    assert not at.exception and not at.error
    run_simulation(at)
    assert not at.exception and not at.error
    result = at.session_state["batch_result"]
    assert [c.name for c in result.components] == ["salt", "pH", "M1", "M2"]
    assert result.summary["exit_flag"] == 0
    # both metals elute in the salt gradient (5–25 min), M1 (lower K) first
    t = result.time
    peak = {i: t[result.outlet[:, i].argmax()] for i in (2, 3)}
    assert 5 < peak[2] < peak[3] < 40


def test_giex_ligand_example():
    at = load_example(AppTest.from_file(str(PAGE), default_timeout=120).run(), LIGAND_EXAMPLE)
    assert not at.error
    run_simulation(at)
    assert not at.exception and not at.error
    r = at.session_state["batch_result"]
    assert [c.name for c in r.components] == ["salt", "pH", "M1", "M2", "L", "M1L", "M2L"]
    assert len(r.spec.reactions.reactions) == 2
    # total metal (free + complex) eluted equals the loaded amount (1 mmol/L for 1 min at 1 mL/min)
    t = r.time
    for free, cplx in ((2, 5), (3, 6)):
        eluted = np.trapezoid(r.outlet[:, free] + r.outlet[:, cplx], t)   # (mmol/L)·min
        assert eluted == pytest.approx(1.0, rel=2e-2)


def test_ecv_toggle(app):
    app.radio(key="col_model").set_value("LRMP").run()
    app.toggle(key="op_ecv").set_value(True).run()
    app.number_input(key="op_Vd").set_value(1.5).run()
    run_simulation(app)
    assert not app.exception and not app.error
    assert app.session_state["batch_result"].spec.operation.dead_volume == 1.5
    app.toggle(key="op_ecv").set_value(False).run()


def test_progress_and_cancel():
    at = AppTest.from_file(str(PAGE), default_timeout=120).run()
    at.number_input(key="sim_ncol").set_value(1500).run()       # slow enough to catch it running
    next(b for b in at.button if "Run simulation" in b.label).click().run()
    job = at.session_state["batch_job"]
    assert not job.done
    assert any(b.label == "■ Cancel" for b in at.button)
    assert next(b for b in at.button if "Run simulation" in b.label).disabled
    next(b for b in at.button if b.label == "■ Cancel").click().run()
    job.wait()
    at.run()
    assert job.status == "cancelled"
    assert "cancelled" in at.error[0].value
    assert "batch_job" not in at.session_state


def test_sequential_run_and_log(isolated_config):
    at = AppTest.from_file(str(PAGE), default_timeout=120).run()
    at.radio(key="col_model").set_value("LRMP").run()
    run_simulation(at)
    first = at.session_state["batch_result"]
    at.radio(key="init_state_source").set_value("Final state of the last run").run()
    assert not at.error
    run_simulation(at)
    second = at.session_state["batch_result"]
    assert second.spec.initial_state_source.startswith("end of a LRMP run")
    assert second is not first
    logs = sorted((isolated_config / "logs").glob("*_simulation.json"))
    assert len(logs) >= 2
    assert any("Log saved to" in c.value for c in at.caption)
    # changing the structure makes the saved state unusable
    at.number_input(key="sim_ncol").set_value(50).run()
    assert any("does not fit" in e.value for e in at.error)
    at.radio(key="init_state_source").set_value("Fresh column").run()
    at.number_input(key="sim_ncol").set_value(100).run()


def test_giex_needs_initial_salt_and_ph():
    at = load_example(AppTest.from_file(str(PAGE), default_timeout=120).run(), GIEX_EXAMPLE)
    initial = at.session_state["initial"]
    assert initial.loc["salt", "c0"] == 50.0 and initial.loc["pH", "c0"] == 7.0
    run_simulation(at)
    assert at.session_state["batch_result"].spec.column.initial_liquid[:2] == [50.0, 7.0]
    df = at.session_state["initial"].copy()
    df.loc["salt", "c0"] = 0.0
    at.session_state["initial"] = df
    at.session_state["initial__version"] = at.session_state["initial__version"] + 1
    at.run()
    next(b for b in at.button if "Run simulation" in b.label).click().run()
    if "batch_job" in at.session_state:         # a validation failure may already be collected
        at.session_state["batch_job"].wait()
        at.run()
    assert any("initial salt" in e.value for e in at.error)


def test_title_is_kept_in_the_input_and_the_result():
    at = AppTest.from_file(str(PAGE), default_timeout=120).run()
    at.text_input(key="form_title").set_value("Title A").run()
    run_simulation(at)
    assert not at.exception and at.session_state["batch_result"].spec.title == "Title A"
    load_example(at, list(EXAMPLES)[0])
    assert at.text_input(key="form_title").value == "Two components, Langmuir"
