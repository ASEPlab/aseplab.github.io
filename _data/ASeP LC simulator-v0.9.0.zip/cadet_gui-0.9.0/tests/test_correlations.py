"""Correlations and dimensionless groups, checked against independent SI calculations."""
import numpy as np
import pytest

from core import correlations as cor
from core import dimensionless as dl
from core import model_builder as mb

# SI reference case: Q = 1 mL/min, D = 1 cm, R = 25 µm, εb = 0.37, water at 25 °C
Q_SI = 1e-6 / 60
A_SI = np.pi * 0.01 ** 2 / 4
EPS_B, EPS_P = 0.37, 0.5
DP_SI = 50e-6
MU, RHO = 0.89e-3, 997.0
DM_SI = 1e-9
US_SI = Q_SI / A_SI
FLUID = cor.Fluid(viscosity=0.89, density=0.997)
TO_CM2_MIN = 1e4 * 60
TO_CM_MIN = 100 * 60


def test_reynolds_schmidt():
    assert cor.reynolds(25.0, US_SI * TO_CM_MIN, FLUID) == pytest.approx(DP_SI * RHO * US_SI / MU)
    assert cor.schmidt(DM_SI * TO_CM2_MIN, FLUID) == pytest.approx(MU / (RHO * DM_SI))


def test_chung_wen_and_wilson_geankoplis():
    est = cor.estimate(1.0, 1.0, 25.0, EPS_B, EPS_P, [DM_SI * TO_CM2_MIN], FLUID)
    re = DP_SI * RHO * US_SI / MU
    u = US_SI / EPS_B
    eb = DP_SI * u * EPS_B / (0.2 + 0.011 * re ** 0.48)
    assert est.axial_dispersion == pytest.approx(eb * TO_CM2_MIN)
    # Sherwood form of Wilson & Geankoplis: Sh = (1.09/εb)·(Re·Sc)^(1/3)
    sh = est.film_diffusion[0] / TO_CM_MIN * DP_SI / DM_SI
    assert sh == pytest.approx(1.09 / EPS_B * (re * MU / (RHO * DM_SI)) ** (1 / 3))
    assert est.u == pytest.approx(u * TO_CM_MIN)
    assert est.warnings == []          # Re ≈ 0.012 is within range


def test_wilson_geankoplis_range_warning():
    est = cor.estimate(1000.0, 1.0, 500.0, EPS_B, EPS_P, [6e-4], FLUID)
    assert est.re > 55 and "outside" in est.warnings[0]


def test_glueckauf():
    kf, dpore = 0.06, 1e-4                 # cm/min, cm²/min
    r_cm = 25e-4
    expected = 1 / (1 / kf + r_cm / (5 * EPS_P * dpore))
    assert cor.glueckauf(kf, 25.0, EPS_P, dpore) == pytest.approx(expected)
    est = cor.estimate(1.0, 1.0, 25.0, EPS_B, EPS_P, [6e-4, 6e-4], FLUID, dp_cm2_min=[dpore, 2 * dpore])
    assert est.keff[1] > est.keff[0]


def test_wilke_chang():
    # Water, 25 °C, V_A = 37 cm³/mol: 7.4e-8·√(2.6·18.015)·298.15 / (0.89·37^0.6) cm²/s
    expected = 7.4e-8 * np.sqrt(2.6 * 18.015) * 298.15 / (0.89 * 37 ** 0.6) * 60
    assert cor.wilke_chang(37.0, 25.0, FLUID) == pytest.approx(expected)
    assert cor.wilke_chang(37.0, 25.0, FLUID) == pytest.approx(1.944e-5 * 60, rel=1e-3)


def test_estimate_rejects_bad_dm():
    with pytest.raises(ValueError, match="Dm"):
        cor.estimate(1.0, 1.0, 25.0, EPS_B, EPS_P, [None], FLUID)


def test_dimensionless_groups():
    col = mb.ColumnSpec(model="GRM", length=10.0, diameter=1.0, eps_b=EPS_B, eps_p=EPS_P, radius=25.0,
                        axial_dispersion=6e-3, film_diffusion=[0.06], pore_diffusion=[1e-4])
    g = dl.groups(col, 1.0)
    u = 1.0 / (EPS_B * np.pi / 4)
    R, L = 25e-4, 10.0
    assert g["1/Pe"][0] == pytest.approx(6e-3 / (u * L))
    assert g["Nf"][0] == pytest.approx(3 * (L / R) * (1 - EPS_B) * 0.06 / (EPS_B * u))
    assert g["ND"][0] == pytest.approx((1 - EPS_B) * EPS_P * L * 1e-4 / (EPS_B * u * R ** 2))
    assert g["Bi"][0] == pytest.approx(g["Nf"][0] / (3 * g["ND"][0]))
    msgs = dl.diagnose(g, ["A"])
    assert any("pore diffusion is rate-limiting" in m for m in msgs)   # Bi = 3 > 1


@pytest.mark.parametrize("model", mb.COLUMN_MODELS)
def test_groups_per_model(model):
    col = mb.ColumnSpec(model=model, film_diffusion=None if model == "LRM" else [0.06, 0.06],
                        pore_diffusion=[1e-4, 1e-4])
    assert tuple(dl.groups(col, 1.0)) == dl.GROUPS_BY_MODEL[model]
