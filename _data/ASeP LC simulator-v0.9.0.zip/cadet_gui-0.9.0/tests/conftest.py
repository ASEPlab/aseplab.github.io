"""Keep test runs from writing logs/results into the repository."""
import pytest

from utils.config import ENV_VAR


@pytest.fixture(autouse=True, scope="session")
def isolated_config(tmp_path_factory):
    root = tmp_path_factory.mktemp("cadet_gui_config")
    cfg = root / "config.yaml"
    cfg.write_text("logs_dir: logs\nresults_dir: results\nauto_save_results: false\n")
    mp = pytest.MonkeyPatch()
    mp.setenv(ENV_VAR, str(cfg))
    yield root
    mp.undo()
