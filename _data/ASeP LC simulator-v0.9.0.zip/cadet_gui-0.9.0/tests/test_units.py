"""Tests for core/units.py (GUI units <-> CADET SI)."""
import numpy as np
import pytest

from core import units as U


def test_basic_factors():
    assert U.length_to_si(10, "cm") == pytest.approx(0.1)
    assert U.radius_to_si(25) == pytest.approx(25e-6)
    assert U.time_to_si(30) == pytest.approx(1800)
    assert U.volume_to_si(2) == pytest.approx(2e-6)
    assert U.flow_to_si(1.0) == pytest.approx(1e-6 / 60)
    assert U.velocity_to_si(60) == pytest.approx(1e-2)          # 60 cm/min = 1 cm/s
    assert U.diffusivity_to_si(1.0) == pytest.approx(1e-4 / 60)


@pytest.mark.parametrize("to_si, from_si, unit", [
    (U.length_to_si, U.length_from_si, "cm"),
    (U.radius_to_si, U.radius_from_si, "um"),
    (U.time_to_si, U.time_from_si, "min"),
    (U.volume_to_si, U.volume_from_si, "mL"),
    (U.flow_to_si, U.flow_from_si, "mL/min"),
    (U.velocity_to_si, U.velocity_from_si, "cm/min"),
    (U.diffusivity_to_si, U.diffusivity_from_si, "cm2/min"),
])
def test_round_trip(to_si, from_si, unit):
    x = np.array([0.0, 1.5, 42.0])
    np.testing.assert_allclose(from_si(to_si(x, unit), unit), x)


def test_unknown_unit_raises():
    with pytest.raises(ValueError):
        U.length_to_si(1, "inch")


def test_liquid_concentrations():
    assert U.liquid_to_si(1, "mol/L") == pytest.approx(1000)
    assert U.liquid_to_si(1, "mmol/L") == pytest.approx(1)
    # Cu²⁺, MW 63.546: 63.546 mg/L = 1 mmol/L
    assert U.liquid_to_si(63.546, "mg/L", mw=63.546) == pytest.approx(1)
    assert U.liquid_to_si(63.546, "g/L", mw=63.546) == pytest.approx(1000)
    # ν = 2: 2 meq/L = 1 mmol/L; sign of ν ignored
    assert U.liquid_to_si(2, "meq/L", charge=2) == pytest.approx(1)
    assert U.liquid_to_si(2, "meq/L", charge=-2) == pytest.approx(1)


def test_liquid_round_trip_and_missing_info():
    c = U.liquid_from_si(U.liquid_to_si(5.0, "mg/L", mw=58.44), "mg/L", mw=58.44)
    assert c == pytest.approx(5.0)
    with pytest.raises(ValueError, match="molecular weight"):
        U.liquid_to_si(1, "mg/L")
    with pytest.raises(ValueError, match="charge"):
        U.liquid_to_si(1, "meq/L", charge=0)
    with pytest.raises(ValueError):
        U.liquid_to_si(1, "mol/mL")


def test_solid_bases():
    # 1 mmol/mL solid = 1 mol/L solid = 1000 mol/m³ solid
    assert U.solid_to_si(1, "mmol/mL solid") == pytest.approx(1000)
    # per mL bed: q_bed = (1 − εt)·q_solid
    eps_t = U.total_porosity(0.35, 0.6)
    q_solid = U.solid_to_si(1, "mmol/mL bed", eps_t=eps_t)
    assert q_solid * (1 - eps_t) == pytest.approx(1000)
    # meq basis for ion-exchange capacity Λ
    assert U.solid_to_si(2, "meq/mL solid", charge=1) == pytest.approx(2000)


def test_g_resin_density_bases_agree():
    """The same resin described by skeletal, particle or packing density gives the same q."""
    eps_b, eps_p = 0.35, 0.6
    eps_t = U.total_porosity(eps_b, eps_p)
    rho_s = 1.5                                   # g/mL solid
    rho_p = rho_s * (1 - eps_p)                   # g/mL particle
    rho_bed = rho_s * (1 - eps_t)                 # g/mL bed
    expected = 1000 * rho_s                       # 1 mmol/g → mol/m³ solid
    assert U.solid_to_si(1, "mmol/g resin", density=rho_s) == pytest.approx(expected)
    assert U.solid_to_si(1, "mmol/g resin", density=rho_p, density_basis="particle",
                         eps_p=eps_p) == pytest.approx(expected)
    assert U.solid_to_si(1, "mmol/g resin", density=rho_bed, density_basis="bed",
                         eps_t=eps_t) == pytest.approx(expected)


def test_solid_round_trip_and_missing_info():
    q = U.solid_from_si(U.solid_to_si(3.0, "mg/mL bed", mw=100, eps_t=0.7),
                        "mg/mL bed", mw=100, eps_t=0.7)
    assert q == pytest.approx(3.0)
    assert U.parse_solid_unit("mg/g resin") == ("mg", "g resin")
    with pytest.raises(ValueError, match="εt"):
        U.solid_to_si(1, "mmol/mL bed")
    with pytest.raises(ValueError, match="density"):
        U.solid_to_si(1, "mmol/g resin")
    with pytest.raises(ValueError, match="εp"):
        U.solid_to_si(1, "mmol/g resin", density=0.6, density_basis="particle")
    with pytest.raises(ValueError):
        U.solid_to_si(1, "mmol/cm3 bed")


def test_isotherm_params_preserve_physics():
    """Evaluating the isotherm in GUI units then converting q must match
    converting the constants and evaluating in SI."""
    f_l = U.liquid_factor("mg/L", mw=63.546)
    f_s = U.solid_factor("mg/mL bed", mw=63.546, eps_t=0.75)
    c_gui, qmax_gui, K_gui, H_gui = 20.0, 50.0, 0.1, 3.0

    # Langmuir: q = qmax·K·c / (1 + K·c), K [1/liquid]
    q_gui = qmax_gui * K_gui * c_gui / (1 + K_gui * c_gui)
    K_si = U.isotherm_param_to_si(K_gui, f_liquid=f_l, liquid_exp=-1)
    c_si, qmax_si = c_gui * f_l, qmax_gui * f_s
    q_si = qmax_si * K_si * c_si / (1 + K_si * c_si)
    assert q_si == pytest.approx(q_gui * f_s)

    # Linear: q = H·c, H [solid/liquid]
    H_si = U.isotherm_param_to_si(H_gui, f_liquid=f_l, f_solid=f_s, liquid_exp=-1, solid_exp=1)
    assert H_si * c_si == pytest.approx(H_gui * c_gui * f_s)

    # Kinetic ka [1/(liquid·time)] round-trip
    ka_si = U.isotherm_param_to_si(2.0, f_liquid=f_l, f_time=U.time_factor("min"),
                                   liquid_exp=-1, time_exp=-1)
    ka_back = U.isotherm_param_from_si(ka_si, f_liquid=f_l, f_time=U.time_factor("min"),
                                       liquid_exp=-1, time_exp=-1)
    assert ka_back == pytest.approx(2.0)


def test_amounts():
    assert U.amount_from_si(1e-6, "umol") == pytest.approx(1.0)
    assert U.amount_from_si(1e-3, "mg", mw=63.546) == pytest.approx(63.546)
    assert U.amount_from_si(1e-3, "meq", charge=2) == pytest.approx(2.0)


def test_velocities_and_porosity():
    # D = 1 cm → A = π/4 cm²; Q = 1 mL/min, εb = 0.35
    A = np.pi / 4
    assert U.superficial_velocity(1.0, 1.0) == pytest.approx(1 / A)
    assert U.interstitial_velocity(1.0, 1.0, 0.35) == pytest.approx(1 / (0.35 * A))
    assert U.total_porosity(0.35, 0.6) == pytest.approx(0.35 + 0.65 * 0.6)
