"""The Batch form: components with +/−, optional sections, salt/pH only for GIEX, input files."""
import json
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from core import examples
from core import model_builder as mb
from core.examples import EXAMPLES
from core.results_io import from_cadet, save_h5
from core.simulator import run_batch
from ui import form_state as fs
from utils import input_files, logger

PAGE = Path(__file__).resolve().parents[1] / "pages" / "1_Batch.py"


def fresh():
    at = AppTest.from_file(str(PAGE), default_timeout=120).run()
    assert not at.exception
    return at


def names(at):
    return [at.session_state[f"comp_{i}_name"] for i in at.session_state["comp_ids"]]


def click(at, label=None, key=None):
    button = next(b for b in at.button if (b.key == key if key else b.label == label))
    button.click().run()
    assert not at.exception
    return at


# --- components: + and − ------------------------------------------------------------------

def test_add_and_remove_components():
    at = fresh()
    assert names(at) == ["A", "B"]
    click(at, key="comp_add")
    assert names(at) == ["A", "B", "C"]
    assert list(at.session_state["inlet"].columns) == ["start [min]", "shape", "A", "B", "C"]
    assert list(at.session_state["binding"].index) == ["A", "B", "C"]
    assert list(at.session_state["mass_transfer"].index) == ["A", "B", "C"]
    first_id = at.session_state["comp_ids"][0]
    click(at, key=f"comp_{first_id}_rm")                               # remove A
    assert names(at) == ["B", "C"]
    assert list(at.session_state["inlet"].columns)[2:] == ["B", "C"]
    assert f"comp_{first_id}_name" not in at.session_state
    assert [c.name for c in at.session_state["form_spec"].components] == ["B", "C"]
    click(at, key="comp_add")                                          # next free name
    assert names(at) == ["B", "C", "A"]
    click(at, key="comp_add")
    assert names(at)[-1] == "D"


def test_last_component_cannot_be_removed():
    at = fresh()
    for i in list(at.session_state["comp_ids"])[1:]:
        click(at, key=f"comp_{i}_rm")
    assert len(names(at)) == 1
    assert next(b for b in at.button if (b.key or "").endswith("_rm")).disabled


def test_duplicate_and_empty_names_are_reported():
    at = fresh()
    i0, i1 = at.session_state["comp_ids"]
    at.text_input(key=f"comp_{i1}_name").set_value("A").run()
    assert any("unique" in e.value for e in at.error) and at.session_state["form_spec"] is None
    at.text_input(key=f"comp_{i1}_name").set_value("  ").run()
    assert any("needs a name" in e.value for e in at.error)
    at.text_input(key=f"comp_{i1}_name").set_value("B").run()
    assert not at.error and at.session_state["form_spec"] is not None


def test_added_component_runs():
    at = fresh()
    click(at, key="comp_add")
    at.radio(key="col_model").set_value("LRMP").run()
    spec = at.session_state["form_spec"]
    assert [c.name for c in spec.components] == ["A", "B", "C"]
    assert len(spec.binding.equilibrium) == 3
    mb.build_process(spec)


# --- reactions are optional ---------------------------------------------------------------

def test_reaction_inputs_appear_with_the_checkbox():
    at = fresh()
    assert at.session_state["form_spec"].reactions is None
    assert "rx_basis" not in [s.key for s in at.selectbox]
    at.toggle(key="rx_enabled").set_value(True).run()
    assert "rx_basis" in [s.key for s in at.selectbox]
    assert at.session_state["form_spec"].reactions is None             # nothing entered yet
    at.session_state["reactions"] = fs.reaction_table([("A = B", 0.1, 0.05)])
    at.session_state["reactions__version"] += 1
    at.run()
    reactions = at.session_state["form_spec"].reactions
    assert reactions.reactions[0].equation == "A = B" and reactions.reactions[0].k_bwd == 0.05
    at.toggle(key="rx_enabled").set_value(False).run()
    assert at.session_state["form_spec"].reactions is None
    assert "rx_basis" not in [s.key for s in at.selectbox]


# --- salt and pH only when GIEX needs them ------------------------------------------------

def test_salt_and_ph_appear_only_for_giex():
    at = fresh()
    assert all(n not in at.session_state["inlet"].columns for n in ("salt", "pH"))
    assert "giex_salt_unit" not in [s.key for s in at.selectbox]
    at.radio(key="binding_model").set_value("GIEX").run()
    assert "giex_salt_unit" in [s.key for s in at.selectbox]
    for key in ("inlet",):
        assert {"salt", "pH"} <= set(at.session_state[key].columns)
    for key in ("mass_transfer", "initial"):
        assert list(at.session_state[key].index)[:2] == ["salt", "pH"]
    assert list(at.session_state["binding"].index) == ["A", "B"]       # no isotherm values for salt / pH
    inlet = at.session_state["inlet"]
    assert (inlet["salt"] == 50.0).all() and (inlet["pH"] == 7.0).all()
    assert at.session_state["initial"].loc["salt", "c0"] == 50.0
    spec = at.session_state["form_spec"]
    assert [c.name for c in spec.components] == ["salt", "pH", "A", "B"]
    assert spec.components[0].charge == 1.0 and spec.components[1].liquid_unit == "pH"
    # a solute may not take the reserved names
    i0 = at.session_state["comp_ids"][0]
    at.text_input(key=f"comp_{i0}_name").set_value("salt").run()
    assert any("reserved" in e.value or "GIEX" in e.value for e in at.error)
    at.text_input(key=f"comp_{i0}_name").set_value("A").run()
    at.radio(key="binding_model").set_value("Langmuir").run()
    assert all(n not in at.session_state["inlet"].columns for n in ("salt", "pH"))
    assert [c.name for c in at.session_state["form_spec"].components] == ["A", "B"]


def test_giex_values_survive_switching_the_binding_model():
    at = fresh()
    at.radio(key="binding_model").set_value("GIEX").run()
    at.number_input(key="giex_capacity").set_value(2.5).run()
    at.radio(key="binding_model").set_value("Linear").run()
    at.radio(key="binding_model").set_value("GIEX").run()
    assert at.number_input(key="giex_capacity").value == 2.5


# --- input files: save, load, round trip ------------------------------------------------------

def _load_script():
    import streamlit as st

    from ui import batch_form
    if "loaded" not in st.session_state:
        st.session_state["loaded"] = True
        batch_form.load_input_into_form(st.session_state["data"], "test.json")
    batch_form.render()


def load_bytes(data):
    at = AppTest.from_function(_load_script, default_timeout=120)
    at.session_state["data"] = data
    at.run()
    assert not at.exception
    return at


@pytest.mark.parametrize("name", list(EXAMPLES))
def test_examples_survive_save_and_load(name):
    spec = EXAMPLES[name]()
    at = load_bytes(input_files.save_input(spec))
    assert at.session_state["input_msg"][0] == "success"
    assert at.session_state["form_spec"] == spec
    assert not at.error


def drive_variants():
    """Form states built by driving the widgets (correlation, ECV, g resin, LRM, reactions, ...)."""
    a = fresh()                                                           # correlation + Glueckauf
    a.radio(key="col_model").set_value("LRM_keff").run()
    a.radio(key="mt_method").set_value("Correlation estimate").run()
    a.number_input(key="mt_mu").set_value(1.1).run()
    yield "correlation LRM_keff", a

    b = fresh()                                                           # ECV, g resin, LRM, manual εt
    b.radio(key="col_model").set_value("LRM").run()
    b.toggle(key="col_eps_t_manual").set_value(True).run()
    b.number_input(key="col_eps_t").set_value(0.7).run()
    b.toggle(key="op_ecv").set_value(True).run()
    b.number_input(key="op_Vd").set_value(0.3).run()
    b.number_input(key="comp_0_mw").set_value(100.0).run()
    b.selectbox(key="comp_0_su").set_value("mg/g resin").run()
    b.number_input(key="resin_density").set_value(1.4).run()
    b.selectbox(key="resin_density_basis").set_value("particle").run()
    yield "LRM, ECV, g resin", b

    c = fresh()                                                           # reactions + manual tolerances
    c.toggle(key="rx_enabled").set_value(True).run()
    c.session_state["reactions"] = fs.reaction_table([("A = B", 0.1, 0.05)])
    c.session_state["reactions__version"] += 1
    c.run()
    c.radio(key="sim_tol_mode").set_value("manual").run()
    c.text_input(key="sim_reltol").set_value("1.2345e-5").run()
    yield "reactions, manual tolerances", c

    d = load_example_page(LIGAND := list(EXAMPLES)[2])                    # GIEX + ligand, kinetic, advanced
    d.toggle(key="binding_kinetic").set_value(True).run()
    d.toggle(key="giex_advanced").set_value(True).run()
    d.selectbox(key="giex_salt_unit").set_value("mol/L").run()
    yield "GIEX ligand kinetic", d


def load_example_page(name):
    at = fresh()
    at.selectbox(key="example_choice").set_value(name).run()
    click(at, "Load example")
    return at


@pytest.mark.parametrize("index", range(4))
def test_form_state_survives_save_and_load(index):
    label, source = list(drive_variants())[index]
    assert not source.error, label
    spec1 = source.session_state["form_spec"]
    assert spec1 is not None, label
    spec2 = load_bytes(input_files.save_input(spec1)).session_state["form_spec"]
    assert spec2 == spec1, label


def test_loading_resets_everything_not_in_the_file():
    """A plain input loaded after a GIEX one must not keep GIEX leftovers."""
    giex_file = input_files.save_input(EXAMPLES[GIEX_NAME]())

    def script():
        import streamlit as st

        from ui import batch_form
        if "step" not in st.session_state:
            st.session_state["step"] = 1
            batch_form.load_input_into_form(st.session_state["giex_data"], "giex.json")
        elif st.session_state["step"] == 1:
            st.session_state["step"] = 2
            batch_form.load_input_into_form(st.session_state["plain_data"], "plain.json")
        batch_form.render()

    at = AppTest.from_function(script, default_timeout=120)
    at.session_state["giex_data"] = giex_file
    at.session_state["plain_data"] = input_files.save_input(examples.default())
    at.run()
    assert [c.name for c in at.session_state["form_spec"].components] == ["salt", "pH", "M1", "M2"]
    at.run()
    assert at.session_state["form_spec"] == examples.default()
    assert not at.error


GIEX_NAME = list(EXAMPLES)[1]


def test_run_log_and_result_file_reopen_the_input(tmp_path):
    spec = examples.default()
    spec.column.model = "LRMP"
    spec.column.pore_diffusion = None
    log = json.dumps(logger.build_log(spec)).encode()
    assert load_bytes(log).session_state["form_spec"] == spec
    path = logger.write_log(tmp_path, spec)
    assert load_bytes(path.read_bytes()).session_state["form_spec"] == spec
    result = from_cadet(run_batch(spec), spec)
    assert load_bytes(save_h5(result)).session_state["form_spec"] == spec


@pytest.mark.parametrize("data, text", [
    (b"not json at all", "not an input file"),
    (b'{"hello": 1}', "not a CADET GUI input file"),
    (b'{"format": "cadet_gui.input", "version": 1, "spec": {"components": []}}', "incomplete"),
])
def test_bad_files_are_refused_and_keep_the_form(data, text):
    at = load_bytes(data)
    kind, message = at.session_state["input_msg"]
    assert kind == "error" and text in message
    assert at.session_state["form_spec"] == examples.default()


def test_unsupported_inlet_is_refused():
    spec = examples.default()
    spec.operation.inlet = [mb.InletSegment(0.0, [[1.0, 0.0, 0.5, 0.0], [0.0]])]      # quadratic
    at = load_bytes(input_files.save_input(spec))
    assert at.session_state["input_msg"][0] == "error"
    assert "inlet table" in at.session_state["input_msg"][1]
    assert at.session_state["form_spec"] == examples.default()


# --- injection, inlet graph, renamed option -----------------------------------------------------

def charts(at):
    return at.get("plotly_chart")


def test_injection_inputs_and_inlet_graph():
    at = fresh()
    spec = at.session_state["form_spec"]
    assert spec.operation.injection.volume == 0.5 and len(charts(at)) >= 1           # the inlet graph
    assert "inj_volume" in [n.key for n in at.number_input]
    assert [(s.start, s.coefficients[0][0]) for s in spec.operation.program()] == [(0.0, 1.0), (0.5, 0.0)]
    at.number_input(key="inj_volume").set_value(2.0).run()
    at.number_input(key="inj_start").set_value(1.0).run()
    program = at.session_state["form_spec"].operation.program()
    assert [(s.start, s.coefficients[0][0]) for s in program] == [(0.0, 0.0), (1.0, 1.0), (3.0, 0.0)]
    at.toggle(key="inj_enabled").set_value(False).run()
    assert at.session_state["form_spec"].operation.injection is None
    assert "inj_volume" not in [n.key for n in at.number_input]
    assert len(charts(at)) >= 1                                                      # the graph stays
    at.toggle(key="inj_enabled").set_value(True).run()
    assert at.number_input(key="inj_volume").value == 2.0                            # values were kept


def test_injection_longer_than_the_run_is_flagged():
    at = fresh()
    at.number_input(key="inj_volume").set_value(100.0).run()                         # 100 mL at 1 mL/min
    assert any("ends at t = 100" in w.value for w in at.warning)
    at.number_input(key="inj_volume").set_value(0.5).run()
    assert not any("simulated time" in w.value for w in at.warning)


def test_giex_graph_has_salt_and_ph_charts_and_feed_defaults():
    at = fresh()
    base = len(charts(at))
    at.radio(key="binding_model").set_value("GIEX").run()
    assert len(charts(at)) == base + 2                                               # salt and pH on their own axes
    feed = at.session_state["injection"]
    assert feed.loc["salt", "feed"] == 50.0 and feed.loc["pH", "feed"] == 7.0    # buffer values for the new rows
    assert feed.loc["A", "feed"] == 1.0                                          # the solute's feed is kept


def test_column_profile_option_name():
    at = fresh()
    assert at.radio(key="init_state_source").options == ["Fresh column", "Final state of the last run",
                                                         "Load column profile"]
    at.radio(key="init_state_source").set_value("Load column profile").run()
    assert not at.exception and not at.error
    assert any(u.label == "Column profile file (.cprofile), or a result file (.h5)" for u in at.get("file_uploader"))


# --- the form survives visits to other pages --------------------------------------------------

def visit(at, page):
    at.switch_page(f"pages/{page}").run()
    assert not at.exception, [e.value for e in at.exception]
    return at


def test_form_survives_other_pages():
    """Streamlit drops a page's widget values while another page runs; the form must come back intact."""
    at = AppTest.from_file(str(PAGE.parents[1] / "app.py"), default_timeout=120).run()
    visit(at, "1_Batch.py")
    at.selectbox(key="example_choice").set_value(list(EXAMPLES)[2]).run()
    click(at, "Load example")
    at.radio(key="col_model").set_value("LRMP").run()
    at.number_input(key="inj_volume").set_value(1.5).run()
    at.toggle(key="binding_kinetic").set_value(True).run()
    at.selectbox(key="giex_salt_unit").set_value("mol/L").run()
    i0 = at.session_state["comp_ids"][0]
    at.text_input(key=f"comp_{i0}_name").set_value("Cu").run()
    at.number_input(key=f"comp_{i0}_mw").set_value(63.5).run()
    click(at, key="comp_add")
    before = at.session_state["form_spec"]
    assert before is not None and before.operation.injection.volume == 1.5
    messages = [e.value for e in at.error]          # renaming M1 breaks the example's reaction: shown both times

    for page in ("3_Results_Viewer.py", "9_Help.py", "3_Results_Viewer.py"):
        visit(at, page)
    visit(at, "1_Batch.py")

    assert [e.value for e in at.error] == messages
    assert at.session_state["form_spec"] == before
    assert at.radio(key="col_model").value == "LRMP"
    assert at.number_input(key="inj_volume").value == 1.5
    assert at.text_input(key=f"comp_{i0}_name").value == "Cu"
    assert at.number_input(key=f"comp_{i0}_mw").value == 63.5
    assert at.selectbox(key="giex_salt_unit").value == "mol/L"
    # the form still works afterwards, including removing a component that existed before the visit
    click(at, key=f"comp_{i0}_rm")
    assert "Cu" not in [c.name for c in at.session_state["form_spec"].components]
    visit(at, "9_Help.py")
    visit(at, "1_Batch.py")
    assert "Cu" not in [c.name for c in at.session_state["form_spec"].components]
    assert f"comp_{i0}_name" not in at.session_state


def test_run_then_open_viewer_and_come_back():
    at = AppTest.from_file(str(PAGE.parents[1] / "app.py"), default_timeout=120).run()
    visit(at, "1_Batch.py")
    at.radio(key="col_model").set_value("LRMP").run()
    click(at, "▶ Run simulation")
    at.session_state["batch_job"].wait()
    at.run()
    assert at.session_state["batch_result"].summary["exit_flag"] == 0
    visit(at, "3_Results_Viewer.py")
    visit(at, "1_Batch.py")
    assert at.radio(key="col_model").value == "LRMP" and at.session_state["batch_result"] is not None
    assert not at.error
    visit(at, "3_Results_Viewer.py")                                  # and the viewer again, with its result
    assert not at.error and at.session_state["batch_result"] is not None


# --- New, component row order, binding models in the form ------------------------------------------

def test_new_clears_the_form_and_the_previous_result():
    at = fresh()
    at.radio(key="col_model").set_value("LRMP").run()
    click(at, key="comp_add")
    at.number_input(key="inj_volume").set_value(2.0).run()
    click(at, "▶ Run simulation")
    at.session_state["batch_job"].wait()
    at.run()
    assert at.session_state["batch_result"] is not None
    click(at, key="new_simulation")
    assert "batch_result" not in at.session_state and "batch_job" not in at.session_state
    assert at.session_state["form_spec"] == examples.default()
    assert at.radio(key="col_model").value == "GRM" and names(at) == ["A", "B"]
    assert not at.error and "Chromatogram" not in [s.value for s in at.subheader]
    assert at.session_state["input_msg"][0] == "success"


def test_new_cancels_a_running_simulation():
    at = fresh()
    at.number_input(key="sim_ncol").set_value(1500).run()
    click(at, "▶ Run simulation")
    job = at.session_state["batch_job"]
    assert not job.done
    click(at, key="new_simulation")
    job.wait()
    assert job.status == "cancelled" and "batch_job" not in at.session_state
    assert at.number_input(key="sim_ncol").value == 100


def test_component_row_puts_units_before_mw_and_charge():
    at = fresh()
    # widgets are drawn in this order: name, liquid unit, solid unit, adsorbs, MW, charge
    keys = [w.key for w in at.main if getattr(w, "key", None) and str(w.key).startswith("comp_0_")]
    order = [k.split("_", 2)[2] for k in keys]
    assert order[:6] == ["name", "lu", "su", "bound", "mw", "charge"]


@pytest.mark.parametrize("model", ["Linear", "Langmuir", "AntiLangmuir", "BiLangmuir", "Freundlich", "SMA", "GIEX"])
def test_every_binding_model_saves_and_loads(model):
    at = fresh()
    at.radio(key="binding_model").set_value(model).run()
    assert not at.exception and not at.error
    if model in ("SMA", "GIEX"):
        for i in at.session_state["comp_ids"]:
            at.number_input(key=f"comp_{i}_charge").set_value(2.0).run()
    at.toggle(key="binding_kinetic").set_value(True).run()
    df = at.session_state["binding"].copy()
    df.loc["A", ["K", "ka", "kd", "n", "k_ldf", "p", "K2", "qmax2", "ka2", "kd2"]] = [0.31, 0.7, 1.9, 1.7, 2.5, -1.0, 0.11,
                                                                                     0.21, 0.4, 3.0]
    at.session_state["binding"] = df
    at.session_state["binding__version"] += 1
    at.run()
    spec1 = at.session_state["form_spec"]
    assert spec1 is not None and spec1.binding.model == model and spec1.binding.kinetic
    spec2 = load_bytes(input_files.save_input(spec1)).session_state["form_spec"]
    assert spec2 == spec1
    if model == "Freundlich":
        assert spec1.binding.exponent == [1.7, 1.0] and spec1.binding.ldf_rate == [2.5, 1.0]
    if model == "AntiLangmuir":
        assert spec1.binding.sign == [-1.0, 1.0]
    if model == "BiLangmuir":
        assert spec1.binding.site2.equilibrium == [0.11, 1.0]
    if model == "SMA":
        assert [c.name for c in spec1.components][0] == "salt" and len(spec1.components) == 3
        assert spec1.binding.giex is not None and spec1.binding.giex.adsorption_ph is None


def test_sma_adds_only_the_salt_component():
    at = fresh()
    at.radio(key="binding_model").set_value("SMA").run()
    assert list(at.session_state["inlet"].columns)[2:] == ["salt", "A", "B"]
    assert list(at.session_state["mass_transfer"].index) == ["salt", "A", "B"]
    assert "pH" not in at.session_state["initial"].index
    at.text_input(key=f"comp_{at.session_state['comp_ids'][0]}_name").set_value("salt").run()
    assert any("reserved" in e.value or "used by" in e.value for e in at.error)


def test_mass_units_without_mw_give_a_message_not_a_crash():
    at = fresh()
    i0, i1 = at.session_state["comp_ids"]
    at.selectbox(key=f"comp_{i0}_lu").set_value("g/L").run()
    assert not at.exception
    assert any("MW" in e.value and "'A'" in e.value for e in at.error) and at.session_state["form_spec"] is None
    at.number_input(key=f"comp_{i0}_mw").set_value(63.5).run()
    assert not at.exception and not at.error and at.session_state["form_spec"] is not None
    at.selectbox(key=f"comp_{i1}_lu").set_value("meq/L").run()                     # needs the charge
    assert any("charge" in e.value.lower() for e in at.error)
    at.number_input(key=f"comp_{i1}_charge").set_value(2.0).run()
    assert not at.exception and not at.error
    at.selectbox(key=f"comp_{i1}_su").set_value("mg/g resin").run()                # solid mass unit needs MW
    assert any("'B'" in e.value for e in at.error)
