"""Freundlich, Anti-Langmuir, Bi-Langmuir and SMA: equilibrium values against their equations,
unit conversion, equality of SMA with GIEX, and input errors."""
import numpy as np
import pytest

from core import model_builder as mb
from core.components import Component, giex_modulators
from core.results_io import from_cadet
from core.simulator import run_batch


def saturate(comps, binding, feed, initial=None, duration=400.0, giex=None, **column):
    """Continuous feed on a short column until saturation; returns the result."""
    n = len(comps)
    spec = mb.BatchSpec(
        comps,
        mb.ColumnSpec(model="LRMP", length=3.0, film_diffusion=[0.5] * n, axial_dispersion=6e-3,
                      initial_liquid=initial, **column),
        binding,
        mb.OperationSpec(1.0, [mb.constant(0.0, feed)]),
        mb.SimulationSettings(duration=duration, output_interval=1.0, n_col=20, timeout=60.0),
    )
    return from_cadet(run_batch(spec), spec)


ABC = [Component("A"), Component("B"), Component("L", bound=False)]
FEED = [2.0, 3.0, 1.0]                       # mmol/L


# --- Freundlich ---------------------------------------------------------------------------------

@pytest.mark.parametrize("kinetic", [False, True])
def test_freundlich_equilibrium(kinetic):
    K, n = [2.0, 1.0], [1.5, 2.0]            # (mmol/mL solid)/(mmol/L)^(1/n)
    binding = mb.BindingSpec("Freundlich", kinetic=kinetic, equilibrium=K + [None], exponent=n + [None],
                             ldf_rate=[60.0, 60.0, None])
    r = saturate(ABC, binding, FEED)
    expected = [k * c ** (1 / ni) for k, ni, c in zip(K, n, FEED[:2])]
    np.testing.assert_allclose(r.solid[-1, 0, :2], expected, rtol=1e-3)
    assert np.isnan(r.solid[-1, 0, 2])


def test_freundlich_units_with_a_fractional_exponent():
    """The same physics in mmol and in mg units (K_mg = K·MW^(1−1/n)) gives the same loading."""
    mw, K, n, c = 100.0, 2.0, 1.5, 2.0
    molar = saturate([Component("A")], mb.BindingSpec("Freundlich", equilibrium=[K], exponent=[n]), [c])
    mass = saturate([Component("A", mw=mw, liquid_unit="mg/L", solid_unit="mg/mL solid")],
                    mb.BindingSpec("Freundlich", equilibrium=[K * mw ** (1 - 1 / n)], exponent=[n]), [c * mw])
    assert molar.solid[-1, 0, 0] == pytest.approx(K * c ** (1 / n), rel=1e-3)
    assert mass.solid[-1, 0, 0] / mw == pytest.approx(molar.solid[-1, 0, 0], rel=1e-6)


def test_freundlich_kinetics_is_a_first_order_approach():
    """dq/dt = k·(q* − q): at the inlet cell q(t) = q*·(1 − e^(−k·t)). K is small so that the feed can
    fill the first cell quickly and the rate constant, not the supply, limits the loading."""
    k_ldf, K, n, c = 0.2, 1e-3, 1.5, 2.0                       # 1/min, ..., mmol/L
    r = saturate([Component("A")], mb.BindingSpec("Freundlich", kinetic=True, equilibrium=[K], exponent=[n],
                                                  ldf_rate=[k_ldf]), [c], duration=30.0)
    q_star = K * c ** (1 / n)
    for t_target in (3.0, 6.0, 10.0):
        i = int(np.searchsorted(r.time, t_target))
        assert r.solid[i, 0, 0] == pytest.approx(q_star * (1 - np.exp(-k_ldf * r.time[i])), rel=0.03)
    assert r.solid[-1, 0, 0] == pytest.approx(q_star, rel=0.01)             # saturated after 30 min


@pytest.mark.parametrize("change, match", [
    (lambda b: setattr(b, "equilibrium", [None, 1.0, None]), "K_F is empty for component 'A'"),
    (lambda b: setattr(b, "exponent", [1.5, None, None]), "n is empty for component 'B'"),
    (lambda b: setattr(b, "exponent", [0.0, 2.0, None]), "exponent n must be positive"),
    (lambda b: (setattr(b, "kinetic", True), setattr(b, "ldf_rate", [None, 1.0, None])), "k_LDF is empty"),
])
def test_freundlich_input_errors(change, match):
    b = mb.BindingSpec("Freundlich", equilibrium=[2.0, 1.0, None], exponent=[1.5, 2.0, None],
                       ldf_rate=[1.0, 1.0, None])
    change(b)
    spec = mb.BatchSpec(ABC, mb.ColumnSpec(model="LRMP", film_diffusion=[0.5] * 3), b,
                        mb.OperationSpec(1.0, [mb.constant(0.0, FEED)]), mb.SimulationSettings())
    with pytest.raises(ValueError, match=match):
        mb.build_process(spec)


# --- Anti-Langmuir ---------------------------------------------------------------------------------

@pytest.mark.parametrize("kinetic", [False, True])
def test_anti_langmuir_equilibrium(kinetic):
    # K of the anti component stays small: with rapid equilibrium CADET does not converge when its K·c is large
    K, Q, p = [0.5, 0.05], [0.1, 0.08], [1.0, -1.0]
    binding = mb.BindingSpec("AntiLangmuir", kinetic=kinetic, equilibrium=K + [None], capacity=Q + [None],
                             adsorption_rate=[k * 60.0 for k in K] + [None], desorption_rate=[60.0, 60.0, None],
                             sign=p + [None])
    r = saturate(ABC, binding, FEED)
    den = 1 + sum(pj * kj * cj for pj, kj, cj in zip(p, K, FEED[:2]))          # 1 + 0.5·2 − 0.05·3
    expected = [qm * k * c / den for qm, k, c in zip(Q, K, FEED[:2])]
    np.testing.assert_allclose(r.solid[-1, 0, :2], expected, rtol=1e-3)
    langmuir_b = Q[1] * K[1] * FEED[1] / (1 + sum(k * c for k, c in zip(K, FEED[:2])))
    assert expected[1] > langmuir_b                                              # the anti component binds more


def test_anti_langmuir_with_plus_signs_is_langmuir():
    K, Q = [0.5, 0.2], [0.1, 0.1]
    lang = saturate(ABC, mb.BindingSpec("Langmuir", equilibrium=K + [None], capacity=Q + [None]), FEED)
    anti = saturate(ABC, mb.BindingSpec("AntiLangmuir", equilibrium=K + [None], capacity=Q + [None],
                                        sign=[1.0, 1.0, None]), FEED)
    np.testing.assert_allclose(anti.outlet, lang.outlet, rtol=1e-6, atol=1e-9)
    default = saturate(ABC, mb.BindingSpec("AntiLangmuir", equilibrium=K + [None], capacity=Q + [None]), FEED)
    np.testing.assert_allclose(default.outlet, lang.outlet, rtol=1e-6, atol=1e-9)    # no sign given: +1


def test_anti_langmuir_sign_must_be_plus_or_minus_one():
    b = mb.BindingSpec("AntiLangmuir", equilibrium=[0.5, 0.2, None], capacity=[0.1, 0.1, None], sign=[1.0, 0.5, None])
    spec = mb.BatchSpec(ABC, mb.ColumnSpec(model="LRMP", film_diffusion=[0.5] * 3), b,
                        mb.OperationSpec(1.0, [mb.constant(0.0, FEED)]), mb.SimulationSettings())
    with pytest.raises(ValueError, match=r"p must be \+1"):
        mb.build_process(spec)


# --- Bi-Langmuir -----------------------------------------------------------------------------------

def bilangmuir(kinetic=False):
    K1, Q1, K2, Q2 = [0.5, 0.2], [0.1, 0.08], [0.05, 0.9], [0.2, 0.3]
    scale = 60.0
    binding = mb.BindingSpec(
        "BiLangmuir", kinetic=kinetic, equilibrium=K1 + [None], capacity=Q1 + [None],
        adsorption_rate=[k * scale for k in K1] + [None], desorption_rate=[scale, scale, None],
        site2=mb.SecondSite(equilibrium=K2 + [None], capacity=Q2 + [None],
                            adsorption_rate=[k * scale for k in K2] + [None], desorption_rate=[scale, scale, None]))
    return binding, (K1, Q1, K2, Q2)


@pytest.mark.parametrize("kinetic", [False, True])
def test_bi_langmuir_is_two_independent_langmuir_sites(kinetic):
    binding, (K1, Q1, K2, Q2) = bilangmuir(kinetic)
    r = saturate(ABC, binding, FEED)

    def site(K, Q):
        d = 1 + sum(k * c for k, c in zip(K, FEED[:2]))
        return np.array([qm * k * c / d for qm, k, c in zip(Q, K, FEED[:2])])

    np.testing.assert_allclose(r.solid[-1, 0, :2], site(K1, Q1) + site(K2, Q2), rtol=1e-3)   # total per component
    assert np.isnan(r.solid[-1, 0, 2])                                                         # inert component
    assert np.isfinite(r.outlet).all()


def test_bi_langmuir_input_errors():
    binding, _ = bilangmuir()
    spec = mb.BatchSpec(ABC, mb.ColumnSpec(model="LRMP", film_diffusion=[0.5] * 3), binding,
                        mb.OperationSpec(1.0, [mb.constant(0.0, FEED)]), mb.SimulationSettings())
    spec.binding.site2 = None
    with pytest.raises(ValueError, match="second site"):
        mb.build_process(spec)
    spec.binding, _ = bilangmuir()
    spec.binding.site2.equilibrium = [None, 0.9, None]
    with pytest.raises(ValueError, match="K2 is empty for component 'A'"):
        mb.build_process(spec)
    spec.binding, _ = bilangmuir()
    spec.column.initial_solid = [0.01, 0.0, 0.0]
    with pytest.raises(ValueError, match="not available for Bi-Langmuir"):
        mb.build_process(spec)


# --- SMA ---------------------------------------------------------------------------------------------

LAMBDA, C_SALT = 1.2, 50.0
NU, SIGMA, K_SMA = [2.0, 3.0], [1.5, 0.5], [0.004, 0.002]


def sma_spec(model, feed_ab=(1.0, 2.0), kinetic=False):
    """Salt (+ pH for GIEX) and two charged solutes; ``model`` is "SMA" or "GIEX"."""
    giex = model == "GIEX"
    mods = giex_modulators()[: 2 if giex else 1]
    comps = mods + [Component("A", charge=NU[0]), Component("B", charge=NU[1])]
    k = len(mods)
    pad = [None] * k
    zeros = [[0.0, 0.0, 0.0]] * 2
    g = mb.GiexSpec(capacity=LAMBDA, capacity_unit="meq/mL solid", reference_liquid=C_SALT, ph_ref=7.0,
                    steric_factor=pad + SIGMA,
                    adsorption_ph=pad + zeros if giex else None, desorption_ph=pad + zeros if giex else None,
                    charge_ph=pad + zeros if giex else None)
    binding = mb.BindingSpec(model, kinetic=kinetic, equilibrium=pad + K_SMA, adsorption_rate=pad + [k_ * 600 for k_ in K_SMA],
                             desorption_rate=pad + [600.0, 600.0], giex=g)
    feed = [C_SALT] + ([7.0] if giex else []) + list(feed_ab)
    n = len(comps)
    return mb.BatchSpec(
        comps, mb.ColumnSpec(model="LRMP", length=3.0, film_diffusion=[0.5] * n, axial_dispersion=6e-3,
                             initial_liquid=[C_SALT] + ([7.0] if giex else []) + [0.0, 0.0]),
        binding, mb.OperationSpec(1.0, [mb.constant(0.0, feed)]),
        mb.SimulationSettings(duration=400.0, output_interval=1.0, n_col=20, timeout=60.0))


@pytest.mark.parametrize("kinetic", [False, True])
def test_sma_saturated_column_satisfies_the_sma_isotherm(kinetic):
    r = from_cadet(run_batch(sma_spec("SMA", kinetic=kinetic)), sma_spec("SMA", kinetic=kinetic))
    c = r.pore[-1, 0]                                   # salt, A, B (mmol/L)
    q = r.solid[-1, 0]                                  # mmol/mL solid (salt: meq/mL)
    assert c[0] == pytest.approx(C_SALT, rel=1e-3)
    q_bar0 = LAMBDA - sum((nu + sg) * qj for nu, sg, qj in zip(NU, SIGMA, q[1:]))
    for i in range(2):                                  # K·c·(q̄0/Λ)^ν = q   (c_salt = c_ref)
        assert K_SMA[i] * c[1 + i] * (q_bar0 / LAMBDA) ** NU[i] == pytest.approx(q[1 + i], rel=2e-3)
    assert q[0] + sum(nu * qj for nu, qj in zip(NU, q[1:])) == pytest.approx(LAMBDA, rel=1e-3)   # electroneutrality


def test_sma_is_giex_without_ph_dependence():
    a = from_cadet(run_batch(sma_spec("SMA")), sma_spec("SMA"))
    b = from_cadet(run_batch(sma_spec("GIEX")), sma_spec("GIEX"))
    # the two runs differ only by the solver's own tolerance (reltol 1e-6) since the systems have different sizes
    np.testing.assert_allclose(a.outlet[:, 1:], b.outlet[:, [0, 2, 3]][:, 1:], rtol=1e-4, atol=1e-7)
    np.testing.assert_allclose(a.solid[:, :, 1:], b.solid[:, :, 2:], rtol=1e-4, atol=1e-8)


def test_sma_initial_salt_on_the_resin_fills_all_sites():
    q0 = mb.build_process(sma_spec("SMA")).flow_sheet.column.q
    assert q0[0] == pytest.approx(LAMBDA * 1000)             # mol/m³ solid
    assert list(q0[1:]) == [0.0, 0.0]


@pytest.mark.parametrize("change, match", [
    (lambda s: setattr(s.components[1], "charge", None), "needs its charge"),
    (lambda s: setattr(s.components[0], "bound", False), "salt"),
    (lambda s: setattr(s.column, "initial_liquid", [0.0, 0.0, 0.0]), "initial salt"),
    (lambda s: setattr(s.binding, "giex", None), "missing"),
    (lambda s: setattr(s.column, "initial_solid", [0.0, 0.7, 0.0]), "exceed the capacity"),     # ν·q = 1.4 > Λ
])
def test_sma_input_errors(change, match):
    spec = sma_spec("SMA")
    change(spec)
    with pytest.raises(ValueError, match=match):
        mb.build_process(spec)


def test_spec_round_trips_through_dict_with_the_new_fields():
    binding, _ = bilangmuir()
    binding.exponent, binding.ldf_rate, binding.sign = [1.5, 2.0, None], [1.0, 2.0, None], [1.0, -1.0, None]
    spec = mb.BatchSpec(ABC, mb.ColumnSpec(model="LRMP", film_diffusion=[0.5] * 3), binding,
                        mb.OperationSpec(1.0, [mb.constant(0.0, FEED)]), mb.SimulationSettings())
    assert mb.spec_from_dict(mb.spec_to_dict(spec)) == spec
    assert mb.modulator_count("SMA") == 1 and mb.modulator_count("GIEX") == 2 and mb.modulator_count("Langmuir") == 0
