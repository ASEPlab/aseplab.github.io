"""GIEX with pH modulator: equilibrium after saturation matches the analytic isotherm."""
import numpy as np
import pytest

from core import model_builder as mb
from core.components import Component
from core.results_io import from_cadet
from core.simulator import run_batch

LAMBDA = 1.2          # meq/mL solid
K, NU, SIGMA = 0.004, 2.0, 1.5
A_PH = [-0.8, 0.3, 0.0]   # ln K vs (pH − 7)
N_PH = [0.4, -0.1, 0.0]   # ν vs (pH − 7)
PH_REF = 7.0
C_SALT, C_A = 50.0, 1.0   # mmol/L


def giex_spec(ph, kinetic=False):
    comps = [
        Component("salt", charge=1),
        Component("pH", bound=False, liquid_unit="pH"),
        Component("A", charge=NU),
        Component("L", bound=False, charge=1),
    ]
    giex = mb.GiexSpec(capacity=LAMBDA, capacity_unit="meq/mL solid", reference_liquid=C_SALT,
                       reference_solid=None, ph_ref=PH_REF,
                       steric_factor=[None, None, SIGMA, None],
                       adsorption_ph=[None, None, A_PH, None],
                       desorption_ph=[None, None, [0.0, 0.0, 0.0], None],
                       charge_ph=[None, None, N_PH, None])
    binding = mb.BindingSpec("GIEX", kinetic=kinetic, equilibrium=[None, None, K, None],
                             adsorption_rate=[None, None, K * 600, None],
                             desorption_rate=[None, None, 600.0, None], giex=giex)
    feed = [C_SALT, ph, C_A, 0.5]
    return mb.BatchSpec(
        components=comps,
        column=mb.ColumnSpec(model="LRMP", length=2.0, film_diffusion=[1.0] * 4, axial_dispersion=1e-2,
                             initial_liquid=[C_SALT, ph, 0.0, 0.0]),
        binding=binding,
        operation=mb.OperationSpec(flow_rate=2.0, inlet=[mb.constant(0.0, feed)]),
        settings=mb.SimulationSettings(duration=120.0, output_interval=1.0, n_col=10),
    )


def residual(ph, c_salt, c_a, q_a):
    """Rapid-eq GIEX residual in SI (mol/m³), normalised by the adsorption term."""
    x = ph - PH_REF
    k_ph = K * 1000 * np.exp(A_PH[0] * x + A_PH[1] * x ** 2)      # (mmol/mL)/(mmol/L) -> SI ×1000
    nu = NU + N_PH[0] * x + N_PH[1] * x ** 2
    lam = LAMBDA * 1000
    q_bar0 = lam - (nu + SIGMA) * q_a
    ads = k_ph * c_a * (q_bar0 / lam) ** nu
    des = q_a * (c_salt / C_SALT) ** nu
    return (ads - des) / ads


@pytest.mark.parametrize("ph", [6.0, 8.0])
@pytest.mark.parametrize("kinetic", [False, True])
def test_giex_equilibrium(ph, kinetic):
    spec = giex_spec(ph, kinetic)
    r = from_cadet(run_batch(spec), spec)
    assert r.summary["exit_flag"] == 0
    c = r.pore[-1, -1]                     # mmol/L (= mol/m³); pH column carries pH
    q = r.solid[-1, -1]                    # mmol/mL solid
    assert c[1] == pytest.approx(ph)
    assert c[0] == pytest.approx(C_SALT, rel=1e-3) and c[2] == pytest.approx(C_A, rel=1e-3)
    assert q[2] > 0
    assert residual(ph, c[0], c[2], q[2] * 1000) == pytest.approx(0.0, abs=1e-3)
    # electroneutrality on the resin: q_salt + ν·q_A = Λ
    x = ph - PH_REF
    nu = NU + N_PH[0] * x + N_PH[1] * x ** 2
    assert q[0] + nu * q[2] == pytest.approx(LAMBDA, rel=1e-3)
    assert np.isnan(q[1]) and np.isnan(q[3])


def test_ph_changes_binding():
    q = {}
    for ph in (6.0, 8.0):
        spec = giex_spec(ph)
        q[ph] = from_cadet(run_batch(spec), spec).solid[-1, -1, 2]
    assert q[6.0] > q[8.0]          # a1 < 0: K falls with pH


def test_recenter_polynomial():
    a, x0 = (0.7, -0.2, 0.05), 6.5
    b = mb.recenter_polynomial(a, x0)
    for x in (5.0, 6.5, 9.0):
        lhs = sum(ak * (x - x0) ** (k + 1) for k, ak in enumerate(a))
        rhs = sum(bk * x ** k for k, bk in enumerate(b))
        assert rhs == pytest.approx(lhs)


@pytest.mark.parametrize("change, match", [
    (lambda s: s.components.pop(), None),
    (lambda s: setattr(s.components[1], "liquid_unit", "mmol/L"), "pH modulator"),
    (lambda s: setattr(s.components[0], "bound", False), "salt"),
    (lambda s: setattr(s.components[2], "charge", None), "charge"),
    (lambda s: setattr(s.binding, "giex", None), "missing"),
    (lambda s: setattr(s.column, "initial_liquid", None), "initial salt"),
    (lambda s: setattr(s.column, "initial_liquid", [C_SALT, 0.0, 0.0, 0.0]), "initial pH"),
    (lambda s: setattr(s.column, "initial_solid", [None, None, LAMBDA, None]), "exceed the capacity"),
])
def test_giex_validation(change, match):
    spec = giex_spec(7.0)
    change(spec)
    if match is None:                   # still valid with 3 components after dropping L
        for attr in ("equilibrium", "adsorption_rate", "desorption_rate"):
            setattr(spec.binding, attr, getattr(spec.binding, attr)[:3])
        g = spec.binding.giex
        for attr in ("steric_factor", "adsorption_ph", "desorption_ph", "charge_ph"):
            setattr(g, attr, getattr(g, attr)[:3])
        spec.operation.inlet = [mb.constant(0.0, [C_SALT, 7.0, C_A])]
        spec.column.film_diffusion = [1.0] * 3
        spec.column.initial_liquid = [C_SALT, 7.0, 0.0]
        mb.build_process(spec)
        return
    with pytest.raises(ValueError, match=match):
        mb.build_process(spec)
