"""SMB: flow conversions, triangle design, ring order, simulation, performance and the result file."""
import numpy as np
import pytest

from core import examples, smb
from core import smb_results as sr
from core.smb_sim import SMBJob, run_smb


def base_spec(n_col=20):
    base = examples.default()
    base.column.model, base.column.pore_diffusion = "LRMP", None
    base.settings.n_col, base.settings.output_interval = n_col, 0.1
    base.settings.timeout = 120
    return base


def binary(**kwargs):
    spec = smb.SMBSpec(base=base_spec(), switch_time=3.0, flow_mode="m", flows=[0, 0, 0, 0],
                       feed=[1.0, 1.0], eluent=[0.0, 0.0], **kwargs)
    spec.flows = smb.triangle_design(spec, gamma=1.1)
    spec.products = smb.default_products(spec)
    return spec


@pytest.fixture(scope="module")
def steady():
    spec = binary()
    results, job = run_smb(spec)
    return sr.from_cadet(results, spec, job.converged, job.differences), job


def test_the_three_flow_inputs_describe_the_same_smb():
    spec = binary()
    reference = smb.flow_set(spec)
    for mode in smb.FLOW_MODES:
        other = smb.SMBSpec(**{**spec.__dict__, "flow_mode": mode, "flows": smb.flows_as(spec, mode)})
        f = smb.flow_set(other)
        np.testing.assert_allclose(f.zones, reference.zones)
        np.testing.assert_allclose(f.m, reference.m)
    f = reference
    assert f.feed + f.eluent == pytest.approx(f.ports["extract"] + f.ports["raffinate"])
    assert f.zones[0] == pytest.approx(f.zones[3] + f.eluent)
    assert f.zones[2] == pytest.approx(f.zones[1] + f.feed)


def test_external_flows_by_hand():
    spec = smb.SMBSpec(base=base_spec(), flow_mode="external", flows=[0.5, 1.5, 1.0, 1.0],
                       feed=[1, 1], eluent=[0, 0])
    f = smb.flow_set(spec)
    assert f.zones == pytest.approx((2.5, 1.5, 2.0, 1.0))
    assert f.ports["raffinate"] == pytest.approx(1.0)
    v, et = smb.column_volume(spec), spec.base.column.total_porosity()
    assert f.m[0] == pytest.approx((2.5 * spec.switch_time - v * et) / (v * (1 - et)))


def test_impossible_flows_are_reported():
    spec = smb.SMBSpec(base=base_spec(), flow_mode="external", flows=[0.5, 1.5, 3.0, 1.0],
                       feed=[1, 1], eluent=[0, 0])                 # extract larger than zone I can give
    problems = smb.flow_problems(spec)
    assert any("Zone II" in p for p in problems)
    with pytest.raises(ValueError, match="Zone II"):
        smb.check(spec)
    spec.flows = [0.5, 1.5, 1.0, None]
    assert smb.flow_problems(spec) == ["Enter all 4 flow values"]


def test_triangle_design_for_linear_and_langmuir():
    spec = binary()
    h = smb.henry_coefficients(spec)
    assert h == pytest.approx({"A": 5.0, "B": 2.0})
    m = smb.triangle_design(spec, gamma=1.0)
    # Langmuir: the optimal point lies below the linear one (m₂ < H_B, m₃ < H_A) and m₂ < m₃
    assert m[0] >= h["A"] - 1e-9 and m[1] < h["B"] and m[1] < m[2] < h["A"] and m[3] <= h["B"] + 1e-9
    assert smb.default_products(spec) == {"extract": ["A"], "raffinate": ["B"]}
    linear = binary()
    linear.base.binding.model = "Linear"
    linear.base.binding.equilibrium = [0.005, 0.002]         # (mmol/mL solid)/(mmol/L): H = 5 and 2
    assert smb.triangle_design(linear, gamma=1.0) == pytest.approx([5.0, 2.0, 5.0, 2.0])
    linear.base.binding.model = "Freundlich"
    with pytest.raises(ValueError, match="triangle"):
        smb.triangle_design(linear)


def test_ring_order_moves_one_column_per_switch():
    spec = smb.SMBSpec(base=base_spec(), columns_per_zone=[2, 1, 2, 1], switch_time=2.0, feed=[1, 1],
                       eluent=[0, 0])
    assert spec.n_columns == 6 and spec.cycle_time == 12.0
    assert smb.column_order(spec, 0.5) == [0, 1, 2, 3, 4, 5]
    assert smb.column_order(spec, 2.5) == [1, 2, 3, 4, 5, 0]
    assert smb.column_order(spec, 12.5) == [0, 1, 2, 3, 4, 5]
    assert smb.zone_of_position(spec) == ["I", "I", "II", "III", "III", "IV"]


def test_spec_round_trip():
    spec = binary(title="AB split")
    assert smb.spec_from_dict(smb.spec_to_dict(spec)) == spec


def test_steady_state_separation(steady):
    result, job = steady
    assert job.converged is True and 2 <= job.cycle < job.max_cycles
    assert result.n_cycles == job.cycle
    assert result.time[-1] == pytest.approx(result.n_cycles * result.spec.cycle_time)
    perf = sr.performance(result)
    assert perf["purity"]["extract"] > 0.9 and perf["purity"]["raffinate"] > 0.85
    a, b = perf["products"]
    assert (a["component"], a["outlet"], b["component"], b["outlet"]) == ("A", "extract", "B", "raffinate")
    assert a["recovery"] > 0.85 and b["recovery"] > 0.9
    # at steady state what is fed in one cycle leaves in the same cycle
    row = sr.cycle_table(result).iloc[-1]
    for name in ("A", "B"):
        out = row[f"{name} extract [mol]"] + row[f"{name} raffinate [mol]"]
        assert out == pytest.approx(row[f"{name} fed [mol]"], rel=0.02)


def test_profiles_cover_the_whole_run_in_ring_order(steady):
    result, _ = steady
    spec = result.spec
    assert result.bulk.shape[1:] == (spec.n_columns, len(result.z), 2) and result.bulk.dtype == np.float32
    np.testing.assert_allclose(result.profile_time, result.time)           # every output time, first to last
    assert result.summary["profile_stride"] == 1
    k_last = np.searchsorted(result.profile_time, result.time[-1] - spec.cycle_time - 1e-9)
    positions, data = result.ring_profile("bulk", k_last)
    assert positions.shape == (spec.n_columns * len(result.z),) and data.shape == (len(positions), 2)
    assert positions[0] > 0 and positions[-1] < spec.n_columns
    # the column at ring position 0 at the start of the last cycle is column 0 again (full cycle)
    np.testing.assert_allclose(data[:len(result.z)], result.bulk[k_last, 0])
    # its outlet is the column outlet the result keeps
    np.testing.assert_allclose(result.column_outlets[0, k_last], result.bulk[k_last, 0, -1], rtol=0.05, atol=1e-6)
    # early cycles are there too: the columns start empty
    assert np.nanmax(result.bulk[0]) == 0.0


def test_profile_stride():
    spec = binary()
    spec.base.settings.output_interval = 0.1
    assert sr.profile_stride(spec, 1000, 100) == 1
    assert sr.profile_stride(spec, 9000, 100) == 3                          # at most PROFILE_TIMES times
    assert sr.profile_stride(spec, 2000, 1e5) == 4                          # at most PROFILE_VALUES values
    spec.profile_interval = 0.5
    assert sr.profile_stride(spec, 1000, 100) == 5                          # the user's interval
    results, job = run_smb(smb.SMBSpec(**{**spec.__dict__, "cycles": smb.CycleSettings(mode="fixed", n_cycles=2)}))
    result = sr.from_cadet(results, spec, job.converged, job.differences)
    np.testing.assert_allclose(np.diff(result.profile_time), 0.5)
    assert result.profile_time[-1] == pytest.approx(result.time[-1])


def test_result_file_round_trip(steady):
    result, _ = steady
    again = sr.load_h5(sr.save_h5(result))
    assert again.spec == result.spec and again.summary == result.summary
    for name in ("time", "column_outlets", "bulk", "solid", "final_state"):
        np.testing.assert_array_equal(getattr(again, name), getattr(result, name))
    assert list(again.outlets) == ["extract", "raffinate"]
    for name in again.outlets:
        np.testing.assert_array_equal(again.outlets[name], result.outlets[name])
    from core.results_io import load_h5 as load_batch
    with pytest.raises(ValueError, match="SMB result file"):
        load_batch(sr.save_h5(result))
    from core.results_io import from_cadet, save_h5
    from core.simulator import run_batch
    batch = base_spec()
    batch.settings.duration = 2.0
    with pytest.raises(ValueError, match="Batch result file"):
        sr.load_h5(save_h5(from_cadet(run_batch(batch), batch)))


def test_fixed_cycles_and_continuing_from_the_final_state(steady):
    result, _ = steady
    spec = binary()
    spec.cycles = smb.CycleSettings(mode="fixed", n_cycles=1)
    results, job = run_smb(spec, (result.final_state, result.final_state_derivative))
    again = sr.from_cadet(results, spec, job.converged)
    assert job.cycle == 1 and job.converged is None
    # continuing from steady state stays at steady state
    np.testing.assert_allclose(again.outlets["extract"][-1], result.outlets["extract"][-1], rtol=1e-3, atol=1e-6)


def test_other_binding_models_build():
    spec = binary()
    spec.base.binding.model = "Freundlich"
    spec.base.binding.exponent = [2.0, 1.5]
    smb.build_process(spec)
    giex = examples.giex_metals()
    n = len(giex.components)
    s = smb.SMBSpec(base=giex, switch_time=5.0, flow_mode="external", flows=[0.2, 1.0, 0.6, 0.6],
                    feed=[50.0, 7.0] + [1.0] * (n - 2), eluent=[300.0, 7.0] + [0.0] * (n - 2))
    assert smb.henry_coefficients(s) is None
    process = smb.build_process(s)
    assert process.flow_sheet.column_0.binding_model.n_comp == n


def test_job_reports_cycles_and_can_be_cancelled():
    spec = binary()
    spec.cycles = smb.CycleSettings(mode="fixed", n_cycles=30)
    job = SMBJob(spec).start()
    import time
    deadline = time.time() + 60
    while job.cycle < 1 and time.time() < deadline:
        time.sleep(0.2)
    assert job.cycle >= 1 and 0 < job.progress < 1
    job.cancel()
    job.wait()
    assert job.status == "cancelled"


@pytest.mark.parametrize("layout, zones, ports", [
    ("4-zone open", [2.5, 1.5, 2.0, 1.0], {"eluent": 2.5, "extract": 1.0, "feed": 0.5, "raffinate": 1.0, "waste": 1.0}),
    ("3-zone", [2.5, 1.5, 2.0], {"eluent": 2.5, "extract": 1.0, "feed": 0.5, "raffinate": 2.0}),
    ("5-zone open", [3.0, 2.0, 1.5, 2.5, 1.0],
     {"eluent": 3.0, "extract_1": 1.0, "extract_2": 0.5, "feed": 1.0, "raffinate": 1.5, "waste": 1.0}),
    ("5-zone closed", [3.0, 2.0, 1.5, 2.5, 1.0],
     {"eluent": 2.0, "extract_1": 1.0, "extract_2": 0.5, "feed": 1.0, "raffinate": 1.5}),
])
def test_layout_flows(layout, zones, ports):
    nz = len(zones)
    spec = smb.SMBSpec(base=base_spec(), layout=layout, columns_per_zone=[1] * nz, flow_mode="zones",
                       flows=zones, feed=[1, 1], eluent=[0, 0])
    f = smb.flow_set(spec)
    assert f.ports == pytest.approx(ports)
    assert sum(v for k, v in f.ports.items() if k in smb.INLETS) == pytest.approx(
        sum(v for k, v in f.ports.items() if k not in smb.INLETS))
    for mode in ("external", "m"):                         # every input form gives back the same zone flows
        other = smb.SMBSpec(**{**spec.__dict__, "flow_mode": mode, "flows": smb.flows_as(spec, mode)})
        np.testing.assert_allclose(smb.flow_set(other).zones, zones)
    assert len(smb.flow_labels(layout, "external")) == len(smb.flows_as(spec, "external"))
    assert smb.flow_problems(spec) == []


@pytest.mark.parametrize("layout", ["4-zone open", "3-zone", "5-zone closed", "5-zone open"])
def test_other_layouts_run_and_conserve_mass(layout):
    """Every layout simulates to a steady state in which what is fed leaves with the outlets."""
    reference = binary()
    q = list(smb.flow_set(reference).zones)
    nz = smb.LAYOUTS[layout].n_zones
    if nz == 5:
        q = [q[0], q[1], 0.8 * q[1], 0.8 * q[1] + (q[2] - q[1]), min(q[3], 0.9 * q[0])]
    spec = smb.SMBSpec(**{**reference.__dict__, "layout": layout, "flow_mode": "zones", "flows": q[:nz],
                          "columns_per_zone": [1] * nz})
    spec.base.settings.n_col = 12
    spec.products = smb.default_products(spec)
    results, job = run_smb(spec)
    result = sr.from_cadet(results, spec, job.converged)
    assert job.converged is True and list(result.outlets) == spec.geometry.outlets
    row = sr.cycle_table(result).iloc[-1]
    for name in ("A", "B"):
        out = sum(row[f"{name} {smb.STREAM_LABELS[o]} [mol]"] for o in result.outlets)
        assert out == pytest.approx(row[f"{name} fed [mol]"], rel=0.01)
    perf = sr.performance(result)
    assert set(perf["purity"]) <= set(spec.geometry.products)
    again = sr.load_h5(sr.save_h5(result))
    assert list(again.outlets) == list(result.outlets) and again.spec == spec


def test_old_files_still_load():
    d = smb.spec_to_dict(binary())
    d.pop("layout"), d.pop("products")
    d["extract_products"], d["raffinate_products"] = ["A"], ["B"]
    spec = smb.spec_from_dict(d)
    assert spec.layout == "4-zone closed" and spec.products == {"extract": ["A"], "raffinate": ["B"]}
    d["layout"] = "5-zone"                                   # the closed 5-zone layout's first name
    assert smb.spec_from_dict(d).layout == "5-zone closed"


def test_cycle_differences_are_kept(steady):
    result, job = steady
    diffs = result.summary["cycle_differences"]
    assert len(diffs) == result.n_cycles - 1 and diffs == job.differences
    assert diffs[-1] <= result.summary["threshold"] < diffs[0]          # converged at the last cycle only
    assert sr.load_h5(sr.save_h5(result)).summary["cycle_differences"] == diffs


def test_switch_averages_match_the_cycle_amounts(steady):
    from core import units
    result, _ = steady
    spec = result.spec
    for outlet in result.outlets:
        starts, ends, means = sr.switch_averages(result, outlet)
        assert len(starts) == result.n_cycles * spec.n_columns
        np.testing.assert_allclose(ends - starts, spec.switch_time)
        last = slice(-spec.n_columns, None)
        flow = units.flow_to_si(smb.flow_set(spec).ports[outlet])
        mol = (means[last, 0] * (ends[last] - starts[last])).sum() * flow * units.time_to_si(1.0)
        assert mol == pytest.approx(sr.cycle_table(result).iloc[-1][f"A {smb.STREAM_LABELS[outlet]} [mol]"])
