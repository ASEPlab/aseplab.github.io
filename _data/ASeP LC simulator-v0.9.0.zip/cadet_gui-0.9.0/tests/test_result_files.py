"""Saving the result file with a chosen name in a chosen folder."""
import pytest

from utils import result_files


def test_file_name_is_safe_and_has_the_extension():
    assert result_files.file_name("run 1", "h5") == "run_1.h5"
    assert result_files.file_name("run.h5", "h5") == "run.h5"
    assert result_files.file_name("RUN.H5", "h5") == "RUN.h5"
    assert result_files.file_name("../../etc/passwd", "h5") == "passwd.h5"
    assert result_files.file_name("", "h5", "result") == "result.h5"


def test_save_creates_the_folder_and_does_not_overwrite_silently(tmp_path):
    folder = tmp_path / "a" / "b"
    path = result_files.save_file(folder, "x", "h5", b"1")
    assert path == folder / "x.h5" and path.read_bytes() == b"1"
    with pytest.raises(FileExistsError):
        result_files.save_file(folder, "x.h5", "h5", b"2")
    assert path.read_bytes() == b"1"
    result_files.save_file(folder, "x", "h5", b"2", overwrite=True)
    assert path.read_bytes() == b"2"


def test_folder_expands_home_and_relative_paths(tmp_path):
    assert str(result_files.target_path("~/runs", "a", "h5")).endswith("/runs/a.h5")
    assert result_files.target_path("results", "a", "h5").parent.name == "results"
    assert result_files.target_path("results", "a", "h5").is_absolute()
