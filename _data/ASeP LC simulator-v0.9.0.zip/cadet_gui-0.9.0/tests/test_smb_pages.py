"""Headless tests of the SMB screen and the SMB results page."""
import io
from pathlib import Path

import numpy as np
import openpyxl
import pytest
from streamlit.testing.v1 import AppTest

from core import smb
from core import smb_results as sr
from utils import input_files

ROOT = Path(__file__).resolve().parents[1]
SMB_PAGE = ROOT / "pages" / "5_SMB.py"


def app(timeout=300):
    """The multipage app, on the SMB screen."""
    return visit(AppTest.from_file(str(ROOT / "app.py"), default_timeout=timeout).run(), "5_SMB.py")


def visit(at, page):
    at.switch_page(f"pages/{page}").run()
    assert not at.exception, [e.value for e in at.exception]
    return at


def fast(at):
    """Coarser grid so a run takes seconds."""
    at.number_input(key="smb_sim_ncol").set_value(15).run()
    at.number_input(key="smb_sim_dt").set_value(0.1).run()
    return at


def run(at):
    at.button(key="smb_run").click().run()
    job = at.session_state["smb_job"] if "smb_job" in at.session_state else None
    if job is not None:
        job.wait()
        at.run()
    return at


@pytest.fixture(scope="module")
def finished():
    at = fast(app())
    at.radio(key="smb_cyc_mode").set_value("fixed").run()
    at.number_input(key="smb_cyc_n").set_value(4).run()
    run(at)
    return at


def test_page_draws_with_the_example():
    at = AppTest.from_file(str(SMB_PAGE), default_timeout=60).run()
    assert not at.exception and not at.error
    assert at.session_state["smb_form_spec"].title == "SMB: A / B, Langmuir"
    assert at.radio(key="smb_flow_mode").value == "external"
    assert len(at.get("iframe")) == 1                     # the process layout animation, before any run
    at.button(key="smb_layout_images_create").click().run()
    assert not at.exception and len(at.session_state["smb_layout_images"]["pngs"]) == 4


def test_switching_the_flow_input_keeps_the_smb():
    at = AppTest.from_file(str(SMB_PAGE), default_timeout=60).run()
    before = smb.flow_set(at.session_state["smb_form_spec"])
    for mode in ("m", "zones", "external"):
        at.radio(key="smb_flow_mode").set_value(mode).run()
        assert not at.exception and not at.error
        after = smb.flow_set(at.session_state["smb_form_spec"])
        np.testing.assert_allclose(after.zones, before.zones, rtol=1e-5)


def test_bad_flows_block_the_run():
    at = AppTest.from_file(str(SMB_PAGE), default_timeout=60).run()
    at.number_input(key="smb_flow_2").set_value(10.0).run()          # extract larger than zone I
    assert any("must be positive" in e.value for e in at.error)
    assert at.session_state["smb_form_spec"] is None
    assert at.button(key="smb_run").disabled
    assert len(at.get("iframe")) == 0                     # no layout drawn for an impossible SMB


def test_triangle_design_button():
    at = AppTest.from_file(str(SMB_PAGE), default_timeout=60).run()
    at.number_input(key="smb_tri_gamma").set_value(1.3).run()
    at.button(key="smb_tri_button").click().run()
    assert not at.exception
    spec = at.session_state["smb_form_spec"]
    assert spec.flow_mode == "m"
    np.testing.assert_allclose(spec.flows, smb.triangle_design(spec, gamma=1.3), rtol=1e-5)


def test_batch_and_smb_forms_are_separate():
    at = app(60)
    at.number_input(key="smb_col_L").set_value(7.0).run()
    visit(at, "1_Batch.py")
    assert at.number_input(key="col_L").value == 10.0
    at.number_input(key="col_L").set_value(12.0).run()
    visit(at, "5_SMB.py")
    assert at.number_input(key="smb_col_L").value == 7.0
    # Copy from Batch takes the Batch column
    at.button(key="smb_copy_batch").click().run()
    assert not at.exception
    assert at.number_input(key="smb_col_L").value == 12.0
    assert at.session_state["smb_form_spec"].switch_time == 3.0          # the SMB part stays


def test_input_file_round_trip():
    at = AppTest.from_file(str(SMB_PAGE), default_timeout=60).run()
    spec = at.session_state["smb_form_spec"]
    data = input_files.save_smb_input(spec)
    kind, again = input_files.load_smb_input(data)
    assert kind == "smb" and again == spec


def test_run_shows_brief_results(finished):
    at = finished
    assert not at.exception and not at.error, [e.value for e in at.error]
    result = at.session_state["smb_result"]
    assert result.n_cycles == 4 and result.summary["converged"] is None
    diffs = result.summary["cycle_differences"]
    assert len(diffs) == 3
    if diffs[-1] > result.summary["threshold"]:                      # 4 cycles are usually not enough
        assert any("Not at cyclic steady state" in w.value for w in at.warning)
    labels = [m.label for m in at.metric]
    assert "Purity, extract" in labels and "Cycles" in labels
    assert "smb_brief_outlet" in [c.key for c in at.get("plotly_chart")] or len(at.get("plotly_chart")) >= 1


def test_results_page(finished):
    at = finished
    visit(at, "6_SMB_Results.py")
    at.toggle(key="smbview_all").set_value(True).run()
    assert len(at.get("plotly_chart")) >= 2                          # extract and raffinate in their own plots
    at.radio(key="smbview_per_row").set_value(1).run()
    at.slider(key="smbview_height").set_value(500).run()
    at.multiselect(key="smbview_outlets").set_value(["raffinate"]).run()
    at.checkbox(key="smbview_curve").set_value(False).run()
    assert not at.exception
    result = at.session_state["smb_result"]
    pt = result.profile_time
    at.select_slider(key="smbview_k").set_value(5).run()
    at.button(key="smbview_next").click().run()
    assert at.session_state["smbview_k"] == 6
    at.button(key="smbview_next_switch").click().run()                  # to the next switch boundary
    assert pt[at.session_state["smbview_k"]] == pytest.approx(result.spec.switch_time)
    at.button(key="smbview_next_cycle").click().run()
    assert pt[at.session_state["smbview_k"]] == pytest.approx(result.spec.cycle_time)
    at.button(key="smbview_prev_switch").click().run()
    assert pt[at.session_state["smbview_k"]] == pytest.approx(result.spec.cycle_time - result.spec.switch_time)
    at.button(key="smbview_prev_cycle").click().run()
    assert at.session_state["smbview_k"] == 0
    at.radio(key="smbview_play_span").set_value("This cycle").run()
    at.button(key="smbview_last").click().run()
    assert at.session_state["smbview_k"] == len(pt) - 1 and not at.exception
    at.button(key="smbview_first").click().run()
    assert at.session_state["smbview_k"] == 0
    at.selectbox(key="smbview_phase").set_value("solid").run()
    assert not at.exception
    workbook = openpyxl.load_workbook(io.BytesIO(at.session_state["smbview_xlsx"][2]))
    assert workbook.sheetnames == ["Summary", "Data", "Cycles", "Average concentration", "Charts", "Column outlets",
                                   "Input parameters"]
    at.checkbox(key="smbview_xlsx_profiles").set_value(True).run()
    assert "Ring bulk" in openpyxl.load_workbook(io.BytesIO(at.session_state["smbview_xlsx"][2])).sheetnames
    at.number_input(key="smbview_video_frames").set_value(10).run()
    at.selectbox(key="smbview_video_fmt").set_value("gif").run()
    at.button(key="smbview_video_create").click().run()
    assert not at.exception and at.session_state["smbview_video"]["data"][:6] == b"GIF89a"
    at.button(key="smbview_layout_images_create").click().run()
    assert not at.exception and len(at.session_state["smbview_layout_images"]["pngs"]) == 4
    again = sr.load_h5(at.session_state["smbview_h5"])
    assert again.spec == at.session_state["smb_result"].spec


def test_continue_from_the_last_run(finished):
    at = finished
    visit(at, "5_SMB.py")
    at.radio(key="smb_init_source").set_value("Final state of the last SMB run").run()
    assert not at.exception and not at.error
    first = at.session_state["smb_result"]
    at.number_input(key="smb_cyc_n").set_value(1).run()
    run(at)
    second = at.session_state["smb_result"]
    assert second is not first and second.n_cycles == 1
    # the run continued: its first outlet value is the previous run's last one
    np.testing.assert_allclose(second.outlets["extract"][0], first.outlets["extract"][-1], rtol=1e-4, atol=1e-8)


def test_animation_html():
    from core import examples
    from ui import smb_animation
    spec = examples.smb_binary()
    spec.columns_per_zone = [2, 2, 2, 2]
    cfg = smb_animation.config(spec, spec.cycle_time)
    assert cfg["n"] == 8 and cfg["closed"] is True
    assert {p["name"]: p["pos"] for p in cfg["ports"]} == {"eluent": 0, "extract": 2, "feed": 4, "raffinate": 6}
    spec.layout, spec.columns_per_zone, spec.flow_mode = "4-zone open", [1, 1, 1, 1], "zones"
    spec.flows = [6.33, 3.43, 5.59, 3.26]
    cfg = smb_animation.config(spec, spec.cycle_time)
    assert cfg["closed"] is False and {p["name"]: p["pos"] for p in cfg["ports"]}["waste"] == 4
    html = smb_animation.process_html(spec)
    assert "<svg" in html and '"n": 4' in html and '"closed": false' in html


def test_changing_the_layout():
    at = app(60)
    for layout, n in (("5-zone closed", 5), ("5-zone open", 5), ("3-zone", 3), ("4-zone open", 4), ("4-zone closed", 4)):
        at.selectbox(key="smb_layout").set_value(layout).run()
        assert not at.exception and not at.error, [e.value for e in at.error]
        spec = at.session_state["smb_form_spec"]
        assert spec.layout == layout and len(spec.columns_per_zone) == n and spec.flow_mode == "zones"
        assert set(spec.products) == set(smb.LAYOUTS[layout].products)
        assert len(at.get("iframe")) == 1
    at.selectbox(key="smb_layout").set_value("5-zone closed").run()
    labels = [x.label for x in at.number_input if x.label.startswith(("Q_", "m"))]
    assert "Q_V [mL/min]" in labels
    at.radio(key="smb_flow_mode").set_value("external").run()
    labels = [x.label for x in at.number_input if x.label.startswith("Q_")]
    assert "Q_E2 extract 2 [mL/min]" in labels and "Q_V recycle [mL/min]" in labels


def test_saving_to_a_folder(finished, tmp_path):
    at = finished
    visit(at, "6_SMB_Results.py")
    at.text_input(key="smbview_h5_folder").set_value(str(tmp_path)).run()
    at.text_input(key="smbview_h5_name").set_value("my smb run").run()
    at.button(key="smbview_h5_save").click().run()
    assert not at.exception and not at.error
    saved = tmp_path / "my_smb_run.smbh5"
    assert saved.exists() and sr.load_h5(saved.read_bytes()).spec == at.session_state["smb_result"].spec
    at.run()                                                         # the typed name stays
    assert at.text_input(key="smbview_h5_name").value == "my smb run"
    visit(at, "5_SMB.py")
    at.text_input(key="smb_input_file_folder").set_value(str(tmp_path)).run()
    at.button(key="smb_input_file_save").click().run()
    assert not at.exception
    files = list(tmp_path.glob("*.json"))
    assert len(files) == 1 and input_files.load_smb_input(files[0].read_bytes())[0] == "smb"


def test_batch_viewer_points_smb_files_elsewhere(finished):
    from core.results_io import load_h5
    with pytest.raises(ValueError, match="SMB results page"):
        load_h5(sr.save_h5(finished.session_state["smb_result"]))


def test_continue_from_a_result_file(finished, tmp_path):
    """Initial state → Load an SMB result file continues from the end of that file's run."""
    at = finished
    visit(at, "5_SMB.py")
    previous = at.session_state["smb_result"]
    data = sr.save_h5(previous)
    from ui import smb_form
    # the uploader cannot be driven headlessly; fill the cache it fills
    at.session_state["smb_init_file_cache"] = {"id": "x", "name": "run.smbh5", "spec": previous.spec,
                                               "n_cycles": previous.n_cycles,
                                               "state": (previous.final_state, previous.final_state_derivative)}
    at.radio(key="smb_init_source").set_value(smb_form.STATE_SOURCES[2]).run()
    assert not at.exception and not at.error, [e.value for e in at.error]
    at.number_input(key="smb_cyc_n").set_value(1).run()
    run(at)
    second = at.session_state["smb_result"]
    np.testing.assert_allclose(second.outlets["extract"][0], previous.outlets["extract"][-1], rtol=1e-4, atol=1e-8)
    # a different layout is refused with the reason
    at.number_input(key="smb_zones_I").set_value(2).run()
    assert any("different setup" in e.value and "columns_per_zone" in e.value for e in at.error)
    at.number_input(key="smb_zones_I").set_value(1).run()
    assert len(data) > 0
