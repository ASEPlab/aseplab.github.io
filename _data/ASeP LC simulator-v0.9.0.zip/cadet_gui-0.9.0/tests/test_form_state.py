"""spec <-> form state mapping (no Streamlit)."""
import copy

import pytest

from core import examples
from core import model_builder as mb
from core.components import Component
from core.examples import EXAMPLES
from ui import form_state as fs
from utils import input_files


def test_default_state_is_complete():
    state = fs.default_state()
    assert set(fs.TABLE_KEYS) <= set(state)
    assert state["comp_ids"] == [0, 1] and state["comp_0_name"] == "A"
    assert state["binding_model"] == "Langmuir" and state["rx_enabled"] is False
    assert list(state["inlet"].columns) == ["start [min]", "shape", "A", "B"]
    assert list(state["initial"].index) == ["A", "B"]


@pytest.mark.parametrize("name", list(EXAMPLES))
def test_every_example_maps(name):
    state, notes = fs.spec_to_state(EXAMPLES[name]())
    assert notes == []
    spec = EXAMPLES[name]()
    giex = spec.binding.model == "GIEX"
    assert state["binding_model"] == spec.binding.model
    expected = ([c.name for c in spec.components][2:] if giex else [c.name for c in spec.components])
    assert [state[f"comp_{i}_name"] for i in state["comp_ids"]] == expected
    assert list(state["binding"].index) == expected
    assert ("salt" in state["inlet"].columns) == giex


def broken(change):
    spec = copy.deepcopy(examples.giex_metals())
    change(spec)
    return spec


@pytest.mark.parametrize("make, text", [
    (lambda: broken(lambda s: s.components.pop(0)), "first two components"),
    (lambda: broken(lambda s: setattr(s.components[1], "liquid_unit", "mmol/L")), "first two components"),
    (lambda: broken(lambda s: setattr(s.components[0], "liquid_unit", "g/L")), "salt unit"),
    (lambda: broken(lambda s: setattr(s.components[2], "name", "salt")), "reserved"),
    (lambda: broken(lambda s: setattr(s.components[3], "name", "M1")), "unique"),
    (lambda: broken(lambda s: setattr(s.components[2], "name", " ")), "no name"),
    (lambda: broken(lambda s: setattr(s.components[3], "solid_unit", "kg/L")), "solid unit"),
    (lambda: broken(lambda s: setattr(s.column, "length", 0.0)), "Column length"),
    (lambda: broken(lambda s: setattr(s.column, "eps_b", 1.5)), "Bed porosity"),
    (lambda: broken(lambda s: setattr(s.binding.giex, "capacity_unit", "bogus")), "capacity unit"),
])
def test_unusable_specs_are_refused(make, text):
    with pytest.raises(ValueError, match=text):
        fs.spec_to_state(make())


def test_non_giex_input_cannot_use_the_ph_unit():
    spec = examples.default()
    spec.components[1].liquid_unit = "pH"
    with pytest.raises(ValueError, match="pH"):
        fs.spec_to_state(spec)


def test_inlet_table_round_trip_and_limits():
    segments = mb.inlet_from_table([0.0, 5.0, 15.0], ["step", "linear", "linear"],
                                   [[1.0, 0.0], [0.1, 1.0], [0.5, 0.0]])
    df = fs.inlet_dataframe(segments, ["A", "B"])
    assert list(df["shape"]) == ["step", "linear", "step"]            # the last row is held, never a ramp
    assert list(df["start [min]"]) == [0.0, 5.0, 15.0]
    assert df.loc[1, "A"] == 0.1 and df.loc[2, "A"] == 0.5
    with pytest.raises(ValueError, match="inlet table"):
        fs.inlet_dataframe([mb.InletSegment(0.0, [[0.0, 1.0, 0.0, 0.0], [0.0]]),
                            mb.InletSegment(5.0, [[9.0], [0.0]])], ["A", "B"])    # ramp misses the next value
    with pytest.raises(ValueError, match="inlet table"):
        fs.inlet_dataframe([mb.InletSegment(0.0, [[1.0, 0.0, 0.01], [0.0]])], ["A", "B"])


def test_saved_run_note():
    spec = examples.default()
    spec.initial_state_source = "end of a GRM run at t = 40 min"
    state, notes = fs.spec_to_state(spec)
    assert state["init_state_source"] == "Fresh column" and "fresh column" in notes[0]


def test_input_file_format(tmp_path):
    spec = examples.giex_metals(with_ligand=True)
    data = input_files.save_input(spec)
    assert data.startswith(b"{") and b'"format": "cadet_gui.input"' in data
    assert input_files.load_input(data) == spec
    bare = mb.spec_to_dict(spec)
    import json
    assert input_files.load_input(json.dumps(bare).encode()) == spec
    newer = json.loads(data)
    newer["version"] = 99
    with pytest.raises(ValueError, match="newer"):
        input_files.load_input(json.dumps(newer).encode())
