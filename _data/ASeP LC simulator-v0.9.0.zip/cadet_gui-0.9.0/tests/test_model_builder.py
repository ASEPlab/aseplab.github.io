"""Model builder tests: run CADET and check results against analytic moments.

For a pulse into a column with linear (or no) binding, the outlet first moment is
    t_R = (L·A/Q)·(εt + K_bed) + t_pulse/2
independent of dispersion and mass-transfer rates, where K_bed = q_bed/c is the
dimensionless Henry constant on a packed-bed basis. This checks the whole
GUI -> SI conversion chain (lengths, flow, porosities, isotherm units).
"""
import numpy as np
import pytest

from core import model_builder as mb
from core import units
from core.components import Component
from core.simulator import run_batch

L, D, Q, EPS_B, EPS_P = 10.0, 1.0, 1.0, 0.37, 0.5   # cm, cm, mL/min
EPS_T = units.total_porosity(EPS_B, EPS_P)
T_COL = L * np.pi * D ** 2 / 4 / Q                   # L·A/Q [min]
T_PULSE = 0.5                                        # min


def column(model, n):
    return mb.ColumnSpec(
        model=model, length=L, diameter=D, eps_b=EPS_B, eps_p=EPS_P, radius=25.0,
        axial_dispersion=1e-3,
        film_diffusion=None if model == "LRM" else [0.5] * n,
        pore_diffusion=[1e-4] * n if model == "GRM" else None,
    )


def pulse_spec(model, components, binding, c_feed, duration=60.0):
    n = len(components)
    return mb.BatchSpec(
        components=components,
        column=column(model, n),
        binding=binding,
        operation=mb.OperationSpec(flow_rate=Q, inlet=[
            mb.constant(0.0, c_feed),
            mb.constant(T_PULSE, [0.0] * n),
        ]),
        settings=mb.SimulationSettings(duration=duration, output_interval=0.01, n_col=100, n_par=5),
    )


def outlet(results):
    sol = results.solution.outlet.outlet
    return units.time_from_si(sol.time), sol.solution


def first_moment(t, c):
    return np.trapezoid(t * c, t) / np.trapezoid(c, t)


@pytest.mark.parametrize("model", mb.COLUMN_MODELS)
def test_tracer_retention(model):
    spec = pulse_spec(model, [Component("tracer", bound=False)], mb.BindingSpec("None"), [1.0])
    results = run_batch(spec)
    assert results.exit_flag == 0
    t, c = outlet(results)
    assert first_moment(t, c[:, 0]) == pytest.approx(T_COL * EPS_T + T_PULSE / 2, rel=1e-2)


@pytest.mark.parametrize("model, kinetic", [
    ("GRM", False), ("LRMP", False), ("LRM_keff", False), ("LRM", True), ("LRMP", True),
])
def test_linear_retention_bed_basis(model, kinetic):
    """K given as (mmol/mL bed)/(mmol/L); one unbound tracer alongside."""
    K_gui = 0.002                                   # -> K_bed = 2
    comps = [Component("A", solid_unit="mmol/mL bed"), Component("tracer", bound=False)]
    if kinetic:
        binding = mb.BindingSpec("Linear", kinetic=True,
                                 adsorption_rate=[K_gui * 60.0, None], desorption_rate=[60.0, None])
    else:
        binding = mb.BindingSpec("Linear", equilibrium=[K_gui, None])
    results = run_batch(pulse_spec(model, comps, binding, [1.0, 1.0]))
    t, c = outlet(results)
    assert first_moment(t, c[:, 0]) == pytest.approx(T_COL * (EPS_T + 2.0) + T_PULSE / 2, rel=1e-2)
    assert first_moment(t, c[:, 1]) == pytest.approx(T_COL * EPS_T + T_PULSE / 2, rel=1e-2)


def test_langmuir_same_physics_in_different_units():
    """mg/L + mg/g resin gives the same CADET result as mmol/L + mmol/mL solid."""
    mw, rho = 63.546, 1.5                           # g/mol, g/mL solid
    molar = Component("Cu", mw=mw)
    mass = Component("Cu", mw=mw, liquid_unit="mg/L", solid_unit="mg/g resin")

    spec_molar = pulse_spec("LRMP", [molar], mb.BindingSpec("Langmuir", equilibrium=[0.5], capacity=[2.0]),
                            [1.0], duration=40.0)
    spec_mass = pulse_spec("LRMP", [mass], mb.BindingSpec("Langmuir", equilibrium=[0.5 / mw],
                                                          capacity=[2.0 * mw / rho]), [mw], duration=40.0)
    spec_mass.column.resin_density = rho

    _, c_molar = outlet(run_batch(spec_molar))
    _, c_mass = outlet(run_batch(spec_mass))
    assert c_molar.max() > 0
    np.testing.assert_allclose(c_mass, c_molar, rtol=1e-6, atol=1e-9)


def test_inlet_polynomial_and_gradient():
    comps = [Component("salt", liquid_unit="mol/L"), Component("B")]
    spec = mb.BatchSpec(
        components=comps,
        column=column("LRMP", 2),
        binding=mb.BindingSpec("None"),
        operation=mb.OperationSpec(flow_rate=Q, inlet=[
            mb.constant(0.0, [0.1, 1.0]),
            mb.linear_gradient(5.0, 15.0, [0.1, 1.0], [0.5, 0.0]),
            mb.InletSegment(15.0, [[0.5, 0.0, 0.01], [0.0]]),   # quadratic in salt
        ]),
        settings=mb.SimulationSettings(duration=20.0, output_interval=0.1, n_col=20),
    )
    sol = run_batch(spec).solution.inlet.outlet
    t = units.time_from_si(sol.time)
    c = units.liquid_from_si(sol.solution[:, 0], "mol/L")
    expected = np.where(t < 5, 0.1,
                        np.where(t < 15, 0.1 + 0.04 * (t - 5), 0.5 + 0.01 * (t - 15) ** 2))
    np.testing.assert_allclose(c, expected, atol=1e-9)
    np.testing.assert_allclose(sol.solution[t > 15, 1], 0.0, atol=1e-12)


def test_profiles_recorded():
    spec = pulse_spec("GRM", [Component("A")], mb.BindingSpec("Linear", equilibrium=[1e-3]), [1.0],
                      duration=5.0)
    sol = run_batch(spec).solution.column
    nt = len(sol.outlet.time)
    assert sol.bulk.solution.shape == (nt, 100, 1)
    assert sol.particle.solution.shape == (nt, 100, 5, 1)
    assert sol.solid.solution.shape == (nt, 100, 5, 1)


@pytest.mark.parametrize("change, match", [
    (lambda s: setattr(s.binding, "kinetic", True), "rapid-equilibrium"),
    (lambda s: setattr(s.column, "film_diffusion", [0.5, 0.5]), "one per component"),
    (lambda s: setattr(s.column, "model", "XYZ"), "Unknown column model"),
    (lambda s: setattr(s.operation.inlet[0], "start", 1.0), "t = 0"),
    (lambda s: setattr(s.operation.inlet[1], "start", 0.0), "strictly increasing"),
    (lambda s: setattr(s.components[0], "bound", False), "no component adsorbs"),
])
def test_validation(change, match):
    spec = pulse_spec("LRM_keff", [Component("A")], mb.BindingSpec("Linear", equilibrium=[1e-3]), [1.0])
    change(spec)
    with pytest.raises(ValueError, match=match):
        mb.build_process(spec)


def test_inlet_from_table():
    segs = mb.inlet_from_table([0.0, 5.0, 15.0], ["step", "linear", "linear"],
                               [[1.0, 0.0], [0.1, 1.0], [0.5, 0.0]])
    assert [s.start for s in segs] == [0.0, 5.0, 15.0]
    assert segs[0].coefficients == [[1.0, 0, 0, 0], [0.0, 0, 0, 0]]
    assert segs[1].coefficients[0] == pytest.approx([0.1, 0.04, 0, 0])
    assert segs[1].coefficients[1] == pytest.approx([1.0, -0.1, 0, 0])
    assert segs[2].coefficients == [[0.5, 0, 0, 0], [0.0, 0, 0, 0]]   # last row held
    with pytest.raises(ValueError, match="shape"):
        mb.inlet_from_table([0.0], ["cubic"], [[1.0]])


@pytest.mark.parametrize("model", ["GRM", "LRM"])
def test_dead_volume_shifts_retention(model):
    """Two CSTRs of V/2 each add V/Q to the first moment and broaden the peak."""
    V = 2.0                                        # mL
    base = pulse_spec(model, [Component("tracer", bound=False)], mb.BindingSpec("None"), [1.0])
    ecv = pulse_spec(model, [Component("tracer", bound=False)], mb.BindingSpec("None"), [1.0])
    ecv.operation.dead_volume = V
    t0, c0 = outlet(run_batch(base))
    t1, c1 = outlet(run_batch(ecv))
    assert first_moment(t1, c1[:, 0]) - first_moment(t0, c0[:, 0]) == pytest.approx(V / Q, rel=1e-2)
    assert c1.max() < c0.max()
    assert np.trapezoid(c1[:, 0], t1) == pytest.approx(T_PULSE, rel=1e-3)   # mass conserved


def test_negative_dead_volume_rejected():
    spec = pulse_spec("LRMP", [Component("A", bound=False)], mb.BindingSpec("None"), [1.0])
    spec.operation.dead_volume = -1.0
    with pytest.raises(ValueError, match="Dead volume"):
        mb.build_process(spec)


@pytest.mark.parametrize("kinetic", [False, True])
@pytest.mark.parametrize("c0", [0.0, 1.0])
def test_initial_state_inventory_elutes(kinetic, c0):
    """A pre-loaded column (c0 in the liquid, q0 on the resin) washed with buffer elutes
    exactly its initial inventory. Rapid-equilibrium binding re-partitions pore liquid
    and resin to equilibrium but keeps the total."""
    from core import mass
    from core.results_io import from_cadet
    q0 = 0.002                                            # mmol/mL solid
    spec = mb.BatchSpec(
        [Component("A")],
        mb.ColumnSpec(model="LRMP", length=L, diameter=D, eps_b=EPS_B, eps_p=EPS_P, film_diffusion=[0.5],
                      axial_dispersion=6e-3, initial_liquid=[c0], initial_solid=[q0]),
        mb.BindingSpec("Linear", kinetic=kinetic, equilibrium=[0.001], adsorption_rate=[0.06],
                       desorption_rate=[60.0]),
        mb.OperationSpec(Q, [mb.constant(0.0, [0.0])]),
        # fine output: with rapid equilibrium the outlet jumps right after t = 0
        mb.SimulationSettings(duration=90.0, output_interval=0.01, n_col=40),
    )
    r = from_cadet(run_batch(spec), spec)
    volume = L * np.pi * D ** 2 / 4                       # mL
    inventory = volume * (EPS_T * c0 / 1000 + (1 - EPS_B) * (1 - EPS_P) * q0)   # mmol
    assert mass.output_moles(r)[0] * 1e3 == pytest.approx(inventory, rel=2e-3)


@pytest.mark.parametrize("kinetic", [False, True])
def test_langmuir_is_competitive_multicomponent(kinetic):
    """All components share the sites: q_i = qmax_i·K_i·c_i / (1 + Σ_j K_j·c_j) at saturation."""
    from core.results_io import from_cadet
    K, qmax, feed = [0.5, 0.2], [0.1, 0.2], [2.0, 3.0]           # 1/(mmol/L), mmol/mL solid, mmol/L
    expected = [qm * k * c / (1 + sum(kj * cj for kj, cj in zip(K, feed))) for qm, k, c in zip(qmax, K, feed)]
    spec = mb.BatchSpec(
        [Component("A"), Component("B")],
        mb.ColumnSpec(model="LRMP", length=5.0, film_diffusion=[0.5, 0.5], axial_dispersion=6e-3),
        mb.BindingSpec("Langmuir", kinetic=kinetic, equilibrium=K, capacity=qmax,
                       adsorption_rate=[k * 60.0 for k in K], desorption_rate=[60.0, 60.0]),
        mb.OperationSpec(1.0, [mb.constant(0.0, feed)]),             # continuous feed
        mb.SimulationSettings(duration=400.0, output_interval=1.0, n_col=30),
    )
    r = from_cadet(run_batch(spec), spec)
    np.testing.assert_allclose(r.solid[-1, 0], expected, rtol=1e-3)   # inlet cell, long after saturation
    # and a single component alone binds more: the competitor takes sites
    alone = 0.1 * 0.5 * 2.0 / (1 + 0.5 * 2.0)
    assert expected[0] < alone
