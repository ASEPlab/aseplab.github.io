"""MP4 / GIF export of the column profile."""
import subprocess

import imageio_ffmpeg
import pytest

from core import animation
from core.results_io import from_cadet
from core.simulator import run_batch
from tests.test_results_io import spec_for
from ui.plots import SERIES_COLORS


@pytest.fixture(scope="module")
def result():
    spec = spec_for("GRM")
    return from_cadet(run_batch(spec), spec)


def test_mp4(result, tmp_path):
    data = animation.profile_video(result, "solid", [0, 1], SERIES_COLORS, fmt="mp4", fps=12, max_frames=30)
    path = tmp_path / "p.mp4"
    path.write_bytes(data)
    probe = subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), "-i", str(path)], capture_output=True, text=True)
    assert "h264" in probe.stderr and "960x540" in probe.stderr


def test_gif(result):
    from io import BytesIO

    from PIL import Image
    img = Image.open(BytesIO(animation.profile_video(result, "bulk", [0, 1], SERIES_COLORS, fmt="gif",
                                                     max_frames=15)))
    assert img.n_frames == 15


def test_bad_inputs(result):
    with pytest.raises(ValueError, match="format"):
        animation.profile_video(result, "bulk", [0], SERIES_COLORS, fmt="avi")
    with pytest.raises(ValueError, match="No component"):
        animation.profile_video(result, "solid", [1], SERIES_COLORS)    # T does not adsorb
