"""Column state save/load (sequential runs), run logs and config."""
import json

import numpy as np
import pytest

from core import model_builder as mb
from core.components import Component
from core.results_io import from_cadet, load_h5, save_h5
from core.simulator import run_batch
from utils import config, logger, state_manager


def loading_spec(model, duration, dead_volume=0.0):
    comps = [Component("A"), Component("T", bound=False)]
    return mb.BatchSpec(
        components=comps,
        column=mb.ColumnSpec(model=model, film_diffusion=None if model == "LRM" else [0.06] * 2,
                             pore_diffusion=[1e-4] * 2, axial_dispersion=6e-3),
        binding=mb.BindingSpec("Langmuir", kinetic=model == "LRM", equilibrium=[0.05, None],
                               adsorption_rate=[3.0, None], desorption_rate=[60.0, None], capacity=[0.1, None]),
        operation=mb.OperationSpec(1.0, [mb.constant(0.0, [1.0, 1.0])], dead_volume=dead_volume),
        settings=mb.SimulationSettings(duration=duration, output_interval=0.1, n_col=40, n_par=4),
    )


@pytest.mark.parametrize("model, dead_volume", [("LRMP", 0.0), ("GRM", 0.5), ("LRM", 0.0)])
def test_sequential_run_matches_continuous(model, dead_volume, tmp_path):
    """0–20 min in one run equals 0–10 min, save state, then 10 more min from that state."""
    full_spec = loading_spec(model, 20.0, dead_volume)
    full = from_cadet(run_batch(full_spec), full_spec)

    first_spec = loading_spec(model, 10.0, dead_volume)
    first = from_cadet(run_batch(first_spec), first_spec)
    path = tmp_path / "state.h5"
    state_manager.save_state(state_manager.state_from_result(first), path)
    state = state_manager.load_state(path)

    second_spec = loading_spec(model, 10.0, dead_volume)
    assert state_manager.incompatibilities(state, second_spec) == []
    second = from_cadet(run_batch(second_spec, state.arrays()), second_spec)

    k = np.searchsorted(full.time, 10.0)
    np.testing.assert_allclose(second.outlet, full.outlet[k:], rtol=1e-4, atol=1e-7)
    np.testing.assert_allclose(second.solid[-1], full.solid[-1], rtol=1e-4, atol=1e-7)


def test_incompatible_state_is_reported():
    spec = loading_spec("LRMP", 5.0)
    state = state_manager.state_from_result(from_cadet(run_batch(spec), spec))
    other = loading_spec("GRM", 5.0)
    other.settings.n_col = 20
    diffs = state_manager.incompatibilities(state, other)
    assert any(d.startswith("column_model") for d in diffs) and any(d.startswith("n_col") for d in diffs)


def test_state_survives_result_file():
    spec = loading_spec("LRMP", 5.0)
    r = from_cadet(run_batch(spec), spec)
    loaded = load_h5(save_h5(r))
    np.testing.assert_array_equal(state_manager.state_from_result(loaded).state, r.final_state)
    # a result file works as a column profile source: its run's final state
    from_result = state_manager.load_state(save_h5(r))
    np.testing.assert_array_equal(from_result.state, r.final_state)
    assert from_result.structure == state_manager.state_from_result(r).structure
    with pytest.raises(ValueError, match="column profile"):
        load_h5(state_manager.save_state(state_manager.state_from_result(r)))      # the other way round
    with pytest.raises(OSError):
        state_manager.load_state(b"not an hdf5 file")


def test_log_written_and_rebuildable(tmp_path):
    spec = loading_spec("LRMP", 5.0)
    r = from_cadet(run_batch(spec), spec)
    path = logger.write_log(tmp_path / "logs", spec, r)
    assert path.name.endswith("_simulation.json")
    log = json.loads(path.read_text())
    assert log["status"] == "done"
    assert mb.spec_from_dict(log["input"]) == spec
    assert {row["component"] for row in log["amounts"]} == {"A", "T"}
    assert "1/Pe" in log["dimensionless"]
    second = logger.write_log(tmp_path / "logs", spec, error="boom", status="failed",
                              timestamp=__import__("datetime").datetime.fromisoformat(log["timestamp"]))
    assert second != path and json.loads(second.read_text())["error"] == "boom"


def test_config(tmp_path):
    cfg_file = tmp_path / "config.yaml"
    cfg_file.write_text("logs_dir: my_logs\nresults_dir: /tmp/shared_results\nauto_save_results: true\n")
    cfg = config.load_config(cfg_file)
    assert cfg.logs_dir == tmp_path / "my_logs"
    assert str(cfg.results_dir) == "/tmp/shared_results"
    assert cfg.auto_save_results
    default = config.load_config(tmp_path / "missing.yaml")
    assert default.logs_dir == tmp_path / "logs" and not default.auto_save_results
