"""Pulse injection laid over the inlet program."""
import numpy as np
import pytest

from core import examples, mass
from core import model_builder as mb
from core import tolerances
from core.components import Component
from core.results_io import from_cadet
from core.simulator import run_batch
from ui import plots


def op(inlet, injection, q=2.0):
    return mb.OperationSpec(q, inlet, injection=injection)


def starts_and_a0(segments):
    return [(round(s.start, 9), [round(p[0], 9) for p in s.coefficients]) for s in segments]


def test_injection_over_a_constant_eluent():
    o = op([mb.constant(0.0, [0.0, 5.0])], mb.Injection(volume=1.0, start=2.0, feed=[3.0, 7.0]))
    assert starts_and_a0(o.program()) == [(0.0, [0.0, 5.0]), (2.0, [3.0, 7.0]), (2.5, [0.0, 5.0])]   # V/Q = 0.5 min


def test_injection_at_time_zero():
    o = op([mb.constant(0.0, [0.0])], mb.Injection(volume=1.0, start=0.0, feed=[1.0]))
    assert starts_and_a0(o.program()) == [(0.0, [1.0]), (0.5, [0.0])]


def test_injection_cuts_a_gradient_and_keeps_its_slope():
    ramp = mb.inlet_from_table([0.0, 10.0, 20.0], ["step", "linear", "step"], [[0.0], [0.0], [10.0]])
    o = op(ramp, mb.Injection(volume=4.0, start=12.0, feed=[99.0]))        # 12 .. 14 min inside the ramp
    program = o.program()
    assert starts_and_a0(program) == [(0.0, [0.0]), (10.0, [0.0]), (12.0, [99.0]), (14.0, [4.0]), (20.0, [10.0])]
    before, after = program[1], program[3]
    assert before.coefficients[0][1] == pytest.approx(1.0) and after.coefficients[0][1] == pytest.approx(1.0)
    # the ramp resumes at its own value at t = 14 min (1 per min after the start at 10): 4
    assert after.coefficients[0][0] == pytest.approx(4.0)


def test_injection_swallows_whole_rows():
    rows = mb.inlet_from_table([0.0, 3.0, 4.0, 9.0], ["step"] * 4, [[1.0], [2.0], [3.0], [4.0]])
    o = op(rows, mb.Injection(volume=10.0, start=2.0, feed=[0.0]), q=2.0)    # 2 .. 7 min
    assert starts_and_a0(o.program()) == [(0.0, [1.0]), (2.0, [0.0]), (7.0, [3.0]), (9.0, [4.0])]


def test_injection_rows_at_the_window_edges():
    rows = mb.inlet_from_table([0.0, 2.0, 7.0], ["step"] * 3, [[1.0], [2.0], [3.0]])
    o = op(rows, mb.Injection(volume=10.0, start=2.0, feed=[0.0]), q=2.0)
    assert starts_and_a0(o.program()) == [(0.0, [1.0]), (2.0, [0.0]), (7.0, [3.0])]


def test_no_injection_leaves_the_program_alone():
    rows = [mb.constant(0.0, [1.0])]
    assert op(rows, None).program() == rows


@pytest.mark.parametrize("injection, text", [
    (mb.Injection(volume=0.0, start=0.0, feed=[1.0]), "volume"),
    (mb.Injection(volume=-1.0, start=0.0, feed=[1.0]), "volume"),
    (mb.Injection(volume=1.0, start=-1.0, feed=[1.0]), "start"),
])
def test_invalid_injection(injection, text):
    with pytest.raises(ValueError, match=text):
        op([mb.constant(0.0, [0.0])], injection).program()


def test_injection_needs_the_right_number_of_feeds():
    spec = examples.default()
    spec.operation.injection.feed = [1.0]
    with pytest.raises(ValueError, match="one feed concentration per component"):
        mb.build_process(spec)


def explicit_equivalent(spec):
    """The same run written as explicit inlet rows (what the table did before injections existed)."""
    twin = mb.spec_from_dict(mb.spec_to_dict(spec))
    twin.operation.inlet = twin.operation.program()
    twin.operation.injection = None
    return twin


def test_injection_runs_exactly_like_explicit_rows():
    spec = examples.default()
    spec.column.model, spec.column.pore_diffusion = "LRMP", None
    spec.operation.injection = mb.Injection(volume=0.75, start=1.0, feed=[2.0, 1.0])
    a = from_cadet(run_batch(spec), spec)
    b = from_cadet(run_batch(explicit_equivalent(spec)), spec)
    np.testing.assert_array_equal(a.outlet, b.outlet)
    assert a.outlet.max() > 0


def test_injected_amount_is_volume_times_feed():
    spec = examples.default()
    spec.operation.injection = mb.Injection(volume=0.4, start=3.0, feed=[2.0, 5.0])    # mmol/L × mL
    np.testing.assert_allclose(mass.input_moles(spec), [0.4 * 2.0e-3 * 1e-3, 0.4 * 5.0e-3 * 1e-3])


def test_feed_counts_for_the_tolerance_scale():
    comps = [Component("M"), Component("S")]
    spec = mb.BatchSpec(comps, mb.ColumnSpec(), mb.BindingSpec("None"),
                        mb.OperationSpec(1.0, [mb.constant(0.0, [0.0, 50.0])],
                                         injection=mb.Injection(1.0, 0.0, [1e-4, 50.0])),
                        mb.SimulationSettings(duration=10))
    assert tolerances.concentration_scale(spec) == pytest.approx(1e-4)            # the trace feed, not salt
    spec.operation.injection = None
    assert tolerances.concentration_scale(spec) == pytest.approx(50.0)


def test_inlet_plot_shows_steps_and_ramps():
    comps = [Component("A"), Component("B")]
    spec = examples.default()
    spec.operation.inlet = mb.inlet_from_table([0.0, 5.0, 15.0], ["step", "linear", "step"],
                                               [[0.0, 0.0], [0.0, 0.0], [10.0, 1.0]])
    spec.operation.injection = mb.Injection(volume=1.0, start=1.0, feed=[3.0, 2.0])
    fig = plots.inlet_program(spec.operation.program(), comps, [0, 1], duration=30.0)
    a = fig.data[0]
    pairs = list(zip(a.x, a.y))
    assert (1.0, 3.0) in pairs and (2.0, 3.0) in pairs and (2.0, 0.0) in pairs     # the pulse is a square
    assert (5.0, 0.0) in pairs and (15.0, 10.0) in pairs                             # the ramp
    assert a.x[0] == 0.0 and a.x[-1] == 30.0
    assert fig.layout.xaxis.range == (0.0, 30.0)
