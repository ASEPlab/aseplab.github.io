"""Headless test of the results viewer page."""
from pathlib import Path

import pytest
from streamlit.testing.v1 import AppTest

from core.results_io import from_cadet, load_h5
from core.simulator import run_batch
from tests.test_results_io import spec_for
from ui.plots import PHASE_LABELS

PAGE = Path(__file__).resolve().parents[1] / "pages" / "3_Results_Viewer.py"


@pytest.mark.parametrize("model, phases", [("GRM", ["bulk", "pore", "solid"]), ("LRM", ["bulk", "solid"])])
def test_viewer(model, phases):
    spec = spec_for(model)
    at = AppTest.from_file(str(PAGE), default_timeout=60)
    at.session_state["batch_result"] = from_cadet(run_batch(spec), spec)
    at.run()
    assert not at.exception
    assert at.selectbox(key="viewer_phase").options == [PHASE_LABELS[p] for p in phases]

    next_button = at.button(key="viewer_next")
    next_button.click().run()
    next_button.click().run()
    assert at.session_state["viewer_t_index"] == 2
    at.button(key="viewer_last").click().run()
    assert at.session_state["viewer_t_index"] == len(at.session_state["batch_result"].time) - 1
    for p in phases:
        at.selectbox(key="viewer_phase").set_value(p).run()
        assert not at.exception
    at.toggle(key="viewer_fixed_y").set_value(False).run()
    assert not at.exception


def test_viewer_without_result():
    at = AppTest.from_file(str(PAGE)).run()
    assert not at.exception
    assert "Run a simulation" in at.info[0].value


def test_video_export():
    spec = spec_for("LRMP")
    at = AppTest.from_file(str(PAGE), default_timeout=120)
    at.session_state["batch_result"] = from_cadet(run_batch(spec), spec)
    at.run()
    at.number_input(key="viewer_video_frames").set_value(20).run()
    at.button(key="viewer_video_create").click().run()
    assert not at.exception and not at.error
    video = at.session_state["viewer_video"]
    assert video["fmt"] == "mp4" and video["data"][4:8] == b"ftyp"
    at.selectbox(key="viewer_video_fmt").set_value("gif").run()
    at.button(key="viewer_video_create").click().run()
    assert at.session_state["viewer_video"]["data"][:6] == b"GIF89a"


def test_excel_and_column_profile_downloads_are_offered():
    spec = spec_for("LRMP")
    at = AppTest.from_file(str(PAGE), default_timeout=120)
    at.session_state["batch_result"] = from_cadet(run_batch(spec), spec)
    at.run()
    assert not at.exception
    labels = [b.proto.label for b in at.get("download_button")]
    assert "📊 Excel workbook (all data)" in labels and "💾 Column profile" in labels
    assert any("Column state" in label for label in labels) is False        # old wording is gone


def test_excel_profile_checkbox_and_title():
    import io
    import openpyxl
    spec = spec_for("LRMP")
    spec.title = "My run"
    at = AppTest.from_file(str(PAGE), default_timeout=120)
    at.session_state["batch_result"] = from_cadet(run_batch(spec), spec)
    at.run()
    names = lambda: openpyxl.load_workbook(io.BytesIO(at.session_state["viewer_xlsx"][2])).sheetnames
    assert not at.checkbox(key="viewer_xlsx_profiles").value and not any(n.startswith("Profile") for n in names())
    assert at.session_state["viewer_xlsx"][3].startswith("My_run_")
    at.checkbox(key="viewer_xlsx_profiles").set_value(True).run()
    assert not at.exception and "Profile bulk" in names()


def test_save_result_file_to_a_chosen_folder(tmp_path):
    spec = spec_for("LRMP")
    spec.title = "My run"
    at = AppTest.from_file(str(PAGE), default_timeout=120)
    at.session_state["batch_result"] = from_cadet(run_batch(spec), spec)
    at.run()
    assert at.text_input(key="viewer_h5_name").value.startswith("My_run_") and at.text_input(key="viewer_h5_name").value.endswith(".h5")
    at.text_input(key="viewer_h5_name").set_value("renamed").run()
    at.text_input(key="viewer_h5_folder").set_value(str(tmp_path / "out")).run()
    at.button(key="viewer_h5_save").click().run()
    assert not at.exception and not at.error
    saved = tmp_path / "out" / "renamed.h5"
    assert saved.exists() and load_h5(saved.read_bytes()).spec.title == "My run"
    at.run()                                                   # the name is now taken: needs the overwrite tick
    assert at.button(key="viewer_h5_save").disabled
    at.checkbox(key="viewer_h5_overwrite").set_value(True).run()
    assert not at.button(key="viewer_h5_save").disabled
