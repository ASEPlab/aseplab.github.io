"""Smoke test: CADET-Core + CADET-Process run a simple LRMP Langmuir pulse."""
import numpy as np
from CADETProcess.processModel import (
    ComponentSystem, Langmuir, Inlet, LumpedRateModelWithPores, Outlet,
    FlowSheet, Process,
)
from CADETProcess.simulator import Cadet

from core.simulator import cadet_root


def build_process():
    cs = ComponentSystem(['A'])
    binding = Langmuir(cs, name='langmuir')
    binding.is_kinetic = False
    binding.adsorption_rate = [1.0]
    binding.desorption_rate = [1.0]
    binding.capacity = [100.0]

    inlet = Inlet(cs, name='inlet')
    inlet.flow_rate = 1e-6 / 60  # 1 mL/min in m^3/s

    col = LumpedRateModelWithPores(cs, name='column')
    col.binding_model = binding
    col.length = 0.1                       # 10 cm
    col.diameter = 0.01                    # 1 cm
    col.bed_porosity = 0.37
    col.particle_porosity = 0.5
    col.particle_radius = 25e-6
    col.axial_dispersion = 1e-7
    col.film_diffusion = [1e-5]

    outlet = Outlet(cs, name='outlet')

    fs = FlowSheet(cs)
    for u in (inlet, col, outlet):
        fs.add_unit(u)
    fs.add_connection(inlet, col)
    fs.add_connection(col, outlet)

    proc = Process(fs, 'pulse')
    proc.cycle_time = 30 * 60
    proc.add_event('load', 'flow_sheet.inlet.c', [1.0], 0)
    proc.add_event('wash', 'flow_sheet.inlet.c', [0.0], 60)
    return proc


def test_cadet_runs():
    sim = Cadet(install_path=cadet_root())      # the environment's CADET, also without it on PATH
    assert sim.check_cadet()
    results = sim.simulate(build_process())
    c = results.solution.outlet.outlet.solution
    assert np.isfinite(c).all()
    assert c.max() > 0
