"""SMB Excel workbook: full-run charts per product outlet and the average-concentration sheet."""
import io
import zipfile

import numpy as np
import openpyxl
import pytest

from core import examples, smb, smb_excel
from core import smb_results as sr
from core.smb_sim import run_smb


@pytest.fixture(scope="module")
def result():
    spec = examples.smb_binary()
    spec.base.settings.n_col, spec.base.settings.output_interval = 10, 0.1
    spec.cycles = smb.CycleSettings(mode="fixed", n_cycles=2)
    results, job = run_smb(spec)
    return sr.from_cadet(results, spec, job.converged, job.differences)


def test_average_concentration_sheet(result):
    ws = openpyxl.load_workbook(io.BytesIO(smb_excel.build_workbook(result)))["Average concentration"]
    header = [c.value for c in ws[1]]
    assert header[:6] == ["switch", "cycle", "from [min]", "to [min]", "average time [min]", "extract A [mmol/L]"]
    rows = [[c.value for c in row] for row in ws.iter_rows(min_row=2, max_row=1 + 2 * result.spec.n_columns)]
    for r in rows:
        assert r[4] == pytest.approx(0.5 * (r[2] + r[3]))
    starts, ends, means = sr.switch_averages(result, "extract")
    np.testing.assert_allclose([r[5] for r in rows], means[:, 0])


def test_charts_cover_the_whole_run(result):
    names = zipfile.ZipFile(io.BytesIO(smb_excel.build_workbook(result))).namelist()
    charts = sorted(n for n in names if n.startswith("xl/charts/chart"))
    assert len(charts) == len(result.spec.geometry.products) + 1             # one per product outlet + convergence
    xml = zipfile.ZipFile(io.BytesIO(smb_excel.build_workbook(result))).read(charts[0]).decode()
    assert "Data!$A$2:$A$" + str(len(result.time) + 1) in xml               # from the first output time
    n_switch = result.n_cycles * result.spec.n_columns
    assert f"'Average concentration'!$E$2:$E${n_switch + 1}" in xml         # averages on the same chart
