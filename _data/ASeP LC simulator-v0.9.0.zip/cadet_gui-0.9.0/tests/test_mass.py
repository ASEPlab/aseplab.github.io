"""Per-component input/output amounts."""
import numpy as np
import pytest

from core import mass
from core import model_builder as mb
from core.components import Component
from core.results_io import from_cadet
from core.simulator import run_batch


def spec_with_units():
    comps = [Component("Cu", mw=63.546, charge=2, bound=False, liquid_unit="mg/L"),
             Component("T", bound=False, liquid_unit="mmol/L")]
    return mb.BatchSpec(
        components=comps,
        column=mb.ColumnSpec(model="LRMP", film_diffusion=[0.5, 0.5], axial_dispersion=6e-3),
        binding=mb.BindingSpec("None"),
        operation=mb.OperationSpec(2.0, [mb.constant(0.0, [63.546, 1.0]),
                                         mb.linear_gradient(0.5, 1.5, [63.546, 1.0], [0.0, 0.0]),
                                         mb.constant(1.5, [0.0, 0.0])]),
        settings=mb.SimulationSettings(duration=30.0, output_interval=0.05, n_col=60),
    )


def test_input_is_exact():
    spec = spec_with_units()
    # Cu: 1 mmol/L for 0.5 min, then a 1 min ramp to 0 -> 1 mmol/L × (0.5 + 0.5) min × 2 mL/min = 2 µmol
    np.testing.assert_allclose(mass.input_moles(spec), [2e-6, 2e-6])


def test_mass_table_units():
    spec = spec_with_units()
    r = from_cadet(run_batch(spec), spec)
    table = mass.mass_table(r)
    assert list(table["unit"]) == ["mg", "mmol"]
    assert table.loc["Cu", "input"] == pytest.approx(2e-3 * 63.546)          # mg
    assert table.loc["T", "input"] == pytest.approx(2e-3)                    # mmol
    assert table.loc["Cu", "output"] == pytest.approx(table.loc["Cu", "input"], rel=1e-3)
    meq = mass.mass_table(r, "meq")
    assert meq.loc["Cu", "input"] == pytest.approx(4e-3)                     # ν = 2
    assert np.isnan(meq.loc["T", "input"])                                   # no charge given
    checks = mass.numerical_checks(r)
    assert (checks["NaN values"] == 0).all()
    assert (checks["negative undershoot / peak"] < 1e-3).all()


def test_ph_skipped():
    spec = spec_with_units()
    spec.components[1].liquid_unit = "pH"
    r = from_cadet(run_batch(spec), spec)
    assert list(mass.mass_table(r).index) == ["Cu"]
