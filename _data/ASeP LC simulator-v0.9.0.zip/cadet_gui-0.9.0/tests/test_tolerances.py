"""Concentration-scaled solver tolerances and protection against empty (NaN) inputs."""
import json
import time

import numpy as np
import pytest

from core import model_builder as mb
from core import tolerances as tol
from core.components import Component
from core.results_io import from_cadet
from core.simulator import SimulationJob, nonfinite_paths, run_batch


def linear_spec(c0, unit="mmol/L", **settings):
    comp = Component("A", liquid_unit=unit)
    return mb.BatchSpec(
        [comp],
        mb.ColumnSpec(model="LRMP", film_diffusion=[0.06], axial_dispersion=6e-3),
        mb.BindingSpec("Linear", equilibrium=[0.002]),            # linear: outlet/c0 independent of c0
        mb.OperationSpec(1.0, [mb.constant(0, [c0]), mb.constant(0.5, [0.0])]),
        mb.SimulationSettings(duration=40, output_interval=0.02, n_col=100, **settings),
    )


def test_defaults_at_mM_level():
    for c0 in (1.0, 50.0, 500.0):
        assert tol.auto_tolerances(linear_spec(c0)) == tol.DEFAULT        # mM and above: CADET's defaults
    assert tol.auto_tolerances(linear_spec(1.0, unit="mol/L")) == tol.DEFAULT   # 1 mol/L = 1000 mol/m³


def test_scaled_to_trace_solute():
    t = tol.auto_tolerances(linear_spec(1e-3))                           # 1 µM
    assert t.abstol == pytest.approx(1e-11) and t.algtol == pytest.approx(1e-15)
    assert t.weno_eps == pytest.approx(1e-16) and t.reltol == tol.DEFAULT.reltol


def test_scale_uses_smallest_solute_not_salt_or_ph():
    comps = [Component("salt", charge=1), Component("pH", bound=False, liquid_unit="pH"),
             Component("M", charge=2), Component("P", bound=False)]
    spec = mb.BatchSpec(
        comps, mb.ColumnSpec(), mb.BindingSpec("None"),
        mb.OperationSpec(1.0, [mb.constant(0, [500.0, 7.0, 1e-3, 0.0])]),
        mb.SimulationSettings(duration=10))
    assert tol.concentration_scale(spec) == pytest.approx(1e-3)           # pH and the never-fed product skipped
    spec.column.initial_liquid = [50.0, 7.0, 0.0, 1e-5]                   # initial values count too
    assert tol.concentration_scale(spec) == pytest.approx(1e-5)
    spec.operation.inlet = [mb.constant(0, [0.0] * 4)]
    spec.column.initial_liquid = None
    assert tol.concentration_scale(spec) is None
    assert tol.auto_tolerances(spec) == tol.DEFAULT


def test_manual_mode():
    spec = linear_spec(1e-6, tolerance_mode="manual", reltol=1e-4, abstol=1e-9, algtol=1e-13, weno_eps=1e-12)
    assert tol.effective_tolerances(spec) == tol.Tolerances(1e-4, 1e-9, 1e-13, 1e-12)
    spec.settings.abstol = 0.0
    with pytest.raises(ValueError, match="abstol"):
        tol.effective_tolerances(spec)
    spec.settings.tolerance_mode = "fast"
    with pytest.raises(ValueError, match="Unknown tolerance mode"):
        tol.effective_tolerances(spec)


def normalised_outlet(c0, **settings):
    spec = linear_spec(c0, **settings)
    return from_cadet(run_batch(spec), spec).outlet[:, 0] / c0


def test_result_is_independent_of_concentration_scale():
    ref = normalised_outlet(1.0)
    for c0 in (1e-3, 1e-6, 1e-9, 1e-12):                                   # mmol/L
        assert np.max(np.abs(normalised_outlet(c0) - ref)) / ref.max() < 1e-4, c0


def test_fixed_tolerances_fail_at_trace_level():
    """Documents why the automatic mode exists: CADET's fixed defaults distort a 1 nM peak."""
    ref = normalised_outlet(1.0)
    fixed = normalised_outlet(1e-6, tolerance_mode="manual")               # manual = CADET defaults here
    assert np.max(np.abs(fixed - ref)) / ref.max() > 1e-2


def test_tolerances_reach_cadet_and_the_log(tmp_path):
    from utils import logger
    spec = linear_spec(1e-6)
    job = SimulationJob(spec).start().wait()
    assert job.status == "done"
    assert job.tolerances.abstol == pytest.approx(1e-14)
    path = logger.write_log(tmp_path, spec, from_cadet(job.results, spec))
    logged = json.loads(path.read_text())["solver_tolerances"]
    assert logged["abstol"] == pytest.approx(1e-14) and logged["reltol"] == 1e-6


# --- empty values must never reach CADET ----------------------------------------------

def test_missing_binding_value_is_reported():
    comps = [Component("salt"), Component("A")]                           # salt adsorbs, no K entered
    spec = mb.BatchSpec(
        comps, mb.ColumnSpec(model="LRMP", film_diffusion=[0.06, 0.06]),
        mb.BindingSpec("Langmuir", equilibrium=[None, 0.05], capacity=[None, 0.1]),
        mb.OperationSpec(1.0, [mb.constant(0, [1.0, 1.0])]), mb.SimulationSettings())
    with pytest.raises(ValueError, match=r"K is empty for component 'salt'"):
        mb.build_process(spec)
    spec.components[0].bound = False                                       # fine once it does not adsorb
    mb.build_process(spec)


def test_missing_mass_transfer_value_is_reported():
    spec = linear_spec(1.0)
    spec.column.film_diffusion = [None]
    with pytest.raises(ValueError, match="kf is empty for component 'A'"):
        mb.build_process(spec)


def test_nonfinite_input_fails_fast_instead_of_hanging():
    spec = linear_spec(1.0)
    spec.operation.inlet = [mb.constant(0.0, [float("nan")])]
    spec.settings.timeout = 120
    t = time.time()
    job = SimulationJob(spec).start().wait()
    assert job.status == "failed" and "non-finite" in job.error
    assert time.time() - t < 10


def test_nonfinite_paths():
    tree = {"a": {"b": np.array([1.0, np.nan]), "c": [1, 2]}, "d": "text", "e": np.inf, "f": 3.0}
    assert sorted(nonfinite_paths(tree)) == ["/a/b", "/e"]
