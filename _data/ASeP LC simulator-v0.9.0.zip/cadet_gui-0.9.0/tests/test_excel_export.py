"""The Excel workbook: sheets, graphable data, summary content, charts, profiles, flat inputs."""
import io
import zipfile

import numpy as np
import openpyxl
import pytest

from core import examples
from core import model_builder as mb
from datetime import datetime

from core.excel_export import build_workbook, export_filename
from core.naming import file_stem
from core.results_io import from_cadet, load_h5, save_h5
from core.simulator import run_batch


@pytest.fixture(scope="module")
def ligand():
    """GIEX + ligand reactions + injection + dead volume: every section of the workbook is used."""
    spec = examples.giex_metals(with_ligand=True)
    spec.operation.dead_volume = 0.4
    spec.settings.duration = 40.0
    spec.settings.output_interval = 0.05
    return from_cadet(run_batch(spec), spec)


@pytest.fixture(scope="module")
def plain():
    spec = examples.default()
    spec.column.model, spec.column.pore_diffusion = "LRMP", None
    spec.settings.duration = 20.0
    return from_cadet(run_batch(spec), spec)


def open_xlsx(data):
    return openpyxl.load_workbook(io.BytesIO(data), data_only=True)


def cells(ws):
    return [v for row in ws.iter_rows(values_only=True) for v in row if v is not None]


def test_sheets_in_order(ligand, plain):
    assert open_xlsx(build_workbook(ligand, include_profiles=True)).sheetnames == [
        "Summary", "Data", "Charts", "Profile bulk", "Profile pore", "Profile solid", "Input parameters"]
    wb = open_xlsx(build_workbook(plain, include_profiles=True))
    assert wb.sheetnames[:3] == ["Summary", "Data", "Charts"] and wb.sheetnames[-1] == "Input parameters"


def test_profiles_are_optional_and_off_by_default(ligand):
    default = open_xlsx(build_workbook(ligand)).sheetnames
    assert default == ["Summary", "Data", "Charts", "Input parameters"]
    assert not any(n.startswith("Profile") for n in default)
    assert len(build_workbook(ligand)) < len(build_workbook(ligand, include_profiles=True))


def test_summary_shows_title_and_dates(ligand):
    when = datetime(2026, 3, 4, 5, 6, 7)
    spec = mb.spec_from_dict(mb.spec_to_dict(ligand.spec))
    spec.title = "Cu / Ni test"
    titled = from_cadet(run_batch(spec), spec)
    ws = open_xlsx(build_workbook(titled, created=when))["Summary"]
    text = " | ".join(str(v) for v in cells(ws))
    assert "Cu / Ni test" in text
    assert "Simulation completed" in text and "Workbook created" in text and "2026-03-04 05:06:07" in text
    assert titled.summary["completed"][:4].isdigit()
    assert export_filename(titled, when) == "Cu_Ni_test_20260304_050607.xlsx"
    assert export_filename(ligand, when) == "GIEX_two_metals_+_ligand_L_20260304_050607.xlsx"
    spec.title = ""
    assert export_filename(from_cadet(run_batch(spec), spec), when) == "cadet_results_20260304_050607.xlsx"


def test_file_stem_is_safe():
    assert file_stem("a b/c:d*?") == "a_b_c_d"
    assert file_stem("", "x") == "x" and file_stem("///", "x") == "x"


def test_data_sheet_has_graphable_columns(ligand):
    ws = open_xlsx(build_workbook(ligand))["Data"]
    header = [c.value for c in ws[1]]
    n = len(ligand.components)
    assert header[0] == "time [min]" and len(header) == 1 + 3 * n          # inlet, outlet, column outlet
    assert header[1] == "inlet salt [mmol/L]" and header[2] == "inlet pH [pH]"
    assert header[1 + n] == "outlet (after dead volume) salt [mmol/L]"
    assert header[1 + 2 * n].startswith("column outlet (before dead volume) salt")
    table = np.array([[c.value for c in row] for row in ws.iter_rows(min_row=2)], dtype=float)
    assert table.shape == (len(ligand.time), 1 + 3 * n)
    np.testing.assert_allclose(table[:, 0], ligand.time)
    np.testing.assert_allclose(table[:, 1:1 + n], ligand.inlet)
    np.testing.assert_allclose(table[:, 1 + n:1 + 2 * n], ligand.outlet)
    np.testing.assert_allclose(table[:, 1 + 2 * n:], ligand.column_outlet)
    assert not np.allclose(ligand.outlet, ligand.column_outlet)           # the dead volume really changes it


def test_without_dead_volume_there_is_one_outlet(plain):
    ws = open_xlsx(build_workbook(plain))["Data"]
    header = [c.value for c in ws[1]]
    assert header == ["time [min]", "inlet A [mmol/L]", "inlet B [mmol/L]", "outlet A [mmol/L]", "outlet B [mmol/L]"]
    np.testing.assert_allclose(plain.outlet, plain.column_outlet)


def test_summary_has_inputs_numbers_and_results(ligand):
    ws = open_xlsx(build_workbook(ligand))["Summary"]
    text = " | ".join(str(v) for v in cells(ws))
    for expected in ("Run", "Components", "Column and process", "Inlet / eluent program", "Initial state", "Binding",
                     "Mass transfer", "Mobile-phase reactions", "Simulation settings", "Dimensionless numbers",
                     "Results", "Computation time", "GIEX (rapid equilibrium)", "M1 + L = M1L", "Injection volume",
                     "1/Pe", "Nf", "Nk−", "Axial dispersion Eb", "Solver tolerances", "mean elution time",
                     "after the outlet dead volume"):
        assert expected in text, expected
    labels = {row[0]: row[1] for row in ws.iter_rows(values_only=True) if row[0] and row[1] is not None}
    assert labels["Length L"] == 10 and labels["Flow rate Q"] == 1 and labels["Extra-column (dead) volume"] == 0.4
    assert labels["Output points"] == len(ligand.time)
    assert labels["Interstitial velocity u"] == pytest.approx(1 / (0.37 * np.pi / 4))
    assert labels["Injection time V/Q"] == 1


def test_summary_amounts_match_the_mass_module(ligand):
    from core import mass
    table = mass.mass_table(ligand)
    ws = open_xlsx(build_workbook(ligand))["Summary"]
    rows = {r[0]: r for r in ws.iter_rows(values_only=True) if r[0] in table.index and r[2] is not None
            and isinstance(r[2], (int, float)) and r[1] in ("mmol", "mol", "mg", "umol", "g", "meq")}
    for name in ("M1", "M2"):
        assert rows[name][2] == pytest.approx(table.loc[name, "input"])
        assert rows[name][3] == pytest.approx(table.loc[name, "output"])


def test_charts_are_native_excel_charts(ligand, plain):
    for result, expected in ((ligand, 4), (plain, 2)):            # solutes outlet + inlet (+ salt and pH for GIEX)
        names = zipfile.ZipFile(io.BytesIO(build_workbook(result))).namelist()
        charts = [n for n in names if n.startswith("xl/charts/chart")]
        assert len(charts) == expected
    xml = zipfile.ZipFile(io.BytesIO(build_workbook(plain))).read("xl/charts/chart1.xml").decode()
    assert "Data!$A$2:$A$" in xml and "scatterChart" in xml


def test_profile_sheets(ligand):
    wb = open_xlsx(build_workbook(ligand, profile_times=5, include_profiles=True))
    ws = wb["Profile bulk"]
    assert [r[0] for r in ws.iter_rows(min_row=1, max_row=2, max_col=1, values_only=True)][0] == "t [min] →"
    z = np.array([r[0] for r in ws.iter_rows(min_row=3, max_row=2 + len(ligand.z), max_col=1, values_only=True)])
    np.testing.assert_allclose(z, ligand.z)
    times = sorted({c.value for c in ws[1][1:] if c.value is not None})
    assert len(times) == 5 and times[0] == pytest.approx(0.0) and times[-1] == pytest.approx(ligand.time[-1])
    # a profile column equals the stored array at that time
    n = len(ligand.components)
    col = 1 + n * 2 + 2                                           # third time, component M1 (index 2)
    k = int(np.argmin(np.abs(ligand.time - ws.cell(row=1, column=col + 1).value)))
    values = [ws.cell(row=r, column=col + 1).value for r in range(3, 3 + len(ligand.z))]
    np.testing.assert_allclose(values, ligand.bulk[k, :, 2])
    solid = wb["Profile solid"]
    headers = [c.value for c in solid[2][1:] if c.value]
    assert not any(h.startswith(("pH", "L ", "M1L", "M2L")) for h in headers)    # unbound: no solid column
    assert any(h.startswith("M1 [") for h in headers)


def test_every_input_is_listed(ligand):
    ws = open_xlsx(build_workbook(ligand))["Input parameters"]
    rows = {r[0]: r[1] for r in ws.iter_rows(min_row=2, values_only=True) if r[0]}
    assert rows["column.length"] == 10 and rows["column.model"] == "LRMP"
    assert rows["components[2].name"] == "M1" and rows["components[2].mw"] == 63.546
    assert rows["operation.injection.volume"] == 1.0 and rows["operation.dead_volume"] == 0.4
    assert rows["reactions.reactions[0].equation"] == "M1 + L = M1L"
    assert rows["binding.giex.capacity"] == 1.2 and rows["settings.tolerance_mode"] == "auto"


def test_correlation_inputs_are_in_the_summary(plain):
    spec = mb.spec_from_dict(mb.spec_to_dict(plain.spec))
    spec.correlation = mb.CorrelationInputs(viscosity=0.89, density=0.997, molecular_diffusion=[6e-4, 6e-4])
    result = from_cadet(run_batch(spec), spec)
    ws = open_xlsx(build_workbook(result))["Summary"]
    text = " | ".join(str(v) for v in cells(ws))
    assert "correlation estimate" in text and "Reynolds number Re" in text and "Wilson & Geankoplis" in text
    assert "Dm [cm²/min]" in text


def test_a_section_that_cannot_be_computed_does_not_break_the_export(plain):
    spec = mb.spec_from_dict(mb.spec_to_dict(plain.spec))
    spec.column.film_diffusion = None                            # makes the dimensionless numbers impossible
    broken = from_cadet(run_batch(plain.spec), spec)
    ws = open_xlsx(build_workbook(broken))["Summary"]
    assert any("not available" in str(v) for v in cells(ws))
    assert "Data" in open_xlsx(build_workbook(broken)).sheetnames


def test_result_files_keep_the_column_outlet_and_old_ones_still_work(ligand):
    again = load_h5(save_h5(ligand))
    np.testing.assert_array_equal(again.column_outlet, ligand.column_outlet)
    ligand_old = load_h5(save_h5(ligand))
    ligand_old.column_outlet = None                              # a file from before this column existed
    header = [c.value for c in open_xlsx(build_workbook(ligand_old))["Data"][1]]
    assert not any("column outlet" in h for h in header)
    assert any("outlet (after dead volume)" in h for h in header)
