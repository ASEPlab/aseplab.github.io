"""The Help and landing pages render."""
from pathlib import Path

from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]


def test_help_page():
    at = AppTest.from_file(str(ROOT / "pages" / "9_Help.py")).run()
    assert not at.exception
    assert [t.label for t in at.tabs] == ["Inputs", "Model equations", "Outputs", "SMB"]
    assert len(at.latex) >= 8


def test_landing_page():
    at = AppTest.from_file(str(ROOT / "app.py")).run()
    assert not at.exception
