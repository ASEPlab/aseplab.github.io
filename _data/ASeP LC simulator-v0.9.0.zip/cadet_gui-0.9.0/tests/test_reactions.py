"""Mobile-phase reactions: parsing, unit conversion and outlet equilibrium."""
import numpy as np
import pytest

from core import dimensionless as dl
from core import model_builder as mb
from core import reactions as rx
from core.components import Component
from core.results_io import from_cadet
from core.simulator import run_batch

KA = 1000.0                 # L/mol
M0, L0 = 1.0, 2.0           # mmol/L


def test_parse_equation():
    names = ["M", "B-C", "B-M", "C", "L", "ML2"]
    assert rx.parse_equation("M + B-C = B-M + C", names) == ({"M": 1, "B-C": 1}, {"B-M": 1, "C": 1})
    assert rx.parse_equation("M + 2 L <=> ML2", names) == ({"M": 1, "L": 2}, {"ML2": 1})
    assert rx.parse_equation("M + 2 L ⇌ ML2", names)[0] == {"M": 1, "L": 2}
    with pytest.raises(ValueError, match="unknown component"):
        rx.parse_equation("M + X = ML2", names)
    with pytest.raises(ValueError, match="exactly one"):
        rx.parse_equation("M + L", names)
    with pytest.raises(ValueError, match="both sides"):
        rx.parse_equation("M + L = M + C", names)


def test_unit_conversion():
    # bimolecular k+ = 1 L/(mol·min) = 1e-3 m³/(mol·min) -> /60 per s
    assert rx.rate_to_si(1.0, 2, "mol/L") == pytest.approx(1e-3 / 60)
    assert rx.rate_to_si(1.0, 2, "mmol/L") == pytest.approx(1 / 60)
    assert rx.rate_to_si(6.0, 1, "mol/L") == pytest.approx(0.1)
    assert rx.equilibrium_to_si(1000.0, 2, 1, "mol/L") == pytest.approx(1.0)   # L/mol -> m³/mol


def complex_spec(model, k_bwd=60.0, metal_unit="mmol/L"):
    mw = 63.546
    metal = Component("M", mw=mw, bound=False, liquid_unit=metal_unit)
    comps = [metal, Component("L", bound=False), Component("ML", bound=False)]
    feed_m = M0 * mw if metal_unit == "mg/L" else M0
    reaction = rx.ReactionSpec("M + L = ML", k_fwd=KA * k_bwd, k_bwd=k_bwd)
    return mb.BatchSpec(
        components=comps,
        column=mb.ColumnSpec(model=model, film_diffusion=None if model == "LRM" else [1.0] * 3,
                             pore_diffusion=[1e-3] * 3, axial_dispersion=1e-2),
        binding=mb.BindingSpec("None"),
        operation=mb.OperationSpec(1.0, [mb.constant(0.0, [feed_m, L0, 0.0])]),
        settings=mb.SimulationSettings(duration=40.0, output_interval=0.5, n_col=20, n_par=3),
        reactions=rx.ReactionSystem("mol/L", [reaction]),
    )


def analytic_complex():
    """Solve (M0 − x)(L0 − x)·Ka = x in mol/L."""
    m0, l0 = M0 / 1000, L0 / 1000
    a, b, c = KA, -(KA * (m0 + l0) + 1), KA * m0 * l0
    return 1000 * (-b - np.sqrt(b * b - 4 * a * c)) / (2 * a)    # mmol/L


@pytest.mark.parametrize("model", mb.COLUMN_MODELS)
@pytest.mark.parametrize("k_bwd", [60.0, 600.0])          # 1/min
def test_outlet_equilibrium(model, k_bwd):
    spec = complex_spec(model, k_bwd)
    r = from_cadet(run_batch(spec), spec)
    assert r.summary["exit_flag"] == 0
    m, lig, ml = r.outlet[-1]
    assert ml == pytest.approx(analytic_complex(), rel=1e-3)
    assert m + ml == pytest.approx(M0, rel=1e-4)               # metal conserved
    assert lig + ml == pytest.approx(L0, rel=1e-4)
    if model != "LRM":                                          # pore liquid reacts too
        pm, plig, pml = r.pore[-1, -1]
        assert pml / (pm * plig) * 1000 == pytest.approx(KA, rel=1e-3)


def test_reaction_with_mass_units():
    spec = complex_spec("LRMP", metal_unit="mg/L")
    r = from_cadet(run_batch(spec), spec)
    m_mmol = r.outlet[-1, 0] / 63.546
    assert r.outlet[-1, 2] == pytest.approx(analytic_complex(), rel=1e-3)
    assert m_mmol + r.outlet[-1, 2] == pytest.approx(M0, rel=1e-4)


def test_reaction_groups():
    spec = complex_spec("LRMP")
    g = dl.reaction_groups(spec)[0]
    u = dl.velocity(spec.column, 1.0)
    L = spec.column.length
    assert g["Nk−"] == pytest.approx(L * 60.0 / u)
    assert g["Nk+"] == pytest.approx(L * KA * 60.0 * (L0 / 1000) / u)      # C = ligand feed (larger)
    assert g["Nk+/Nk−"] == pytest.approx(KA * L0 / 1000)
    assert "near equilibrium" in g["note"]                                  # Nk− ≈ 174
    slow = dl.reaction_groups(complex_spec("LRMP", k_bwd=0.01))[0]
    assert slow["Nk−"] < 1 and "kinetics" in slow["note"]


def test_reaction_spec():
    r = rx.ReactionSpec("M + L = ML", k_fwd=1e5, k_bwd=100.0)
    assert r.equilibrium == pytest.approx(1e3)
    assert rx.ReactionSpec("M + L = ML", k_fwd=1.0).equilibrium is None
    old = rx.ReactionSpec.from_dict({"equation": "M + L = ML", "kinetic": True, "k_fwd": 2.0, "k_bwd": 1.0,
                                     "equilibrium": 2.0})
    assert old == rx.ReactionSpec("M + L = ML", 2.0, 1.0)
    with pytest.raises(ValueError, match=r"both k\+ and k−"):
        rx.rates(rx.ReactionSpec("M + L = ML", k_fwd=1.0))


def test_reaction_rejects_ph():
    spec = complex_spec("LRMP")
    spec.components[1].liquid_unit = "pH"
    with pytest.raises(ValueError, match="pH modulator"):
        mb.build_process(spec)


# --- reactions together with Linear / Langmuir binding ---------------------------------------

def binding_case(kind, ka_rx, model="LRMP"):
    """Metal M adsorbs (Linear or Langmuir); ligand L and complex ML do not; M + L = ML in the mobile phase."""
    comps = [Component("M"), Component("L", bound=False), Component("ML", bound=False)]
    if kind == "Linear":
        binding = mb.BindingSpec("Linear", equilibrium=[0.004, None, None])
    else:
        binding = mb.BindingSpec("Langmuir", equilibrium=[0.5, None, None], capacity=[0.02, None, None])
    reactions = (rx.ReactionSystem("mol/L", [rx.ReactionSpec("M + L = ML", k_fwd=ka_rx * 100.0, k_bwd=100.0)])
                 if ka_rx else None)
    return mb.BatchSpec(
        comps,
        mb.ColumnSpec(model=model, film_diffusion=[0.5] * 3, pore_diffusion=[1e-3] * 3, axial_dispersion=1e-2,
                      length=5.0),
        binding,
        mb.OperationSpec(1.0, [mb.constant(0.0, [0.0, 0.5, 0.0])],
                         injection=mb.Injection(volume=1.0, start=0.0, feed=[1.0, 0.5, 0.0])),
        mb.SimulationSettings(duration=120.0, output_interval=0.05, n_col=60, n_par=5),
        reactions=reactions,
    )


def metal_curve(spec):
    r = from_cadet(run_batch(spec), spec)
    total = r.outlet[:, 0] + r.outlet[:, 2]                   # free + complexed metal
    return r.time, total


@pytest.mark.parametrize("model", ["LRMP", "GRM"])
@pytest.mark.parametrize("kind", ["Linear", "Langmuir"])
def test_reactions_with_adsorption_conserve_the_metal(kind, model):
    spec = binding_case(kind, ka_rx=2e3, model=model)
    t, total = metal_curve(spec)
    injected = 1.0 * 1.0 * 1e-3                                # 1 mL × 1 mmol/L = 1e-3 mmol
    assert np.trapezoid(total, t) * 1.0 / 1000 == pytest.approx(injected, rel=2e-2)   # (mmol/L·min)·mL/min


@pytest.mark.parametrize("kind", ["Linear", "Langmuir"])
def test_complexation_releases_the_metal_earlier(kind):
    """The complex does not adsorb, so binding the metal in the mobile phase speeds up its elution;
    a negligible Ka changes nothing."""
    def centroid(spec):
        t, c = metal_curve(spec)
        return np.trapezoid(t * c, t) / np.trapezoid(c, t)

    free = centroid(binding_case(kind, ka_rx=None))
    weak = centroid(binding_case(kind, ka_rx=1e-6))
    strong = centroid(binding_case(kind, ka_rx=2e3))
    assert weak == pytest.approx(free, rel=1e-3)
    assert strong < 0.8 * free


def test_zero_rate_constants_do_not_divide_by_zero():
    import warnings
    spec = complex_spec("LRMP")
    with warnings.catch_warnings():
        warnings.simplefilter("error")                          # a 0/0 RuntimeWarning would fail here
        spec.reactions.reactions[0] = rx.ReactionSpec("M + L = ML", k_fwd=0.0, k_bwd=0.0)
        both = dl.reaction_groups(spec)[0]
        spec.reactions.reactions[0] = rx.ReactionSpec("M + L = ML", k_fwd=5.0, k_bwd=0.0)
        irreversible = dl.reaction_groups(spec)[0]
    assert "does nothing" in both["note"] and both["Nk+/Nk−"] != both["Nk+/Nk−"]     # NaN
    assert "irreversible" in irreversible["note"] and irreversible["Nk+/Nk−"] == float("inf")
