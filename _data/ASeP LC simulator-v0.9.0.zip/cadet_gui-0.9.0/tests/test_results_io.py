"""BatchResult conversion and HDF5 round trip."""
import numpy as np
import pytest

from core import model_builder as mb
from core import units
from core.components import Component
from core.results_io import _shell_weights, from_cadet, load_h5, save_h5
from core.simulator import run_batch

Q, C_FEED, T_PULSE = 1.0, 1.0, 0.5   # mL/min, mmol/L, min


def spec_for(model):
    comps = [Component("A", solid_unit="mmol/mL bed"), Component("T", bound=False)]
    kinetic = model == "LRM"
    return mb.BatchSpec(
        components=comps,
        column=mb.ColumnSpec(model=model, film_diffusion=None if model == "LRM" else [0.06] * 2,
                             pore_diffusion=[1e-4] * 2, axial_dispersion=6e-3),
        binding=mb.BindingSpec("Linear", kinetic=kinetic, equilibrium=[0.002, None],
                               adsorption_rate=[0.002 * 60, None], desorption_rate=[60.0, None]),
        operation=mb.OperationSpec(Q, [mb.constant(0, [C_FEED, C_FEED]), mb.constant(T_PULSE, [0, 0])]),
        settings=mb.SimulationSettings(duration=6.0, output_interval=0.05, n_col=60, n_par=6),
    )


def test_shell_weights():
    w = _shell_weights(np.array([0.875, 0.625, 0.375, 0.125]), 1.0)   # CADET order: outer -> centre
    np.testing.assert_allclose(w, [1 - 0.75 ** 3, 0.75 ** 3 - 0.5 ** 3, 0.5 ** 3 - 0.25 ** 3, 0.25 ** 3])
    assert w.sum() == pytest.approx(1.0)


@pytest.mark.parametrize("model", mb.COLUMN_MODELS)
def test_column_inventory_equals_injected(model):
    """While the pulse is inside the column, bulk + pore + solid amount = injected amount."""
    spec = spec_for(model)
    r = from_cadet(run_batch(spec), spec)
    col = spec.column
    k = int(np.searchsorted(r.time, 2.0))          # after injection, before breakthrough
    assert r.outlet[k].max() < 1e-6

    area = units.cross_section_area(col.diameter)
    dz = col.length / len(r.z)
    injected = Q * C_FEED / 1000 * T_PULSE          # mmol
    for i in range(2):
        if model == "LRM":
            liquid = col.total_porosity() * r.bulk[k, :, i]
        else:
            liquid = col.eps_b * r.bulk[k, :, i] + (1 - col.eps_b) * col.eps_p * r.pore[k, :, i]
        amount = area * dz * liquid.sum() / 1000     # mmol/L × mL -> mmol
        if spec.components[i].bound:
            amount += area * dz * r.solid[k, :, i].sum()   # mmol/mL bed × mL
        else:
            assert np.isnan(r.solid[:, :, i]).all()
        assert amount == pytest.approx(injected, rel=1e-3)
    assert ("pore" in r.phases()) == (model != "LRM")


def test_h5_round_trip(tmp_path):
    spec = spec_for("GRM")
    r = from_cadet(run_batch(spec), spec)
    for target in (tmp_path / "r.h5", None):
        data = save_h5(r, target)
        loaded = load_h5(target if data is None else data)
        assert loaded.spec == r.spec
        assert loaded.summary == r.summary
        for name in ("time", "z", "inlet", "outlet", "bulk", "pore", "solid"):
            np.testing.assert_array_equal(getattr(loaded, name), getattr(r, name))
    df = loaded.outlet_dataframe()
    assert list(df.columns) == ["time [min]", "A [mmol/L]", "T [mmol/L]"]


def test_load_rejects_other_files(tmp_path):
    import h5py
    path = tmp_path / "other.h5"
    with h5py.File(path, "w") as f:
        f["x"] = [1, 2]
    with pytest.raises(ValueError, match="Not a CADET GUI"):
        load_h5(path)
