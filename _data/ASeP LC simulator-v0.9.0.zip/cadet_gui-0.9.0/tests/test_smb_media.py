"""SMB images and videos: layout PNGs per switch and the ring-profile animation."""
import io
import zipfile

import pytest
from PIL import Image

from core import examples, smb, smb_media
from core import smb_results as sr
from core.palette import SERIES_COLORS
from core.smb_sim import run_smb


@pytest.mark.parametrize("layout, zones", [("4-zone closed", None), ("4-zone open", [6.33, 3.43, 5.59, 3.26]),
                                           ("3-zone", [6.33, 3.43, 5.59]),
                                           ("5-zone open", [6.33, 3.43, 2.7, 4.9, 3.26])])
def test_layout_images(layout, zones):
    spec = examples.smb_binary()
    if zones:
        spec.layout, spec.flow_mode, spec.flows, spec.columns_per_zone = layout, "zones", zones, [1] * len(zones)
    png = smb_media.layout_png(spec, 1)
    assert png[:8] == b"\x89PNG\r\n\x1a\n" and Image.open(io.BytesIO(png)).size[0] > 800
    names = zipfile.ZipFile(io.BytesIO(smb_media.layout_zip(spec))).namelist()
    assert names == [f"switch_{i + 1:02d}.png" for i in range(spec.n_columns)]


@pytest.fixture(scope="module")
def result():
    spec = examples.smb_binary()
    spec.base.settings.n_col, spec.base.settings.output_interval = 10, 0.1
    spec.cycles = smb.CycleSettings(mode="fixed", n_cycles=2)
    results, job = run_smb(spec)
    return sr.from_cadet(results, spec, job.converged, job.differences)


def test_ring_video(result):
    gif = smb_media.ring_video(result, "bulk", [0, 1], SERIES_COLORS, fmt="gif", max_frames=8)
    img = Image.open(io.BytesIO(gif))
    assert gif[:6] == b"GIF89a" and img.n_frames == 8
    mp4 = smb_media.ring_video(result, "solid", [0, 1], SERIES_COLORS, fmt="mp4", max_frames=12,
                               frame_range=(0, 40))
    assert mp4[4:8] == b"ftyp"
