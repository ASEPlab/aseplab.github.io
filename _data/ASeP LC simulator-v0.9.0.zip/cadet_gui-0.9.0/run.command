#!/bin/bash
# CADET GUI: starts the app and opens it in the web browser. Keep this window open while you use the app;
# close it (or press Ctrl+C) to stop the app.
cd "$(dirname "$0")"
ROOT="${CADET_GUI_HOME:-$HOME/.cadet_gui}"
PYTHON="$ROOT/env/bin/python"
if [ ! -x "$PYTHON" ]; then
    echo "The app is not installed yet. Run install.command first."
    read -r -n 1 -s -p "Press any key to close this window." || true
    exit 1
fi
echo "Starting CADET GUI $(cat VERSION)… The browser opens by itself; the address (Local URL) is shown below."
exec "$PYTHON" -m streamlit run app.py --browser.gatherUsageStats false
