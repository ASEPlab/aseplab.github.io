#!/bin/bash
# CADET GUI: installs (first time) or updates (later) the app's conda environment.
# macOS: double-click this file. Linux: bash install.command
# Everything goes into ~/.cadet_gui (or $CADET_GUI_HOME); nothing else on the computer is changed.
set -euo pipefail
cd "$(dirname "$0")"
ROOT="${CADET_GUI_HOME:-$HOME/.cadet_gui}"
MINIFORGE="$ROOT/miniforge"
ENV_DIR="$ROOT/env"

finish() { echo; read -r -n 1 -s -p "Press any key to close this window." || true; echo; }
fail() { echo; echo "Installation failed: $1"; finish; exit 1; }
trap 'fail "see the messages above."' ERR

case "$ROOT" in *" "*) fail "the folder $ROOT contains a space; set CADET_GUI_HOME to a folder without spaces.";; esac

echo "CADET GUI $(cat VERSION) — installing into $ROOT"
if [ ! -x "$MINIFORGE/bin/conda" ]; then
    case "$(uname -s)-$(uname -m)" in
        Darwin-arm64) FILE=Miniforge3-MacOSX-arm64.sh ;;
        Darwin-x86_64) FILE=Miniforge3-MacOSX-x86_64.sh ;;
        Linux-x86_64) FILE=Miniforge3-Linux-x86_64.sh ;;
        Linux-aarch64) FILE=Miniforge3-Linux-aarch64.sh ;;
        *) fail "unsupported system $(uname -s) $(uname -m)." ;;
    esac
    mkdir -p "$ROOT"
    echo "Downloading Miniforge ($FILE)…"
    curl -fL --progress-bar -o "$ROOT/miniforge.sh" "https://github.com/conda-forge/miniforge/releases/latest/download/$FILE"
    echo "Installing Miniforge…"
    bash "$ROOT/miniforge.sh" -b -p "$MINIFORGE" > /dev/null
    rm -f "$ROOT/miniforge.sh"
fi

if [ -d "$ENV_DIR/conda-meta" ]; then
    echo "Updating the app environment (CADET, Python packages)…"
    "$MINIFORGE/bin/conda" env update -p "$ENV_DIR" -f environment.yml --prune
else
    echo "Creating the app environment (CADET, Python packages; about 1 GB, 5–15 minutes)…"
    "$MINIFORGE/bin/conda" env create -p "$ENV_DIR" -f environment.yml
fi

echo "Checking the installation…"
"$ENV_DIR/bin/python" -c "from core.simulator import cadet_root; from core import __version__; print('CADET GUI', __version__, '- CADET found in', cadet_root())"
trap - ERR
echo
echo "Installation finished. Start the app with run.command."
finish
